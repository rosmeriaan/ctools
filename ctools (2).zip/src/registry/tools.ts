import { ToolDefinition, ToolCategory } from '../types';

export interface CategoryInfo {
  id: ToolCategory;
  name: string;
  emoji: string;
  description: string;
}

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'video',
    name: 'Video Tools',
    emoji: '🎬',
    description: 'Cut, compress, speed, reverse, mirror, GIF, and aspect ratio modifiers',
  },
  {
    id: 'audio',
    name: 'Audio Tools',
    emoji: '🎵',
    description: 'MP4 to MP3, audio cutter, volume changer, BPM detector, and beat markers',
  },
  {
    id: 'image',
    name: 'Image Tools',
    emoji: '🖼️',
    description: 'Background eraser, compressor, resizer, converter, and SVG utilities',
  },
  {
    id: 'design',
    name: 'Design & Motion',
    emoji: '🎨',
    description: 'Text to PNG, color picker, gradient generator, and color harmony palettes',
  },
  {
    id: 'utility',
    name: 'Utilities',
    emoji: '🧰',
    description: 'QR code generator, frame extractor, JSON formatter, and developer helpers',
  },
];

export const TOOLS_REGISTRY: ToolDefinition[] = [
  // --- VIDEO TOOLS ---
  {
    id: 'video-reverse',
    name: 'Video Reverse',
    shortDescription: 'Putar balik frame video dan audio (efek rewind)',
    description:
      'Balikkan urutan frame video dan audio secara instan di browser. Buat efek rewind keren dengan pratinjau langsung tanpa perlu upload ke server.',
    icon: 'Rewind',
    category: 'video',
    badge: 'Popular',
    tags: ['video', 'reverse', 'rewind', 'mp4', 'webm', 'effects', 'motion', 'jj'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/video-reverse/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 150,
  },
  {
    id: 'video-cutter',
    name: 'Video Cutter',
    shortDescription: 'Potong dan trim video secara presisi dengan timeline',
    description:
      'Potong durasi video dengan menentukan start time dan end time secara akurat. Pratinjau hasil sebelum download.',
    icon: 'Scissors',
    category: 'video',
    badge: 'Essential',
    tags: ['video', 'cut', 'trim', 'split', 'clip', 'mp4', 'webm', 'timeline'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-cutter/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime', 'video/ogg'],
    maxFileSizeMB: 200,
  },
  {
    id: 'video-compressor',
    name: 'Video Compressor',
    shortDescription: 'Perkecil ukuran video dengan resolusi & bitrate fleksibel',
    description:
      'Kompres video untuk hemat kuota dan upload cepat ke TikTok/Reels/Shorts dengan pilihan resolusi 1080p, 720p, 480p, dan FPS selector.',
    icon: 'Minimize2',
    category: 'video',
    badge: 'Save Size',
    tags: ['video', 'compress', 'reduce', 'resize', 'size', '1080p', '720p', 'fps'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-compressor/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 300,
  },
  {
    id: 'video-speed',
    name: 'Video Speed Changer',
    shortDescription: 'Ubah kecepatan video (Slow-Mo / Fast Forward 0.25x - 4x)',
    description:
      'Percepat atau perlambat tempo video dan audio secara instan dengan preset 0.25x hingga 4x atau kecepatan kustom.',
    icon: 'Gauge',
    category: 'video',
    tags: ['video', 'speed', 'slowmo', 'fast', 'tempo', 'motion', 'jj'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-speed/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 150,
  },
  {
    id: 'video-mirror',
    name: 'Video Mirror',
    shortDescription: 'Cermin / flip video horizontal & vertikal',
    description:
      'Balikkan orientasi video secara horizontal (mirror selfie) atau vertikal dengan pratinjau real-time.',
    icon: 'FlipHorizontal',
    category: 'video',
    tags: ['video', 'mirror', 'flip', 'horizontal', 'vertical', 'selfie'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-mirror/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 150,
  },
  {
    id: 'video-rotate',
    name: 'Video Rotate',
    shortDescription: 'Putar sudut video 90°, 180°, atau 270°',
    description:
      'Perbaiki orientasi video miring atau terbalik dengan putaran searah jarum jam (CW) atau berlawanan (CCW).',
    icon: 'RotateCw',
    category: 'video',
    tags: ['video', 'rotate', 'orientation', '90', '180', '270', 'turn'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-rotate/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 150,
  },
  {
    id: 'video-aspect-ratio',
    name: 'Aspect Ratio Converter',
    shortDescription: 'Ubah rasio video ke 9:16, 16:9, 1:1, 4:5 dengan Fit/Crop/Fill',
    description:
      'Konversi aspek rasio video untuk TikTok, Reels, YouTube Shorts, Feed Instagram dengan pilihan crop, fit, fill padding warna kustom.',
    icon: 'Crop',
    category: 'video',
    badge: 'Creator',
    tags: ['video', 'aspect', 'ratio', '9:16', '16:9', '1:1', 'tiktok', 'reels', 'crop', 'fit'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-aspect-ratio/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 150,
  },
  {
    id: 'video-to-gif',
    name: 'Video to GIF',
    shortDescription: 'Konversi cuplikan video menjadi animasi GIF berkualitas',
    description:
      'Pilih rentang waktu, atur FPS dan resolusi lebar, lalu hasilkan animasi GIF ringan dengan palet warna optimal.',
    icon: 'Film',
    category: 'video',
    tags: ['video', 'gif', 'convert', 'animation', 'loop', 'clip'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-to-gif/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 100,
  },
  {
    id: 'gif-to-video',
    name: 'GIF to Video',
    shortDescription: 'Ubah animasi GIF menjadi video MP4 / WebM',
    description:
      'Konversi animasi GIF menjadi file video berukuran ringkas yang dapat diputar di semua platform sosial media.',
    icon: 'Film',
    category: 'video',
    tags: ['gif', 'video', 'mp4', 'webm', 'convert'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/gif-to-video/',
    supportedFormats: ['image/gif'],
    maxFileSizeMB: 50,
  },
  {
    id: 'video-to-frames',
    name: 'Video to Frames',
    shortDescription: 'Ekstrak urutan frame video menjadi PNG/JPG/WEBP + ZIP',
    description:
      'Ekstrak seluruh frame atau setiap interval detik/frame dari video menjadi gambar resolusi tinggi dengan download paket ZIP.',
    icon: 'Images',
    category: 'video',
    tags: ['video', 'frames', 'extract', 'sequence', 'png', 'jpg', 'zip'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/video-to-frames/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 100,
  },
  {
    id: 'frames-to-video',
    name: 'Frames to Video',
    shortDescription: 'Gabungkan beberapa gambar menjadi video timelapse/stop-motion',
    description:
      'Susun urutan gambar, tentukan FPS (12, 24, 30, 60), dan ekspor langsung menjadi video MP4 / WebM.',
    icon: 'Images',
    category: 'video',
    tags: ['frames', 'images', 'timelapse', 'stopmotion', 'video', 'slideshow'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/frames-to-video/',
    supportedFormats: ['image/png', 'image/jpeg', 'image/webp'],
    maxFileSizeMB: 100,
  },
  {
    id: 'video-remove-audio',
    name: 'Remove Audio (Mute)',
    shortDescription: 'Hapus trek audio dari video tanpa re-encoding lambat',
    description:
      'Hilangkan suara latar belakang atau kebisingan dari video MP4/WebM dan download video hening (video_without_audio.mp4).',
    icon: 'VolumeX',
    category: 'video',
    tags: ['video', 'audio', 'mute', 'silent', 'remove', 'strip'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/video-remove-audio/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 200,
  },

  // --- AUDIO TOOLS ---
  {
    id: 'audio-spectrum',
    name: 'Audio Spectrum Visualizer',
    shortDescription: 'Visualisasi spektrum audio real-time Canvas & export video 1080p MP4',
    description:
      'Render animasi spektrum frekuensi audio (Bars, Circular, Neon Glow, Waveform) dengan custom cover background dan export video MP4 1080p 30 FPS tersinkronisasi 100% di browser.',
    icon: 'Radio',
    category: 'audio',
    badge: '1080p MP4',
    tags: ['audio', 'spectrum', 'visualizer', 'frequency', 'mp4', 'music-video', 'canvas', 'neon', 'circular', 'bars'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/audio-spectrum/',
    supportedFormats: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4', 'audio/aac'],
    maxFileSizeMB: 100,
  },
  {
    id: 'mp4-to-mp3',
    name: 'MP4 to MP3',
    shortDescription: 'Ekstrak dan konversi audio video ke format MP3 (128 - 320 kbps)',
    description:
      'Ubah file video MP4 / WebM menjadi file audio MP3 berkualitas tinggi dengan bitrate pilihan (128 - 320 kbps) langsung di browser Anda.',
    icon: 'Music2',
    category: 'audio',
    badge: 'HD Audio',
    tags: ['audio', 'mp3', 'converter', 'mp4', 'sound', 'extract'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/mp4-to-mp3/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/ogg', 'audio/mp4'],
    maxFileSizeMB: 150,
  },
  {
    id: 'audio-cutter',
    name: 'Audio Cutter',
    shortDescription: 'Potong audio MP3, WAV, OGG dengan visual waveform & preview',
    description:
      'Potong lagu, rekaman suara, atau efek sound bite dengan penanda waktu mulai dan selesai yang presisi.',
    icon: 'Scissors',
    category: 'audio',
    tags: ['audio', 'cut', 'trim', 'mp3', 'wav', 'sound', 'ringtone'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/audio-cutter/',
    supportedFormats: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4', 'audio/webm'],
    maxFileSizeMB: 80,
  },
  {
    id: 'audio-volume',
    name: 'Audio Volume Changer',
    shortDescription: 'Tingkatkan atau turunkan volume audio (25% hingga 200%)',
    description:
      'Atur kekuatan suara file audio atau video dengan penguatan gain preset (25% - 200%) atau nilai kustom.',
    icon: 'Volume2',
    category: 'audio',
    tags: ['audio', 'volume', 'boost', 'gain', 'loudness', 'amplify'],
    requiresAI: false,
    requiresFFmpeg: true,
    path: '/tools/audio-volume/',
    supportedFormats: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4'],
    maxFileSizeMB: 80,
  },
  {
    id: 'bpm-detector',
    name: 'BPM Detector',
    shortDescription: 'Deteksi tempo lagu (Beats Per Minute) via Web Audio API',
    description:
      'Analisis frekuensi audio lokal secara otomatis untuk memperkirakan BPM dan ritme musik untuk keperluan JJ / Alight Motion.',
    icon: 'Activity',
    category: 'audio',
    badge: 'JJ / Motion',
    tags: ['bpm', 'tempo', 'beat', 'music', 'analysis', 'jj', 'alight', 'motion'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/bpm-detector/',
    supportedFormats: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'video/mp4'],
    maxFileSizeMB: 50,
  },
  {
    id: 'beat-marker',
    name: 'Beat Marker & Tapper',
    shortDescription: 'Tandai titik beat audio secara manual & ekspor JSON/TXT/CSV',
    description:
      'Putar musik dan tap tombol beat secara real-time. Ekspor daftar timestamp beat dalam format JSON, TXT, atau CSV untuk keyframe editing.',
    icon: 'Bookmark',
    category: 'audio',
    badge: 'Keyframe',
    tags: ['beat', 'marker', 'tap', 'keyframe', 'alight', 'capcut', 'timestamps'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/beat-marker/',
    supportedFormats: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'video/mp4'],
    maxFileSizeMB: 50,
  },

  // --- IMAGE TOOLS ---
  {
    id: 'bg-eraser',
    name: 'Background Eraser',
    shortDescription: 'Hapus background gambar dengan color key & edge matting',
    description:
      'Hapus latar belakang foto atau gambar secara otomatis menggunakan deteksi warna cerdas, chroma key, atau kuas manual dengan hasil transparan beresolusi tinggi.',
    icon: 'Eraser',
    category: 'image',
    badge: 'Local Engine',
    tags: ['image', 'background', 'transparent', 'png', 'photo', 'crop'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/bg-eraser/',
    supportedFormats: ['image/png', 'image/jpeg', 'image/jpg', 'image/webp'],
    maxFileSizeMB: 25,
  },
  {
    id: 'image-compressor',
    name: 'Image Compressor',
    shortDescription: 'Kompres ukuran gambar JPG, PNG, WEBP dengan perbandingan size',
    description:
      'Perkecil ukuran byte foto hingga 80% dengan slider kualitas visual interaktif dan kalkulasi penghematan storage secara instan.',
    icon: 'Minimize2',
    category: 'image',
    badge: 'Fast',
    tags: ['image', 'compress', 'optimize', 'jpg', 'png', 'webp', 'size'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/image-compressor/',
    supportedFormats: ['image/jpeg', 'image/png', 'image/webp'],
    maxFileSizeMB: 50,
  },
  {
    id: 'image-resizer',
    name: 'Image Resizer',
    shortDescription: 'Ubah dimensi piksel dengan rasio terkunci & preset sosial media',
    description:
      'Ubah ukuran lebar dan tinggi gambar dengan aspect ratio lock serta preset 1080x1920, 1920x1080, 1080x1080, 1080x1350, 720x1280.',
    icon: 'Crop',
    category: 'image',
    tags: ['image', 'resize', 'dimension', 'scale', '1080p', '4k', 'social'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/image-resizer/',
    supportedFormats: ['image/jpeg', 'image/png', 'image/webp'],
    maxFileSizeMB: 50,
  },
  {
    id: 'image-converter',
    name: 'Image Converter',
    shortDescription: 'Konversi format PNG ↔ JPG ↔ WEBP secara instan',
    description:
      'Ubah format gambar antar PNG, JPG, dan WEBP dengan kontrol kualitas tanpa kompromi.',
    icon: 'FileImage',
    category: 'image',
    tags: ['image', 'convert', 'format', 'png', 'jpg', 'webp'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/image-converter/',
    supportedFormats: ['image/png', 'image/jpeg', 'image/webp', 'image/bmp'],
    maxFileSizeMB: 50,
  },
  {
    id: 'svg-to-png',
    name: 'SVG to PNG Rasterizer',
    shortDescription: 'Render vektor SVG ke gambar PNG beresolusi tinggi (512 - 4096px)',
    description:
      'Konversi file vektor SVG menjadi PNG tajam dengan mempertahankan transparansi latar belakang dan resolusi kustom hingga 4K.',
    icon: 'FileCode',
    category: 'image',
    tags: ['svg', 'png', 'vector', 'raster', 'transparent', 'resolution', '4k'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/svg-to-png/',
    supportedFormats: ['image/svg+xml'],
    maxFileSizeMB: 20,
  },
  {
    id: 'svg-optimizer',
    name: 'SVG Optimizer',
    shortDescription: 'Bersihkan metadata dan optimasi kode SVG tanpa merusak tampilan',
    description:
      'Pangkas tag berlebih, komentar editor, dan ruang kosong pada berkas SVG dengan perbandingan ukuran sebelum dan sesudah.',
    icon: 'FileCode',
    category: 'image',
    tags: ['svg', 'optimize', 'minify', 'clean', 'vector', 'code'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/svg-optimizer/',
    supportedFormats: ['image/svg+xml'],
    maxFileSizeMB: 10,
  },

  // --- DESIGN & CREATOR TOOLS ---
  {
    id: 'alight-motion-exporter',
    name: 'Alight Motion Project Exporter',
    shortDescription: 'Buat & export file project XML resmi Alight Motion (ffver=106)',
    description:
      'Generator berkas XML project asli Alight Motion (Android) dengan dukungan shape, typography, keyframe cubicBezier/elastic, null object 3D perspective, precompose scene, dan multi-stage validation.',
    icon: 'Smartphone',
    category: 'design',
    badge: 'Verified AM',
    tags: ['alight-motion', 'am', 'xml', 'project', 'exporter', 'preset', 'keyframe', 'motion', 'jj', 'bezier', 'easing'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/alight-motion-exporter/',
  },
  {
    id: 'easing-visualizer',
    name: 'Easing & Bezier Visualizer',
    shortDescription: 'Visualisasi kurva transisi Alight Motion, CSS, dan After Effects',
    description:
      'Simulasi kurva bezier interaktif dengan bola animasi uji kecepatan (Ease-In, Ease-Out, JJ Shake) dan salinan kode CSS / AM.',
    icon: 'Activity',
    category: 'design',
    badge: 'Motion Graphic',
    tags: ['easing', 'cubic-bezier', 'curve', 'motion', 'alight', 'after-effects', 'animation', 'jj'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/easing-visualizer/',
  },
  {
    id: 'lut-previewer',
    name: 'LUT & Color Grading Previewer',
    shortDescription: 'Pratinjau filter warna sinematik (Teal & Orange, Moody, Neon, Vintage)',
    description:
      'Terapkan preset filter warna sinematik dengan pengaturan intensitas, exposure, contrast, dan saturation tanpa upload.',
    icon: 'Sparkles',
    category: 'design',
    badge: 'Color Grade',
    tags: ['lut', 'color', 'grading', 'cinematic', 'filter', 'teal-orange', 'moody', 'video'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/lut-previewer/',
  },
  {
    id: 'text-behind-subject',
    name: 'Text Behind Subject',
    shortDescription: 'Efek tipografi teks viral di belakang orang/objek foto',
    description:
      'Buat poster dan thumbnail viral dengan teks tebal 3D yang diposisikan rapi di belakang subjek gambar secara instan.',
    icon: 'Type',
    category: 'design',
    badge: 'Trending JJ',
    tags: ['text', 'typography', 'subject', 'layer', 'thumbnail', 'poster', 'effect'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/text-behind-subject/',
    supportedFormats: ['image/png', 'image/jpeg', 'image/webp'],
  },
  {
    id: 'safe-zone',
    name: 'Safe Zone Overlay Inspector',
    shortDescription: 'Simulator UI TikTok, IG Reels, dan YT Shorts agar teks tidak tertutup',
    description:
      'Uji posisi teks dan elemen visual penting dengan panduan overlay antarmuka resmi TikTok, Instagram Reels, dan YouTube Shorts.',
    icon: 'Eye',
    category: 'design',
    badge: 'Creator Safe',
    tags: ['safe-zone', 'tiktok', 'reels', 'shorts', 'overlay', 'ui', 'guideline'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/safe-zone/',
    supportedFormats: ['image/png', 'image/jpeg', 'image/webp'],
  },
  {
    id: 'solid-background',
    name: 'Solid Color & Green Screen Generator',
    shortDescription: 'Buat background polos (Chroma Green, Black Screen) gambar & video MP4',
    description:
      'Hasilkan background warna solid dengan resolusi HD / 4K dalam format gambar PNG atau video MP4 berdurasi untuk bahan compositing.',
    icon: 'Maximize2',
    category: 'design',
    tags: ['chroma', 'green-screen', 'solid', 'black', 'background', 'generator', 'mp4'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/solid-background/',
  },
  {
    id: 'grid-splitter',
    name: 'Instagram Grid Splitter',
    shortDescription: 'Potong foto panorama menjadi grid rapi (3x3, 3x2, 3x1) + ZIP',
    description:
      'Bagi foto lanskap atau karya desain menjadi potongan grid terurut untuk feed Instagram dengan download paket ZIP langsung.',
    icon: 'Grid',
    category: 'design',
    tags: ['grid', 'splitter', 'instagram', 'feed', '3x3', 'panorama', 'crop', 'zip'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/grid-splitter/',
    supportedFormats: ['image/png', 'image/jpeg', 'image/webp'],
  },
  {
    id: 'text-to-png',
    name: 'Text to PNG Generator',
    shortDescription: 'Buat stiker teks transparan dengan shadow, stroke & glow untuk overlay',
    description:
      'Desain teks tipografi dengan font kustom, outline tebal, shadow, dan glow untuk bahan teks motion graphic dan video editor.',
    icon: 'Type',
    category: 'design',
    badge: 'Motion Asset',
    tags: ['text', 'typography', 'png', 'overlay', 'stroke', 'glow', 'sticker', 'motion'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/text-to-png/',
  },
  {
    id: 'color-picker',
    name: 'Color Picker & Inspector',
    shortDescription: 'Pemilih warna presisi HEX, RGB, HSL, HSV & riwayat palet',
    description:
      'Salin kode warna dalam berbagai format standar desain, simpan riwayat warna favorit, dan uji kontras warna.',
    icon: 'Pipette',
    category: 'design',
    tags: ['color', 'picker', 'hex', 'rgb', 'hsl', 'hsv', 'palette', 'inspector'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/color-picker/',
  },
  {
    id: 'gradient-generator',
    name: 'Gradient Generator',
    shortDescription: 'Buat gradasi Linear & Radial dengan kode CSS dan ekspor PNG',
    description:
      'Desain transisi warna multi-stop gradasi yang halus, putar sudut derajat, dan unduh sebagai gambar PNG atau salin CSS.',
    icon: 'Palette',
    category: 'design',
    tags: ['gradient', 'linear', 'radial', 'css', 'colors', 'background'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/gradient-generator/',
  },
  {
    id: 'color-palette',
    name: 'Color Palette Generator',
    shortDescription: 'Hasilkan harmoni warna (Complementary, Analogous, Triadic, dll.)',
    description:
      'Temukan skema warna serasi berdasarkan teori warna grafis untuk branding dan color grading visual video.',
    icon: 'Palette',
    category: 'design',
    tags: ['palette', 'harmony', 'complementary', 'analogous', 'triadic', 'scheme'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/color-palette/',
  },

  // --- UTILITY TOOLS ---
  {
    id: 'timestamp-converter',
    name: 'Timestamp Converter & Generator',
    shortDescription: 'Konversi Unix epoch, ISO 8601, tanggal lokal, dan video timecode',
    description:
      'Konversi epoch timestamp detik/ms ke tanggal lokal (WIB), ISO 8601, waktu relatif, dan SMPTE frame timecode untuk sinkronisasi keyframe Alight Motion.',
    icon: 'Clock',
    category: 'utility',
    badge: 'Offline Helper',
    tags: ['timestamp', 'epoch', 'unix', 'time', 'date', 'iso', 'timecode', 'keyframe'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/timestamp-converter/',
  },
  {
    id: 'json-formatter',
    name: 'JSON Formatter & Validator',
    shortDescription: 'Format, validasi sintaks dengan baris error, konversi ke YAML & auto-fix',
    description:
      'Format struktur JSON menjadi rapi dan mudah dibaca, periksa kesalahan sintaks dengan penanda baris, konversi ke YAML, perbaiki kutip otomatis, dan jelajahi pohon hirarki data.',
    icon: 'FileJson',
    category: 'utility',
    badge: 'Dev & Creator',
    tags: ['json', 'formatter', 'validator', 'minify', 'beautify', 'yaml', 'tree', 'code'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/json-formatter/',
  },
  {
    id: 'url-params-tool',
    name: 'URL Parameter & Query Builder',
    shortDescription: 'Uraikan & kelola parameter URL, decode/encode, serta bangun tautan UTM',
    description:
      'Kelola query parameter URL secara visual, edit key-value, encode/decode string, dan buat tautan campaign UTM tracker untuk media sosial.',
    icon: 'Link2',
    category: 'utility',
    badge: 'URL & UTM',
    tags: ['url', 'parameter', 'query', 'utm', 'encode', 'decode', 'link', 'campaign'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/url-params-tool/',
  },
  {
    id: 'keyframe-calculator',
    name: 'Beat to Keyframe Calculator',
    shortDescription: 'Hitung interval keyframe & frame number eksak berdasarkan BPM dan target FPS',
    description:
      'Kalkulasi jeda waktu ketukan musik per ketukan (1/1, 1/2, 1/4 beat) ke jumlah frame tepat untuk Alight Motion dan CapCut.',
    icon: 'Sliders',
    category: 'utility',
    badge: 'JJ Calc',
    tags: ['keyframe', 'calculator', 'bpm', 'fps', 'frame', 'alight', 'capcut', 'jj'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/keyframe-calculator/',
  },
  {
    id: 'aspect-calculator',
    name: 'Aspect Ratio & Bitrate Calculator',
    shortDescription: 'Kalkulator resolusi piksel & estimasi ukuran file video',
    description:
      'Hitung dimensi lebar dan tinggi proporsional serta perkirakan ukuran file akhir video berdasarkan bitrate dan durasi.',
    icon: 'Maximize2',
    category: 'utility',
    tags: ['aspect', 'ratio', 'calculator', 'bitrate', 'file-size', 'dimension'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/aspect-calculator/',
  },
  {
    id: 'media-info',
    name: 'Media Metadata Inspector',
    shortDescription: 'Inspeksi detail resolusi, codec, FPS, bitrate, dan durasi file media',
    description:
      'Periksa spesifikasi teknis mendalam berkas video, audio, dan gambar secara instan tanpa perlu upload ke server.',
    icon: 'Info',
    category: 'utility',
    tags: ['media-info', 'metadata', 'inspector', 'codec', 'resolution', 'fps', 'bitrate'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/media-info/',
    supportedFormats: ['video/mp4', 'video/webm', 'audio/mpeg', 'audio/wav', 'image/png', 'image/jpeg'],
  },
  {
    id: 'qr-generator',
    name: 'QR Code Generator',
    shortDescription: 'Buat QR Code instan URL, Teks, WiFi, WA, Email, SMS dengan SVG & PNG',
    description:
      'Hasilkan QR Code instan dengan kustomisasi warna, margin, level koreksi kesalahan, serta download format PNG dan SVG vektor.',
    icon: 'QrCode',
    category: 'utility',
    tags: ['qr', 'code', 'generator', 'link', 'svg', 'barcode', 'wifi', 'sms', 'wa'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/qr-generator/',
  },
  {
    id: 'frame-extractor',
    name: 'Timestamp Frame Extractor',
    shortDescription: 'Ambil snapshot frame video pada timestamp waktu tertentu (00:00.000)',
    description:
      'Tentukan waktu spesifik hingga milidetik pada video untuk menangkap thumbnail atau frame gambar beresolusi penuh.',
    icon: 'Camera',
    category: 'utility',
    tags: ['frame', 'snapshot', 'thumbnail', 'timestamp', 'capture', 'video'],
    requiresAI: false,
    requiresFFmpeg: false,
    path: '/tools/frame-extractor/',
    supportedFormats: ['video/mp4', 'video/webm', 'video/quicktime'],
    maxFileSizeMB: 100,
  },
];

export function getToolById(id: string): ToolDefinition | undefined {
  return TOOLS_REGISTRY.find((tool) => tool.id === id);
}

export function getToolsByCategory(category: ToolCategory): ToolDefinition[] {
  return TOOLS_REGISTRY.filter((tool) => tool.category === category);
}

const SYNONYMS: Record<string, string[]> = {
  potong: ['cutter', 'trim', 'cut', 'audio-cutter', 'video-cutter'],
  pangkas: ['cutter', 'trim', 'crop'],
  balik: ['reverse', 'mirror', 'flip'],
  mundur: ['reverse'],
  cermin: ['mirror'],
  putar: ['rotate'],
  kompres: ['compress', 'compressor', 'size', 'kecil'],
  perkecil: ['compress', 'resize'],
  ubah: ['converter', 'resizer'],
  lagu: ['audio', 'mp3', 'music', 'sound', 'suara'],
  suara: ['audio', 'volume', 'mp3', 'mute'],
  musisi: ['audio', 'bpm', 'beat'],
  beat: ['bpm', 'marker', 'keyframe', 'jj', 'jedag'],
  jedag: ['bpm', 'beat', 'easing', 'keyframe', 'motion'],
  jj: ['bpm', 'beat', 'easing', 'keyframe', 'motion', 'shake', 'reverse'],
  transisi: ['easing', 'bezier', 'curve', 'motion'],
  kurva: ['easing', 'bezier'],
  warna: ['color', 'palette', 'gradient', 'lut', 'picker'],
  gradasi: ['gradient'],
  teks: ['text', 'typography', 'font'],
  tulisan: ['text'],
  vektor: ['svg'],
  gambar: ['image', 'photo', 'png', 'jpg', 'webp'],
  foto: ['image', 'photo', 'bg-eraser', 'grid-splitter'],
  hapus: ['eraser', 'remove-audio', 'bg-eraser'],
  ekstrak: ['frame-extractor', 'mp4-to-mp3', 'video-to-frames'],
  gabung: ['frames-to-video'],
  qrcode: ['qr', 'barcode'],
  barcode: ['qr'],
  waktu: ['timestamp', 'timecode'],
  kecepatan: ['speed', 'slowmo', 'fast'],
  slowmo: ['speed'],
  fps: ['keyframe-calculator', 'media-info', 'video-speed'],
};

export function searchTools(query: string): ToolDefinition[] {
  const q = query.toLowerCase().trim();
  if (!q) return TOOLS_REGISTRY;

  // Resolve mapped synonyms
  const synonymTerms: string[] = [];
  Object.entries(SYNONYMS).forEach(([key, aliases]) => {
    if (q.includes(key) || key.includes(q)) {
      synonymTerms.push(...aliases);
    }
  });

  return TOOLS_REGISTRY.filter((tool) => {
    const nameMatch = tool.name.toLowerCase().includes(q);
    const shortDescMatch = tool.shortDescription.toLowerCase().includes(q);
    const descMatch = tool.description.toLowerCase().includes(q);
    const catMatch = tool.category.toLowerCase().includes(q);
    const idMatch = tool.id.toLowerCase().includes(q);
    const tagMatch = tool.tags.some((tag) => tag.toLowerCase().includes(q));

    // Check synonym matches
    const synonymMatch = synonymTerms.some(
      (term) =>
        tool.id.toLowerCase().includes(term) ||
        tool.tags.some((t) => t.toLowerCase().includes(term))
    );

    return nameMatch || shortDescMatch || descMatch || catMatch || idMatch || tagMatch || synonymMatch;
  });
}
