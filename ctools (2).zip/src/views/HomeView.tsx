import React, { useState, useEffect } from 'react';
import { TOOLS_REGISTRY, CATEGORIES, searchTools, getToolById } from '../registry/tools';
import { ToolCard } from '../components/common/ToolCard';
import { ToolCategory, ToolDefinition } from '../types';
import { getRecentTools, getFavorites } from '../utils/favorites';
import {
  Search,
  Sparkles,
  Zap,
  Lock,
  Compass,
  ArrowRight,
  Layers,
  History,
  Star,
  Film,
  Music,
  Palette,
  Image as ImageIcon,
  Wrench,
} from 'lucide-react';

interface HomeViewProps {
  onSelectTool: (id: string) => void;
}

const QUICK_ACCESS_IDS = [
  'video-cutter',
  'video-reverse',
  'mp4-to-mp3',
  'easing-visualizer',
  'text-to-png',
  'video-compressor',
  'bpm-detector',
  'safe-zone',
];

export const HomeView: React.FC<HomeViewProps> = ({ onSelectTool }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<ToolCategory | 'all'>('all');
  const [recentToolIds, setRecentToolIds] = useState<string[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);

  const refreshRecentAndFavorites = () => {
    setRecentToolIds(getRecentTools());
    setFavoriteIds(getFavorites());
  };

  useEffect(() => {
    refreshRecentAndFavorites();
  }, []);

  const isFiltering = searchQuery.trim().length > 0 || selectedCategory !== 'all';

  const filteredTools = searchTools(searchQuery).filter(
    (tool) => selectedCategory === 'all' || tool.category === selectedCategory
  );

  const getToolsForCategory = (cat: ToolCategory) => {
    return TOOLS_REGISTRY.filter((t) => t.category === cat);
  };

  const recentTools = recentToolIds
    .map((id) => getToolById(id))
    .filter((t): t is ToolDefinition => t !== undefined);

  const favoriteTools = favoriteIds
    .map((id) => getToolById(id))
    .filter((t): t is ToolDefinition => t !== undefined);

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Header */}
      <section className="relative pt-4 sm:pt-8 pb-4 text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Creator & Motion Graphic Toolbox</span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 dark:text-slate-50">
          Simple tools. <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-blue-600 via-indigo-500 to-cyan-400 bg-clip-text text-transparent">
            Fast results.
          </span>
        </h1>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
          Toolbox lokal tanpa AI untuk editor video, motion graphic, dan kreator konten. Berkas Anda diproses secara privat dan instan di browser.
        </p>

        {/* Search Bar */}
        <div className="pt-2 max-w-xl mx-auto space-y-3">
          <div className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari tool (contoh: potong, reverse, mp3, jj, easing, compress)..."
              className="w-full pl-11 pr-20 py-3 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs sm:text-sm font-medium shadow-md shadow-slate-200/50 dark:shadow-black/20 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-slate-900 dark:text-slate-100"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-slate-100"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center justify-center flex-wrap gap-1.5 pt-1">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                selectedCategory === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              Semua ({TOOLS_REGISTRY.length})
            </button>
            {CATEGORIES.map((cat) => {
              const count = getToolsForCategory(cat.id).length;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {cat.name} ({count})
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Quick Access Strip (only when not actively searching) */}
      {!isFiltering && (
        <section className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span>Akses Cepat (Quick Access)</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
            {QUICK_ACCESS_IDS.map((id) => {
              const tool = getToolById(id);
              if (!tool) return null;
              return (
                <button
                  key={tool.id}
                  onClick={() => onSelectTool(tool.id)}
                  className="p-3 rounded-2xl bg-white dark:bg-slate-900 hover:bg-blue-50 dark:hover:bg-blue-950/20 border border-slate-200/80 dark:border-slate-800/80 text-left transition-all hover:scale-105 shadow-xs flex flex-col justify-between group"
                >
                  <div className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400 truncate">
                    {tool.name}
                  </div>
                  <div className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 uppercase font-semibold">
                    {tool.category}
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      )}

      {/* Recent Tools Row (if any) */}
      {!isFiltering && recentTools.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              <History className="w-3.5 h-3.5 text-blue-500" />
              <span>Baru Saja Dibuka (Recent Tools)</span>
            </div>
            <button
              onClick={() => {
                localStorage.removeItem('ctools_recent_v1');
                setRecentToolIds([]);
              }}
              className="text-[11px] font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              Hapus Riwayat
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {recentTools.map((tool) => (
              <ToolCard
                key={tool.id}
                tool={tool}
                onOpen={onSelectTool}
                onFavoriteToggle={refreshRecentAndFavorites}
              />
            ))}
          </div>
        </section>
      )}

      {/* Favorites Row (if any) */}
      {!isFiltering && favoriteTools.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>Alat Favorit ({favoriteTools.length})</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {favoriteTools.slice(0, 4).map((tool) => (
              <ToolCard
                key={tool.id}
                tool={tool}
                onOpen={onSelectTool}
                onFavoriteToggle={refreshRecentAndFavorites}
              />
            ))}
          </div>
        </section>
      )}

      {/* Filtered View (when searching or category selected) */}
      {isFiltering ? (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <span>Hasil ({filteredTools.length})</span>
            </h2>
          </div>

          {filteredTools.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredTools.map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  onOpen={onSelectTool}
                  onFavoriteToggle={refreshRecentAndFavorites}
                />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
              <Compass className="w-10 h-10 text-slate-400 mx-auto" />
              <p className="font-semibold text-slate-700 dark:text-slate-300 text-sm">
                Tidak ada tool yang cocok dengan pencarian "{searchQuery}"
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                }}
                className="text-xs font-bold text-blue-600 hover:underline cursor-pointer"
              >
                Reset Filter Pencarian
              </button>
            </div>
          )}
        </section>
      ) : (
        /* Category-Grouped Sections */
        <div className="space-y-12">
          {/* Video Category */}
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
                  <Film className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                    Video Editing & Converter
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Potong, balik, kompres, ubah kecepatan, mirror, dan konversi format video
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCategory('video')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Lihat Semua ({getToolsForCategory('video').length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {getToolsForCategory('video').map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  onOpen={onSelectTool}
                  onFavoriteToggle={refreshRecentAndFavorites}
                />
              ))}
            </div>
          </section>

          {/* Audio Category */}
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                  <Music className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                    Audio & Beat Rhythm
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Ekstrak MP3, potong lagu, BPM detector, dan penanda beat jedag-jedug
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCategory('audio')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Lihat Semua ({getToolsForCategory('audio').length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {getToolsForCategory('audio').map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  onOpen={onSelectTool}
                  onFavoriteToggle={refreshRecentAndFavorites}
                />
              ))}
            </div>
          </section>

          {/* Motion & Design Category */}
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-xl bg-pink-500/10 text-pink-600 dark:text-pink-400">
                  <Palette className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                    Motion Graphic & Desain
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Easing bezier Alight Motion, LUT color grading, safe zone TikTok/Reels, text behind subject, dan aset stiker
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCategory('design')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Lihat Semua ({getToolsForCategory('design').length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {getToolsForCategory('design').map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  onOpen={onSelectTool}
                  onFavoriteToggle={refreshRecentAndFavorites}
                />
              ))}
            </div>
          </section>

          {/* Image & Vector Category */}
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                    Gambar & Vektor
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Hapus background, kompres foto, ubah ukuran piksel, dan rasterizer vektor SVG
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCategory('image')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Lihat Semua ({getToolsForCategory('image').length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {getToolsForCategory('image').map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  onOpen={onSelectTool}
                  onFavoriteToggle={refreshRecentAndFavorites}
                />
              ))}
            </div>
          </section>

          {/* Utilities Category */}
          <section className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                    Utilitas & Developer
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Kalkulator keyframe FPS, timecode converter, JSON formatter, URL query & UTM builder, inspeksi metadata
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCategory('utility')}
                className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Lihat Semua ({getToolsForCategory('utility').length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {getToolsForCategory('utility').map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  onOpen={onSelectTool}
                  onFavoriteToggle={refreshRecentAndFavorites}
                />
              ))}
            </div>
          </section>
        </div>
      )}

      {/* Highlights Bar */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <Lock className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
            Privat & 100% Browser-Side
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Berkas video, audio, dan gambar Anda diproses lokal di peramban tanpa pernah diunggah ke server mana pun.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
          <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Zap className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
            Tanpa Kuota & Tanpa Watermark
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Ekspor hasil kualitas asli tanpa batasan kuota harian dan tanpa watermark.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs">
          <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <Layers className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm">
            Dioptimalkan untuk JJ & Motion Graphic
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Alat khusus beat marker, BPM detector, easing bezier visualizer, safe zone TikTok, dan kalkulator keyframe.
          </p>
        </div>
      </section>
    </div>
  );
};
