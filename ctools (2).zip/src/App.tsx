import React, { useState, useEffect, useCallback } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';
import { BottomNav } from './components/common/BottomNav';
import { ToastContainer } from './components/common/ToastContainer';
import { SettingsModal } from './components/common/SettingsModal';
import { HomeView } from './views/HomeView';
import { BgEraserTool } from './tools/bg-eraser/BgEraserTool';
import { VideoReverseTool } from './tools/video-reverse/VideoReverseTool';
import { Mp4ToMp3Tool } from './tools/mp4-to-mp3/Mp4ToMp3Tool';
import { QrGeneratorTool } from './tools/qr-generator/QrGeneratorTool';
import { VideoCutterTool } from './tools/video-cutter/VideoCutterTool';
import { VideoCompressorTool } from './tools/video-compressor/VideoCompressorTool';
import { VideoSpeedTool } from './tools/video-speed/VideoSpeedTool';
import { VideoMirrorTool } from './tools/video-mirror/VideoMirrorTool';
import { VideoRotateTool } from './tools/video-rotate/VideoRotateTool';
import { VideoAspectRatioTool } from './tools/video-aspect-ratio/VideoAspectRatioTool';
import { VideoToGifTool } from './tools/video-to-gif/VideoToGifTool';
import { GifToVideoTool } from './tools/gif-to-video/GifToVideoTool';
import { VideoToFramesTool } from './tools/video-to-frames/VideoToFramesTool';
import { FramesToVideoTool } from './tools/frames-to-video/FramesToVideoTool';
import { VideoRemoveAudioTool } from './tools/video-remove-audio/VideoRemoveAudioTool';
import { AudioCutterTool } from './tools/audio-cutter/AudioCutterTool';
import { AudioVolumeTool } from './tools/audio-volume/AudioVolumeTool';
import { BpmDetectorTool } from './tools/bpm-detector/BpmDetectorTool';
import { BeatMarkerTool } from './tools/beat-marker/BeatMarkerTool';
import { EasingVisualizerTool } from './tools/easing-visualizer/EasingVisualizerTool';
import { LutPreviewerTool } from './tools/lut-previewer/LutPreviewerTool';
import { TextBehindSubjectTool } from './tools/text-behind-subject/TextBehindSubjectTool';
import { GridSplitterTool } from './tools/grid-splitter/GridSplitterTool';
import { SafeZoneTool } from './tools/safe-zone/SafeZoneTool';
import { SolidBackgroundTool } from './tools/solid-background/SolidBackgroundTool';
import { AspectCalculatorTool } from './tools/aspect-calculator/AspectCalculatorTool';
import { MediaInfoTool } from './tools/media-info/MediaInfoTool';
import { KeyframeCalculatorTool } from './tools/keyframe-calculator/KeyframeCalculatorTool';
import { TextToPngTool } from './tools/text-to-png/TextToPngTool';
import { ColorPickerTool } from './tools/color-picker/ColorPickerTool';
import { GradientGeneratorTool } from './tools/gradient-generator/GradientGeneratorTool';
import { ColorPaletteTool } from './tools/color-palette/ColorPaletteTool';
import { ImageCompressorTool } from './tools/image-compressor/ImageCompressorTool';
import { ImageResizerTool } from './tools/image-resizer/ImageResizerTool';
import { ImageConverterTool } from './tools/image-converter/ImageConverterTool';
import { SvgToPngTool } from './tools/svg-to-png/SvgToPngTool';
import { SvgOptimizerTool } from './tools/svg-optimizer/SvgOptimizerTool';
import { TimestampConverterTool } from './tools/timestamp-converter/TimestampConverterTool';
import { JsonFormatterTool } from './tools/json-formatter/JsonFormatterTool';
import { UrlParamsTool } from './tools/url-params-tool/UrlParamsTool';
import { FrameExtractorTool } from './tools/frame-extractor/FrameExtractorTool';
import { AlightMotionExporterTool } from './tools/alight-motion-exporter/AlightMotionExporterTool';
import { AudioSpectrumTool } from './tools/audio-spectrum/AudioSpectrumTool';
import { getToolById, TOOLS_REGISTRY } from './registry/tools';
import { ToolDefinition } from './types';
import { toast } from './utils/toast';
import { recordRecentTool } from './utils/favorites';
import { ErrorBoundary } from './components/common/ErrorBoundary';

function AppContent() {
  const [activeToolId, setActiveToolId] = useState<string | null>(() => {
    const params = new URLSearchParams(window.location.search);
    const toolParam = params.get('tool');
    if (toolParam && getToolById(toolParam)) {
      return toolParam;
    }
    return null;
  });

  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Sync activeToolId with browser URL query parameter `?tool=...`
  const updateUrlParam = useCallback((toolId: string | null) => {
    const url = new URL(window.location.href);
    if (toolId) {
      url.searchParams.set('tool', toolId);
    } else {
      url.searchParams.delete('tool');
    }
    window.history.pushState({}, '', url.toString());
  }, []);

  const handleSelectTool = (id: string | null) => {
    if (id && !getToolById(id)) {
      toast.error('Tool Tidak Ditemukan', `ID tool "${id}" belum terdaftar.`);
      setActiveToolId(null);
      updateUrlParam(null);
      return;
    }
    if (id) {
      recordRecentTool(id);
    }
    setActiveToolId(id);
    updateUrlParam(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle browser back and forward button navigation
  useEffect(() => {
    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const toolParam = params.get('tool');
      if (toolParam && getToolById(toolParam)) {
        setActiveToolId(toolParam);
      } else {
        setActiveToolId(null);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const currentTool: ToolDefinition | undefined = activeToolId
    ? getToolById(activeToolId)
    : undefined;

  const renderToolView = () => {
    switch (activeToolId) {
      case 'bg-eraser':
        return <BgEraserTool />;
      case 'video-reverse':
        return <VideoReverseTool />;
      case 'mp4-to-mp3':
        return <Mp4ToMp3Tool />;
      case 'qr-generator':
        return <QrGeneratorTool />;
      case 'video-cutter':
        return <VideoCutterTool />;
      case 'video-compressor':
        return <VideoCompressorTool />;
      case 'video-speed':
        return <VideoSpeedTool />;
      case 'video-mirror':
        return <VideoMirrorTool />;
      case 'video-rotate':
        return <VideoRotateTool />;
      case 'video-aspect-ratio':
        return <VideoAspectRatioTool />;
      case 'video-to-gif':
        return <VideoToGifTool />;
      case 'gif-to-video':
        return <GifToVideoTool />;
      case 'video-to-frames':
        return <VideoToFramesTool />;
      case 'frames-to-video':
        return <FramesToVideoTool />;
      case 'video-remove-audio':
        return <VideoRemoveAudioTool />;
      case 'audio-cutter':
        return <AudioCutterTool />;
      case 'audio-volume':
        return <AudioVolumeTool />;
      case 'bpm-detector':
        return <BpmDetectorTool />;
      case 'beat-marker':
        return <BeatMarkerTool />;
      case 'easing-visualizer':
        return <EasingVisualizerTool />;
      case 'lut-previewer':
        return <LutPreviewerTool />;
      case 'text-behind-subject':
        return <TextBehindSubjectTool />;
      case 'grid-splitter':
        return <GridSplitterTool />;
      case 'safe-zone':
        return <SafeZoneTool />;
      case 'solid-background':
        return <SolidBackgroundTool />;
      case 'aspect-calculator':
        return <AspectCalculatorTool />;
      case 'media-info':
        return <MediaInfoTool />;
      case 'keyframe-calculator':
        return <KeyframeCalculatorTool />;
      case 'text-to-png':
        return <TextToPngTool />;
      case 'color-picker':
        return <ColorPickerTool />;
      case 'gradient-generator':
        return <GradientGeneratorTool />;
      case 'color-palette':
        return <ColorPaletteTool />;
      case 'image-compressor':
        return <ImageCompressorTool />;
      case 'image-resizer':
        return <ImageResizerTool />;
      case 'image-converter':
        return <ImageConverterTool />;
      case 'svg-to-png':
        return <SvgToPngTool />;
      case 'svg-optimizer':
        return <SvgOptimizerTool />;
      case 'timestamp-converter':
        return <TimestampConverterTool />;
      case 'json-formatter':
        return <JsonFormatterTool />;
      case 'url-params-tool':
      case 'url-params':
        return <UrlParamsTool />;
      case 'frame-extractor':
        return <FrameExtractorTool />;
      case 'alight-motion-exporter':
        return <AlightMotionExporterTool />;
      case 'audio-spectrum':
        return <AudioSpectrumTool />;
      default:
        return <HomeView onSelectTool={handleSelectTool} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg-primary)] text-[var(--text-primary)] antialiased transition-colors">
      {/* Sidebar for desktop & mobile drawer */}
      <Sidebar
        activeToolId={activeToolId}
        onSelectTool={handleSelectTool}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:pl-72 transition-all duration-300">
        {/* Sticky Header */}
        <Header
          currentTool={currentTool}
          onNavigateHome={() => handleSelectTool(null)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
          isSidebarOpen={isSidebarOpen}
        />

        {/* Dynamic Route View */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
          <ErrorBoundary key={activeToolId ?? 'home'} onReset={() => handleSelectTool(null)}>
            {renderToolView()}
          </ErrorBoundary>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-200/80 dark:border-slate-800/80 py-6 px-4 text-center text-xs text-slate-500 dark:text-slate-400">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="font-medium">
              © {new Date().getFullYear()} CTools — Simple tools. Fast results.
            </p>
            <div className="flex items-center gap-4 text-xs font-semibold">
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer"
              >
                Pengaturan
              </button>
              <span>•</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                100% Client-Side Engine
              </span>
            </div>
          </div>
        </footer>
      </div>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeToolId={activeToolId}
        onSelectTool={handleSelectTool}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Global Toast Notifications */}
      <ToastContainer />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}
