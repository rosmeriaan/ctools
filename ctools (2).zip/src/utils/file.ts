export interface FileValidationResult {
  valid: boolean;
  error?: string;
}

export function validateFile(
  file: File,
  allowedTypes?: string[],
  maxSizeMB?: number
): FileValidationResult {
  if (!file) {
    return { valid: false, error: 'Tidak ada file yang dipilih.' };
  }

  if (maxSizeMB && file.size > maxSizeMB * 1024 * 1024) {
    return {
      valid: false,
      error: `Ukuran file terlalu besar (${(file.size / (1024 * 1024)).toFixed(1)} MB). Maksimum adalah ${maxSizeMB} MB.`,
    };
  }

  if (allowedTypes && allowedTypes.length > 0) {
    const fileType = file.type.toLowerCase();
    const fileName = file.name.toLowerCase();
    
    const isAllowed = allowedTypes.some((type) => {
      const cleanType = type.toLowerCase().trim();
      if (cleanType.startsWith('.')) {
        return fileName.endsWith(cleanType);
      }
      if (cleanType.includes('*')) {
        const prefix = cleanType.split('*')[0];
        return fileType.startsWith(prefix);
      }
      return fileType === cleanType;
    });

    if (!isAllowed) {
      return {
        valid: false,
        error: `Format file "${file.type || file.name.split('.').pop()}" tidak didukung. Format yang didukung: ${allowedTypes.join(', ')}.`,
      };
    }
  }

  return { valid: true };
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  setTimeout(() => {
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }, 100);
}

export function downloadTextFile(text: string, filename: string, mimeType = 'text/plain'): void {
  const blob = new Blob([text], { type: mimeType });
  downloadBlob(blob, filename);
}

export function downloadDataUrl(dataUrl: string, filename: string): void {
  const anchor = document.createElement('a');
  anchor.href = dataUrl;
  anchor.download = filename;
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  setTimeout(() => {
    document.body.removeChild(anchor);
  }, 100);
}

export function createObjectURL(fileOrBlob: Blob | File): string {
  return URL.createObjectURL(fileOrBlob);
}

export function revokeObjectURL(url: string | null | undefined): void {
  if (url && url.startsWith('blob:')) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      // ignore
    }
  }
}

export function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Gagal membaca file sebagai data URL'));
    reader.readAsDataURL(file);
  });
}

export function readFileAsArrayBuffer(file: File): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as ArrayBuffer);
    reader.onerror = () => reject(new Error('Gagal membaca file sebagai ArrayBuffer'));
    reader.readAsArrayBuffer(file);
  });
}

export async function copyImageToClipboard(blob: Blob): Promise<boolean> {
  try {
    if (!navigator.clipboard || !window.ClipboardItem) {
      return false;
    }
    const item = new ClipboardItem({ [blob.type]: blob });
    await navigator.clipboard.write([item]);
    return true;
  } catch (err) {
    console.error('Failed to copy image to clipboard', err);
    return false;
  }
}
