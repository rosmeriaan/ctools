const FAVORITES_KEY = 'ctools_favorites_v1';
const RECENT_KEY = 'ctools_recent_v1';

export function getFavorites(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITES_KEY);
    return raw ? JSON.parse(raw) : ['video-reverse', 'mp4-to-mp3', 'video-cutter', 'bg-eraser'];
  } catch {
    return ['video-reverse', 'mp4-to-mp3', 'video-cutter', 'bg-eraser'];
  }
}

export function toggleFavorite(toolId: string): string[] {
  const current = getFavorites();
  const exists = current.includes(toolId);
  const updated = exists ? current.filter((id) => id !== toolId) : [...current, toolId];
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return updated;
}

export function isFavorite(toolId: string): boolean {
  return getFavorites().includes(toolId);
}

export function getRecentTools(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function recordRecentTool(toolId: string): string[] {
  const current = getRecentTools().filter((id) => id !== toolId);
  const updated = [toolId, ...current].slice(0, 5); // maximum 5 recent
  try {
    localStorage.setItem(RECENT_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return updated;
}
