import React, { useState } from 'react';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { ProcessingState } from '../../types';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { Images, Download, Film, Trash2, Upload, Plus } from 'lucide-react';

interface FrameItem {
  id: string;
  name: string;
  dataUrl: string;
  file: File;
}

export const FramesToVideoTool: React.FC = () => {
  const [frames, setFrames] = useState<FrameItem[]>([]);
  const [fps, setFps] = useState<number>(24);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap membuat video dari frame',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const handleFilesAdded = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = e.target.files ? Array.from(e.target.files) : [];
    if (files.length === 0) return;

    // sort naturally by filename
    files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

    const newItems: FrameItem[] = files.map((file, i) => ({
      id: `${Date.now()}-${i}-${file.name}`,
      name: file.name,
      dataUrl: URL.createObjectURL(file),
      file,
    }));

    setFrames((prev) => [...prev, ...newItems]);
  };

  const handleRemove = (id: string) => {
    setFrames((prev) => prev.filter((f) => f.id !== id));
  };

  const handleClearAll = () => {
    frames.forEach((f) => URL.revokeObjectURL(f.dataUrl));
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFrames([]);
    setOutputBlob(null);
    setOutputUrl('');
  };

  const handleRenderVideo = async () => {
    if (frames.length < 2) {
      toast.warning('Frame Kurang', 'Masukkan minimal 2 gambar frame.');
      return;
    }

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan encoder FFmpeg...',
      step: 'preparing',
    });

    try {
      const inputs = frames.map((f, i) => {
        const ext = f.name.split('.').pop() || 'png';
        const num = String(i + 1).padStart(5, '0');
        return {
          name: `img_${num}.${ext}`,
          data: f.file,
        };
      });

      const firstExt = frames[0].name.split('.').pop() || 'png';
      const outputName = 'slideshow.mp4';

      const args = [
        '-framerate',
        fps.toString(),
        '-i',
        `img_%05d.${firstExt}`,
        '-c:v',
        'libx264',
        '-pix_fmt',
        'yuv420p',
        '-preset',
        'ultrafast',
        outputName,
      ];

      const blob = await runFFmpegProcess({
        inputs,
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Merender video (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Video berhasil dibuat!',
        step: 'completed',
      });
      toast.success('Berhasil', 'Video berhasil digenerate dari frame gambar.');
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal membuat video.',
        step: 'error',
        error: err?.message,
      });
      toast.error('Gagal', err?.message || 'Gagal membuat video.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob) return;
    downloadBlob(outputBlob, 'ctools-frames-animation.mp4');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Images className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Frames to Video</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Timelapse / Stopmotion
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Gabungkan rangkaian urutan gambar menjadi animasi video MP4 dengan pilihan FPS.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Daftar Frame ({frames.length} Gambar)
              </h3>
              {frames.length > 0 && (
                <button
                  onClick={handleClearAll}
                  className="text-xs text-red-500 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Hapus Semua</span>
                </button>
              )}
            </div>

            <label className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer transition-colors text-center">
              <input
                type="file"
                multiple
                accept="image/png,image/jpeg,image/webp"
                onChange={handleFilesAdded}
                className="hidden"
              />
              <Upload className="w-8 h-8 text-blue-500 mb-2" />
              <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                Tambah Gambar Frame (PNG / JPG / WEBP)
              </span>
              <span className="text-xs text-slate-400 mt-1">
                Pilih beberapa file sekaligus. Nama file akan diurutkan otomatis.
              </span>
            </label>

            {frames.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5 max-h-80 overflow-y-auto p-1">
                {frames.map((f, idx) => (
                  <div
                    key={f.id}
                    className="relative group rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 aspect-square bg-slate-100 dark:bg-slate-950 flex items-center justify-center"
                  >
                    <img src={f.dataUrl} alt={f.name} className="w-full h-full object-cover" />
                    <div className="absolute top-1 left-1 px-1.5 py-0.2 text-[9px] font-bold rounded-md bg-black/70 text-white font-mono">
                      #{idx + 1}
                    </div>
                    <button
                      onClick={() => handleRemove(f.id)}
                      className="absolute top-1 right-1 p-1 rounded-md bg-red-600/80 hover:bg-red-600 text-white opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Pengaturan Video Output:
            </h3>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Frame Rate (FPS):
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[5, 12, 24, 30, 60].map((f) => (
                  <button
                    key={f}
                    onClick={() => setFps(f)}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                      fps === f
                        ? 'border-blue-600 bg-blue-600 text-white shadow-xs'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {f} FPS
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs flex justify-between items-center text-slate-600 dark:text-slate-300">
              <span>Perkiraan Durasi Video:</span>
              <span className="font-mono font-bold text-blue-600">
                {frames.length > 0 ? (frames.length / fps).toFixed(2) : 0} detik
              </span>
            </div>

            {processing.isProcessing && (
              <ProgressBar
                progress={processing.progress}
                statusText={processing.statusText}
                isIndeterminate={processing.step === 'preparing'}
              />
            )}

            {outputUrl ? (
              <div className="space-y-3">
                <div className="rounded-xl overflow-hidden bg-black aspect-video">
                  <video src={outputUrl} controls loop autoPlay className="w-full h-full object-contain" />
                </div>
                <button
                  onClick={handleDownload}
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Video ({formatFileSize(outputBlob?.size || 0)})</span>
                </button>
              </div>
            ) : (
              <button
                onClick={handleRenderVideo}
                disabled={processing.isProcessing || frames.length < 2}
                className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
              >
                <Film className="w-4 h-4" />
                <span>{processing.isProcessing ? 'Merender Video...' : 'Gabungkan Jadi Video'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
