import React, { useState, useRef } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { FFmpegCommands } from '../../core/ffmpeg/commands';
import { FlipHorizontal, FlipVertical, Film, Download } from 'lucide-react';

export const VideoMirrorTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [mode, setMode] = useState<'horizontal' | 'vertical' | 'both'>('horizontal');

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap mirror video',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const handleFileSelect = (selectedFile: File) => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setVideoUrl(url);
    setOutputBlob(null);
    setOutputUrl('');

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleMirror = async () => {
    if (!file) return;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan engine FFmpeg...',
      step: 'preparing',
    });

    try {
      const inputExt = file.name.split('.').pop() || 'mp4';
      const inputName = `input.${inputExt}`;
      const outputName = 'mirrored.mp4';

      const args = FFmpegCommands.mirrorVideo(inputName, outputName, mode);

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Membalikkan video (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Video berhasil di-mirror!',
        step: 'completed',
      });
      toast.success('Berhasil', 'Video berhasil di-mirror.');
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal memproses video.',
        step: 'error',
        error: err?.message || 'Error',
      });
      toast.error('Gagal', err?.message || 'Gagal membalikkan video.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob || !file) return;
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    downloadBlob(outputBlob, `ctools-mirrored-${mode}-${baseName}.mp4`);
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setVideoUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <FlipHorizontal className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Video Mirror & Flip</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Horizontal & Vertikal
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Balikkan orientasi kamera selfie atau mirror video secara offline.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['video/mp4', 'video/webm', 'video/quicktime']}
          maxSizeMB={150}
          title="Pilih Video untuk Di-mirror"
          description="Mendukung MP4, WebM, MOV hingga 150 MB"
          icon={<Film className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                <video
                  src={videoUrl}
                  controls
                  className={`w-full h-full object-contain ${
                    mode === 'horizontal'
                      ? 'scale-x-[-1]'
                      : mode === 'vertical'
                      ? 'scale-y-[-1]'
                      : 'scale-[-1]'
                  }`}
                />
              </div>
              <p className="text-[11px] text-slate-400 text-center mt-2">
                *Pratinjau CSS real-time sesuai mode yang dipilih
              </p>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Pilih Arah Mirror / Flip:
              </h3>

              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { id: 'horizontal', name: 'Horizontal (Kiri ↔ Kanan)', icon: FlipHorizontal },
                  { id: 'vertical', name: 'Vertikal (Atas ↕ Bawah)', icon: FlipVertical },
                  { id: 'both', name: 'Keduanya (180°)', icon: FlipHorizontal },
                ].map((item) => {
                  const Icon = item.icon;
                  const isSel = mode === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setMode(item.id as any)}
                      className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center gap-2 ${
                        isSel
                          ? 'border-blue-600 bg-blue-600/10 text-blue-600 dark:text-blue-400 font-bold'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-xs">{item.name}</span>
                    </button>
                  );
                })}
              </div>

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputUrl ? (
                <div className="space-y-3">
                  <div className="rounded-xl overflow-hidden bg-black aspect-video">
                    <video src={outputUrl} controls className="w-full h-full object-contain" />
                  </div>
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Video Hasil ({formatFileSize(outputBlob?.size || 0)})</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleMirror}
                  disabled={processing.isProcessing}
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                >
                  <FlipHorizontal className="w-4 h-4" />
                  <span>{processing.isProcessing ? 'Memproses Video...' : 'Terapkan Mirror Video'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
