import React, { useState, useEffect } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import { downloadTextFile } from '../../utils/file';
import {
  Clock,
  Copy,
  Check,
  RefreshCw,
  Play,
  Pause,
  Calendar,
  Layers,
  Download,
  Share2,
  Sliders,
  Sparkles,
} from 'lucide-react';

export const TimestampConverterTool: React.FC = () => {
  const [liveEpoch, setLiveEpoch] = useState<number>(Math.floor(Date.now() / 1000));
  const [isLiveActive, setIsLiveActive] = useState<boolean>(true);

  // Conversion Inputs
  const [inputTimestamp, setInputTimestamp] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('ts') || String(Math.floor(Date.now() / 1000));
  });

  const [dateInput, setDateInput] = useState<string>(() => {
    const now = new Date();
    const tzOffset = now.getTimezoneOffset() * 60000;
    const localISOTime = new Date(now.getTime() - tzOffset).toISOString().slice(0, 19);
    return localISOTime;
  });

  const [fps, setFps] = useState<number>(60);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Live epoch counter
  useEffect(() => {
    if (!isLiveActive) return;
    const timer = setInterval(() => {
      setLiveEpoch(Math.floor(Date.now() / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, [isLiveActive]);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    toast.success('Disalin', `"${text}" berhasil disalin ke clipboard.`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const setTimestampToNow = () => {
    const now = Math.floor(Date.now() / 1000);
    setInputTimestamp(String(now));
    toast.info('Diperbarui', 'Timestamp diatur ke waktu sekarang.');
  };

  // Parse input timestamp
  const getParsedTimestampData = () => {
    const raw = inputTimestamp.trim();
    if (!raw) return null;

    let num = Number(raw);
    if (isNaN(num)) return null;

    // Check if seconds or milliseconds
    let isMillis = raw.length >= 13;
    let millis = isMillis ? num : num * 1000;
    const date = new Date(millis);

    if (isNaN(date.getTime())) return null;

    // Video timecode calculation
    const totalSec = millis / 1000;
    const hours = Math.floor(totalSec / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = Math.floor(totalSec % 60);
    const fractionMs = Math.floor(millis % 1000);
    const frameIndex = Math.floor((fractionMs / 1000) * fps);

    const pad = (n: number, z = 2) => String(n).padStart(z, '0');
    const timecodeSMPTE = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}:${pad(frameIndex)}`;
    const timecodeSimple = `${pad(minutes)}:${pad(seconds)}.${pad(fractionMs, 3)}`;

    // Relative time
    const diffSec = Math.round((Date.now() - millis) / 1000);
    let relativeStr = '';
    const rtf = new Intl.RelativeTimeFormat('id', { numeric: 'auto' });
    if (Math.abs(diffSec) < 60) relativeStr = rtf.format(-diffSec, 'second');
    else if (Math.abs(diffSec) < 3600) relativeStr = rtf.format(-Math.round(diffSec / 60), 'minute');
    else if (Math.abs(diffSec) < 86400) relativeStr = rtf.format(-Math.round(diffSec / 3600), 'hour');
    else relativeStr = rtf.format(-Math.round(diffSec / 86400), 'day');

    return {
      rawSeconds: isMillis ? Math.floor(num / 1000) : num,
      rawMillis: isMillis ? num : num * 1000,
      isoUtc: date.toISOString(),
      utcString: date.toUTCString(),
      localString: date.toLocaleString('id-ID', {
        dateStyle: 'full',
        timeStyle: 'long',
      }),
      localWib: new Intl.DateTimeFormat('id-ID', {
        timeZone: 'Asia/Jakarta',
        dateStyle: 'medium',
        timeStyle: 'medium',
      }).format(date) + ' (WIB / GMT+7)',
      relativeStr,
      timecodeSMPTE,
      timecodeSimple,
      totalFrames: Math.floor(totalSec * fps),
    };
  };

  // Convert Date Picker to Timestamp
  const getConvertedDateTimestamp = () => {
    if (!dateInput) return null;
    const d = new Date(dateInput);
    if (isNaN(d.getTime())) return null;
    return {
      seconds: Math.floor(d.getTime() / 1000),
      millis: d.getTime(),
      iso: d.toISOString(),
    };
  };

  const parsedData = getParsedTimestampData();
  const dateConverted = getConvertedDateTimestamp();

  const handleShareLink = () => {
    const url = new URL(window.location.href);
    url.searchParams.set('tool', 'timestamp-converter');
    if (inputTimestamp) url.searchParams.set('ts', inputTimestamp);
    navigator.clipboard.writeText(url.toString());
    toast.success('Tautan Disalin', 'URL parameter timestamp berhasil disalin.');
  };

  const handleExportJson = () => {
    if (!parsedData) return;
    const payload = JSON.stringify(parsedData, null, 2);
    downloadTextFile(payload, `timestamp-${parsedData.rawSeconds}.json`, 'application/json');
    toast.success('Berhasil', 'File JSON timestamp berhasil diunduh.');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Clock className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Timestamp Converter & Generator</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              100% Offline
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Konversi epoch Unix timestamp ke tanggal lokal, ISO 8601, UTC, timecode video & keyframe JJ, serta URL parameter generator.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleShareLink}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
            title="Bagikan Tautan dengan Parameter URL"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Bagikan Link</span>
          </button>
          <PrivacyBadge compact />
        </div>
      </div>

      {/* Live Unix Epoch Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs font-medium text-blue-100">Live Current Unix Epoch (Detik)</div>
            <div className="text-2xl sm:text-3xl font-mono font-black tracking-wider">
              {liveEpoch}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsLiveActive(!isLiveActive)}
            className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            {isLiveActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isLiveActive ? 'Pause' : 'Resume'}</span>
          </button>
          <button
            onClick={() => copyToClipboard(String(liveEpoch), 'live')}
            className="px-3 py-1.5 rounded-lg bg-white text-blue-700 hover:bg-blue-50 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            {copiedKey === 'live' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Salin Epoch Sekarang</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 1: Convert Timestamp -> Human Date */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-blue-500" />
              <span>1. Konversi Unix Timestamp ke Tanggal</span>
            </h3>
            <button
              onClick={setTimestampToNow}
              className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Gunakan Sekarang</span>
            </button>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Masukkan Nilai Timestamp (Detik atau Milidetik):
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={inputTimestamp}
                onChange={(e) => setInputTimestamp(e.target.value)}
                placeholder="Contoh: 1700000000 atau 1700000000000"
                className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={() => setInputTimestamp(String(liveEpoch))}
                className="px-3 py-2 text-xs font-bold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
              >
                Now
              </button>
            </div>
          </div>

          {parsedData ? (
            <div className="space-y-3 pt-2">
              {/* Local Date */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Waktu Lokal (WIB)</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                    {parsedData.localWib}
                  </div>
                </div>
                <button
                  onClick={() => copyToClipboard(parsedData.localWib, 'localWib')}
                  className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500"
                  title="Salin"
                >
                  {copiedKey === 'localWib' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* ISO 8601 UTC */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">ISO 8601 Format (UTC)</div>
                  <div className="text-xs font-mono font-bold text-slate-800 dark:text-slate-200">
                    {parsedData.isoUtc}
                  </div>
                </div>
                <button
                  onClick={() => copyToClipboard(parsedData.isoUtc, 'isoUtc')}
                  className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500"
                  title="Salin"
                >
                  {copiedKey === 'isoUtc' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Relative Time */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Waktu Relatif</div>
                  <div className="text-xs sm:text-sm font-semibold text-blue-600 dark:text-blue-400 capitalize">
                    {parsedData.relativeStr}
                  </div>
                </div>
                <button
                  onClick={() => copyToClipboard(parsedData.relativeStr, 'relative')}
                  className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500"
                  title="Salin"
                >
                  {copiedKey === 'relative' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                <button
                  onClick={handleExportJson}
                  className="flex-1 py-2 px-3 text-xs font-semibold rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Ekspor JSON Data</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="p-4 text-center text-xs text-rose-500 bg-rose-50 dark:bg-rose-950/20 rounded-xl border border-rose-200 dark:border-rose-900/30">
              Format timestamp tidak valid. Masukkan angka Unix epoch (misal: 1700000000).
            </div>
          )}
        </div>

        {/* Section 2: Date Picker -> Unix Timestamp */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-500" />
            <span>2. Buat Timestamp dari Tanggal Kalender</span>
          </h3>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Pilih Tanggal & Jam Lokal:
            </label>
            <input
              type="datetime-local"
              value={dateInput}
              onChange={(e) => setDateInput(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {dateConverted && (
            <div className="space-y-3 pt-2">
              {/* Epoch Seconds */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Epoch Timestamp (Detik)</div>
                  <div className="text-base font-mono font-black text-blue-600 dark:text-blue-400">
                    {dateConverted.seconds}
                  </div>
                </div>
                <button
                  onClick={() => copyToClipboard(String(dateConverted.seconds), 'dateSec')}
                  className="px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs font-bold flex items-center gap-1.5"
                >
                  {copiedKey === 'dateSec' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Salin Detik</span>
                </button>
              </div>

              {/* Epoch Milliseconds */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Epoch Timestamp (Milidetik)</div>
                  <div className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200">
                    {dateConverted.millis}
                  </div>
                </div>
                <button
                  onClick={() => copyToClipboard(String(dateConverted.millis), 'dateMs')}
                  className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-1.5"
                >
                  {copiedKey === 'dateMs' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Salin Ms</span>
                </button>
              </div>
            </div>
          )}

          {/* Quick Presets */}
          <div className="pt-2">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2">Preset Cepat:</div>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  const now = new Date();
                  const offset = now.getTimezoneOffset() * 60000;
                  setDateInput(new Date(now.getTime() - offset).toISOString().slice(0, 19));
                }}
                className="py-1.5 px-2 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
              >
                Hari Ini
              </button>
              <button
                onClick={() => {
                  const t = new Date(Date.now() + 86400000);
                  const offset = t.getTimezoneOffset() * 60000;
                  setDateInput(new Date(t.getTime() - offset).toISOString().slice(0, 19));
                }}
                className="py-1.5 px-2 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
              >
                Besok (+1 Hari)
              </button>
              <button
                onClick={() => {
                  const t = new Date(Date.now() + 7 * 86400000);
                  const offset = t.getTimezoneOffset() * 60000;
                  setDateInput(new Date(t.getTime() - offset).toISOString().slice(0, 19));
                }}
                className="py-1.5 px-2 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
              >
                +1 Minggu
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Video & Keyframe JJ Timecode Calculator Card */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-500" />
              <span>Video Editor & Motion Graphics Timecode Sync (Alight Motion / CapCut / Premiere)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Hitung frame number eksak berdasarkan target frame rate (FPS) proyek video Anda.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">Target FPS:</span>
            <div className="flex gap-1">
              {[24, 30, 60, 120].map((f) => (
                <button
                  key={f}
                  onClick={() => setFps(f)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    fps === f
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {f} fps
                </button>
              ))}
            </div>
          </div>
        </div>

        {parsedData && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="p-3.5 rounded-xl bg-emerald-500/5 dark:bg-emerald-950/20 border border-emerald-500/20">
              <div className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400">
                SMPTE Timecode (HH:MM:SS:FF)
              </div>
              <div className="text-base sm:text-lg font-mono font-black text-emerald-800 dark:text-emerald-300 mt-1">
                {parsedData.timecodeSMPTE}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Format standar NLE / CapCut</div>
            </div>

            <div className="p-3.5 rounded-xl bg-blue-500/5 dark:bg-blue-950/20 border border-blue-500/20">
              <div className="text-[11px] font-semibold text-blue-700 dark:text-blue-400">
                Millisecond Timecode (MM:SS.mmm)
              </div>
              <div className="text-base sm:text-lg font-mono font-black text-blue-800 dark:text-blue-300 mt-1">
                {parsedData.timecodeSimple}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Format standar Alight Motion keyframe</div>
            </div>

            <div className="p-3.5 rounded-xl bg-indigo-500/5 dark:bg-indigo-950/20 border border-indigo-500/20">
              <div className="text-[11px] font-semibold text-indigo-700 dark:text-indigo-400">
                Total Absolute Frames (@{fps}fps)
              </div>
              <div className="text-base sm:text-lg font-mono font-black text-indigo-800 dark:text-indigo-300 mt-1">
                {parsedData.totalFrames.toLocaleString()} Frames
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Jumlah frame total sejak epoch</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
