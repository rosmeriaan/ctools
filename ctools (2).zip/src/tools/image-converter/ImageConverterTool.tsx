import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  FileImage,
  Upload,
  Download,
  ArrowRight,
  Sliders,
  Sparkles,
  RefreshCw,
} from 'lucide-react';

export const ImageConverterTool: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string>('');
  const [targetFormat, setTargetFormat] = useState<'png' | 'jpeg' | 'webp'>('png');
  const [quality, setQuality] = useState<number>(90);
  const [bgColorForJpg, setBgColorForJpg] = useState<string>('#FFFFFF');
  const [convertedUrl, setConvertedUrl] = useState<string>('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (imageUrl) URL.revokeObjectURL(imageUrl);
    const url = URL.createObjectURL(file);
    setImageFile(file);
    setImageUrl(url);
    setConvertedUrl('');
    toast.success('Gambar Dimuat', `${file.name}`);
  };

  const handleConvert = () => {
    if (!imageUrl || !imageFile) return;

    const img = new Image();
    img.src = imageUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      if (targetFormat === 'jpeg') {
        ctx.fillStyle = bgColorForJpg;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      ctx.drawImage(img, 0, 0);

      const mime = `image/${targetFormat}`;
      const dataUrl = canvas.toDataURL(mime, quality / 100);
      setConvertedUrl(dataUrl);
      toast.success('Konversi Selesai', `Format berhasil diubah ke ${targetFormat.toUpperCase()}.`);
    };
  };

  const handleDownload = () => {
    if (!convertedUrl || !imageFile) return;
    const a = document.createElement('a');
    a.href = convertedUrl;
    const baseName = imageFile.name.replace(/\.[^/.]+$/, '');
    a.download = `${baseName}.${targetFormat === 'jpeg' ? 'jpg' : targetFormat}`;
    a.click();
    toast.success('Diunduh', `File berhasil disimpan.`);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <FileImage className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Image Format Converter (PNG ↔ JPG ↔ WEBP)</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Universal
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ubah format berkas gambar antar PNG, JPG, dan WEBP dengan kontrol kualitas dan warna latar transparan.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!imageUrl ? (
        <div className="p-10 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl bg-white dark:bg-slate-900 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center">
            <Upload className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Pilih Gambar yang Ingin Dikonversi
            </h3>
            <p className="text-xs text-slate-500 mt-1">Mendukung format PNG, JPG, JPEG, WEBP, BMP, GIF.</p>
          </div>
          <label className="inline-block cursor-pointer px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors">
            Pilih Berkas Gambar
            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Format Target Keluaran:
              </label>
              <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                {(['png', 'jpeg', 'webp'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => {
                      setTargetFormat(fmt);
                      setConvertedUrl('');
                    }}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg uppercase transition-all ${
                      targetFormat === fmt
                        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {fmt === 'jpeg' ? 'JPG' : fmt}
                  </button>
                ))}
              </div>
            </div>

            {targetFormat !== 'png' && (
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span>Kualitas:</span>
                  <span className="font-bold text-blue-600">{quality}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={100}
                  value={quality}
                  onChange={(e) => {
                    setQuality(Number(e.target.value));
                    setConvertedUrl('');
                  }}
                  className="w-full accent-blue-600 mt-2"
                />
              </div>
            )}

            {targetFormat === 'jpeg' && (
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Warna Background Pengganti Transparan:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={bgColorForJpg}
                    onChange={(e) => {
                      setBgColorForJpg(e.target.value);
                      setConvertedUrl('');
                    }}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                  />
                  <span className="text-xs font-mono font-bold uppercase">{bgColorForJpg}</span>
                </div>
              </div>
            )}
          </div>

          {/* Action Bar */}
          <div className="flex gap-3">
            <button
              onClick={handleConvert}
              className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Konversi Sekarang ke {targetFormat.toUpperCase()}</span>
            </button>

            {convertedUrl && (
              <button
                onClick={handleDownload}
                className="py-3 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-md transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Hasil</span>
              </button>
            )}
          </div>

          {/* Preview */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-500">Gambar Awal:</div>
              <img
                src={imageUrl}
                alt="Source"
                className="w-full h-64 object-contain rounded-xl bg-slate-50 dark:bg-slate-950 p-2 border border-slate-200 dark:border-slate-800"
              />
            </div>

            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-500">
                Hasil Konversi ({targetFormat.toUpperCase()}):
              </div>
              {convertedUrl ? (
                <img
                  src={convertedUrl}
                  alt="Converted"
                  className="w-full h-64 object-contain rounded-xl bg-slate-50 dark:bg-slate-950 p-2 border border-slate-200 dark:border-slate-800"
                />
              ) : (
                <div className="w-full h-64 flex items-center justify-center text-xs text-slate-400 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                  Klik tombol "Konversi Sekarang" untuk melihat hasil.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
