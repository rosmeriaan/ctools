import React, { useState, useEffect, useCallback, useRef } from 'react';
import { QrEngine, QrErrorCorrectionLevel, QrOptions } from './qrEngine';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { downloadBlob, downloadDataUrl, copyImageToClipboard } from '../../utils/file';
import { toast } from '../../utils/toast';
import {
  QrCode,
  Download,
  Copy,
  Check,
  RotateCcw,
  Globe,
  FileText,
  Wifi,
  Mail,
  Phone,
  MessageSquare,
  Sliders,
  Palette,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';

type QrPresetType = 'url' | 'text' | 'wifi' | 'email' | 'phone' | 'whatsapp';

export const QrGeneratorTool: React.FC = () => {
  const [presetType, setPresetType] = useState<QrPresetType>('url');
  const [inputContent, setInputContent] = useState<string>('https://example.com');

  // WiFi helper state
  const [wifiSsid, setWifiSsid] = useState<string>('MyHomeWiFi');
  const [wifiPass, setWifiPass] = useState<string>('SecretPassword123');
  const [wifiType, setWifiType] = useState<string>('WPA');

  // QR Options
  const [size, setSize] = useState<number>(400);
  const [margin, setMargin] = useState<number>(2);
  const [fgColor, setFgColor] = useState<string>('#0f172a');
  const [bgColor, setBgColor] = useState<string>('#ffffff');
  const [isBgTransparent, setIsBgTransparent] = useState<boolean>(false);
  const [errorCorrection, setErrorCorrection] = useState<QrErrorCorrectionLevel>('M');

  // Output
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [qrSvgString, setQrSvgString] = useState<string>('');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isLinkCopied, setIsLinkCopied] = useState<boolean>(false);

  // Validation
  const isValidUrl = QrEngine.isValidUrl(inputContent);

  // Construct effective payload
  const getPayload = useCallback(() => {
    if (presetType === 'wifi') {
      return `WIFI:S:${wifiSsid};T:${wifiType};P:${wifiPass};;`;
    }
    return inputContent;
  }, [presetType, inputContent, wifiSsid, wifiType, wifiPass]);

  // Generate QR Code on change
  useEffect(() => {
    const payload = getPayload();
    if (!payload || payload.trim() === '') {
      setQrDataUrl('');
      setQrSvgString('');
      return;
    }

    const options: QrOptions = {
      width: size,
      margin: margin,
      color: {
        dark: fgColor,
        light: isBgTransparent ? '#00000000' : bgColor,
      },
      errorCorrectionLevel: errorCorrection,
    };

    let isMounted = true;

    Promise.all([
      QrEngine.generateDataUrl(payload, options),
      QrEngine.generateSvgString(payload, options),
    ])
      .then(([dataUrl, svg]) => {
        if (isMounted) {
          setQrDataUrl(dataUrl);
          setQrSvgString(svg);
        }
      })
      .catch((err) => {
        console.error('QR generation error:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [getPayload, size, margin, fgColor, bgColor, isBgTransparent, errorCorrection]);

  const handleDownloadPng = () => {
    if (!qrDataUrl) return;
    downloadDataUrl(qrDataUrl, 'ctools-qr-code.png');
    toast.success('QR Code Diunduh', 'Berkas ctools-qr-code.png berhasil disimpan.');
  };

  const handleDownloadSvg = () => {
    if (!qrSvgString) return;
    const blob = new Blob([qrSvgString], { type: 'image/svg+xml' });
    downloadBlob(blob, 'ctools-qr-code.svg');
    toast.success('SVG Diunduh', 'Berkas ctools-qr-code.svg berhasil disimpan.');
  };

  const handleCopyImage = async () => {
    if (!qrDataUrl) return;
    try {
      const res = await fetch(qrDataUrl);
      const blob = await res.blob();
      const success = await copyImageToClipboard(blob);
      if (success) {
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2500);
        toast.success('Gambar Disalin', 'QR Code siap ditempel (Ctrl+V) ke aplikasi lain.');
      } else {
        toast.error('Gagal Menyalin', 'Browser Anda tidak mendukung penyalinan gambar otomatis.');
      }
    } catch {
      toast.error('Gagal Menyalin', 'Terjadi kesalahan saat menyalin ke clipboard.');
    }
  };

  const handleCopyLink = () => {
    const payload = getPayload();
    if (!payload) return;
    navigator.clipboard.writeText(payload);
    setIsLinkCopied(true);
    setTimeout(() => setIsLinkCopied(false), 2000);
    toast.info('Teks Disalin', 'Tautan/isi QR Code disalin ke clipboard.');
  };

  const handleClear = () => {
    setInputContent('');
    toast.info('Form Dikosongkan');
  };

  const presetThemes = [
    { name: 'Monochrome', fg: '#0f172a', bg: '#ffffff' },
    { name: 'Ocean Blue', fg: '#1d4ed8', bg: '#eff6ff' },
    { name: 'Emerald', fg: '#047857', bg: '#ecfdf5' },
    { name: 'Violet', fg: '#6d28d9', bg: '#f5f3ff' },
    { name: 'Sunset', fg: '#c2410c', bg: '#fff7ed' },
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <span>QR Code Link Generator</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Vector & PNG
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Buat QR Code instan beresolusi tinggi dengan kustomisasi warna, SVG vektor, dan download cepat.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Content & Customization */}
        <div className="lg:col-span-7 space-y-5">
          {/* Preset Buttons */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 block">
              Tipe Konten
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
              {[
                { id: 'url', label: 'URL', icon: <Globe className="w-3.5 h-3.5" /> },
                { id: 'text', label: 'Teks', icon: <FileText className="w-3.5 h-3.5" /> },
                { id: 'wifi', label: 'WiFi', icon: <Wifi className="w-3.5 h-3.5" /> },
                { id: 'email', label: 'Email', icon: <Mail className="w-3.5 h-3.5" /> },
                { id: 'phone', label: 'Telepon', icon: <Phone className="w-3.5 h-3.5" /> },
                { id: 'whatsapp', label: 'WhatsApp', icon: <MessageSquare className="w-3.5 h-3.5" /> },
              ].map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    setPresetType(p.id as QrPresetType);
                    if (p.id === 'url' && !inputContent.startsWith('http')) {
                      setInputContent('https://example.com');
                    } else if (p.id === 'email' && !inputContent.startsWith('mailto:')) {
                      setInputContent('mailto:hello@example.com?subject=Halo');
                    } else if (p.id === 'phone' && !inputContent.startsWith('tel:')) {
                      setInputContent('tel:+6281234567890');
                    } else if (p.id === 'whatsapp' && !inputContent.includes('wa.me')) {
                      setInputContent('https://wa.me/6281234567890?text=Halo%20Admin');
                    }
                  }}
                  className={`py-2 px-1 rounded-xl text-xs font-semibold flex flex-col items-center gap-1 border transition-all cursor-pointer ${
                    presetType === p.id
                      ? 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-1 ring-blue-500/30'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {p.icon}
                  <span className="text-[11px]">{p.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Input Content Area */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                {presetType === 'url'
                  ? 'Masukkan Tautan / Link URL'
                  : presetType === 'wifi'
                  ? 'Konfigurasi Jaringan WiFi'
                  : 'Isi Teks / Pesan'}
              </label>

              {inputContent && (
                <button
                  onClick={handleClear}
                  className="text-xs text-rose-500 hover:underline cursor-pointer"
                >
                  Kosongkan
                </button>
              )}
            </div>

            {presetType === 'wifi' ? (
              <div className="space-y-3 pt-1">
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Nama WiFi (SSID)</label>
                  <input
                    type="text"
                    value={wifiSsid}
                    onChange={(e) => setWifiSsid(e.target.value)}
                    placeholder="Contoh: MyHomeWiFi"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm font-medium text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Kata Sandi WiFi (Password)</label>
                  <input
                    type="text"
                    value={wifiPass}
                    onChange={(e) => setWifiPass(e.target.value)}
                    placeholder="Password WiFi"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm font-medium text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">Tipe Enkripsi</label>
                  <select
                    value={wifiType}
                    onChange={(e) => setWifiType(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm font-medium text-slate-900 dark:text-slate-100 cursor-pointer"
                  >
                    <option value="WPA">WPA / WPA2 / WPA3 (Umum)</option>
                    <option value="WEP">WEP (Lama)</option>
                    <option value="nopass">Tanpa Sandi (Terbuka)</option>
                  </select>
                </div>
              </div>
            ) : (
              <div>
                <textarea
                  rows={3}
                  value={inputContent}
                  onChange={(e) => setInputContent(e.target.value)}
                  placeholder={presetType === 'url' ? 'https://website-kamu.com' : 'Tuliskan teks di sini...'}
                  className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-sm font-medium text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-hidden transition-all resize-none"
                />

                {presetType === 'url' && inputContent && (
                  <div className="mt-2 flex items-center gap-1.5 text-xs">
                    {isValidUrl ? (
                      <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        URL Valid
                      </span>
                    ) : (
                      <span className="text-amber-600 dark:text-amber-400 flex items-center gap-1 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        Format URL disarankan menyertakan https://
                      </span>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Style Customization */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <Sliders className="w-4 h-4 text-blue-500" />
              <span>Desain & Kustomisasi Warna</span>
            </h3>

            {/* Quick Themes */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                Preset Tema Warna
              </label>
              <div className="flex flex-wrap gap-2">
                {presetThemes.map((t) => (
                  <button
                    key={t.name}
                    onClick={() => {
                      setFgColor(t.fg);
                      setBgColor(t.bg);
                      setIsBgTransparent(false);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 text-xs font-semibold cursor-pointer"
                  >
                    <span
                      className="w-3 h-3 rounded-full border border-black/10"
                      style={{ backgroundColor: t.fg }}
                    />
                    <span className="text-slate-700 dark:text-slate-300">{t.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Color Pickers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300 block mb-1.5">
                  Warna Kode (Foreground)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={fgColor}
                    onChange={(e) => setFgColor(e.target.value)}
                    className="w-9 h-9 rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer p-0.5 bg-transparent"
                  />
                  <input
                    type="text"
                    value={fgColor}
                    onChange={(e) => setFgColor(e.target.value)}
                    className="w-28 px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300 block mb-1.5">
                  Warna Latar (Background)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    disabled={isBgTransparent}
                    value={bgColor}
                    onChange={(e) => setBgColor(e.target.value)}
                    className="w-9 h-9 rounded-lg border border-slate-300 dark:border-slate-700 cursor-pointer p-0.5 bg-transparent disabled:opacity-30"
                  />
                  <label className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={isBgTransparent}
                      onChange={(e) => setIsBgTransparent(e.target.checked)}
                      className="rounded accent-blue-600"
                    />
                    <span>Transparan</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Size & Margin Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-600 dark:text-slate-400">Ukuran Resolusi</span>
                  <span className="text-blue-600 dark:text-blue-400">{size} px</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="800"
                  step="50"
                  value={size}
                  onChange={(e) => setSize(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-600 dark:text-slate-400">Margin / Spasi Tepi</span>
                  <span className="text-blue-600 dark:text-blue-400">{margin} modul</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="6"
                  value={margin}
                  onChange={(e) => setMargin(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>
            </div>

            {/* Error Correction Level */}
            <div className="space-y-1.5 pt-1">
              <label className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                Level Koreksi Kesalahan (Error Correction)
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { level: 'L', name: 'L (7%)', desc: 'Ukuran Minimal' },
                  { level: 'M', name: 'M (15%)', desc: 'Standar' },
                  { level: 'Q', name: 'Q (25%)', desc: 'High Quality' },
                  { level: 'H', name: 'H (30%)', desc: 'Maksimal' },
                ].map((ec) => (
                  <button
                    key={ec.level}
                    onClick={() => setErrorCorrection(ec.level as QrErrorCorrectionLevel)}
                    className={`py-1.5 px-1 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      errorCorrection === ec.level
                        ? 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {ec.name}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Preview Card */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl flex flex-col items-center justify-center text-center space-y-5 sticky top-24">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Live Pratinjau QR Code
            </span>

            {/* QR Canvas Box */}
            <div
              className={`p-4 rounded-2xl border border-slate-200 dark:border-slate-800 transition-all ${
                isBgTransparent ? 'checkerboard-pattern' : ''
              }`}
              style={{
                backgroundColor: !isBgTransparent ? bgColor : undefined,
              }}
            >
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="Generated QR Code"
                  className="w-56 h-56 sm:w-64 sm:h-64 object-contain shadow-xs rounded-lg"
                />
              ) : (
                <div className="w-56 h-56 flex items-center justify-center text-slate-400 text-xs">
                  Masukkan teks untuk menghasilkan QR Code
                </div>
              )}
            </div>

            {/* Quick Actions */}
            <div className="w-full space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleDownloadPng}
                  disabled={!qrDataUrl}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download PNG</span>
                </button>

                <button
                  onClick={handleDownloadSvg}
                  disabled={!qrSvgString}
                  className="py-2.5 px-3 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50 text-slate-800 dark:text-slate-200 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download SVG</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleCopyImage}
                  disabled={!qrDataUrl}
                  className="py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-50 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isCopied ? 'Tersalin!' : 'Salin Gambar'}</span>
                </button>

                <button
                  onClick={handleCopyLink}
                  disabled={!inputContent}
                  className="py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-50 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  {isLinkCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{isLinkCopied ? 'Tersalin!' : 'Salin Link'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
