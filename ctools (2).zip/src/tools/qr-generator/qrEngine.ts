import QRCode from 'qrcode';

export type QrErrorCorrectionLevel = 'L' | 'M' | 'Q' | 'H';

export interface QrOptions {
  width: number;
  margin: number;
  color: {
    dark: string;
    light: string;
  };
  errorCorrectionLevel: QrErrorCorrectionLevel;
}

export class QrEngine {
  static async generateDataUrl(text: string, options: QrOptions): Promise<string> {
    if (!text || text.trim() === '') {
      throw new Error('Teks atau URL tidak boleh kosong.');
    }
    return QRCode.toDataURL(text, {
      width: options.width,
      margin: options.margin,
      color: options.color,
      errorCorrectionLevel: options.errorCorrectionLevel,
    });
  }

  static async generateSvgString(text: string, options: QrOptions): Promise<string> {
    if (!text || text.trim() === '') {
      throw new Error('Teks atau URL tidak boleh kosong.');
    }
    return QRCode.toString(text, {
      type: 'svg',
      width: options.width,
      margin: options.margin,
      color: options.color,
      errorCorrectionLevel: options.errorCorrectionLevel,
    });
  }

  static isValidUrl(str: string): boolean {
    if (!str) return false;
    try {
      const parsed = new URL(str);
      return parsed.protocol === 'http:' || parsed.protocol === 'https:';
    } catch {
      return false;
    }
  }
}
