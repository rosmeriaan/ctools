# QR Code Link Generator Tool

Hasilkan QR Code instan beresolusi tinggi dari URL, Teks, WiFi, Kontak, Email, atau WhatsApp.

## Fitur
- Deteksi dan validasi format URL otomatis.
- Preset khusus: URL, Teks biasa, Konfigurasi WiFi, Email, Telepon, WhatsApp.
- Kustomisasi ukuran (200px - 800px) dan margin.
- Pilihan warna kustom (Foreground & Background) serta opsi Transparan.
- Level koreksi kesalahan (L 7%, M 15%, Q 25%, H 30%).
- Ekspor berkas dalam format PNG & SVG vektor.
- Fitur salin gambar QR langsung ke clipboard.

## File Terkait
- `QrGeneratorTool.tsx`: Komponen generator, panel opsi warna, preset, dan pratinjau.
- `qrEngine.ts`: Wrapper pustaka QRCode untuk rendering DataURL & SVG.
