import React, { useState, useEffect } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  Crop,
  Upload,
  Download,
  Lock,
  Unlock,
  Sliders,
  Eye,
  RefreshCw,
} from 'lucide-react';

const SOCIAL_PRESETS = [
  { name: 'TikTok / Story / Reels', w: 1080, h: 1920 },
  { name: 'YouTube Thumbnail', w: 1280, h: 720 },
  { name: 'IG Square Post', w: 1080, h: 1080 },
  { name: 'IG Portrait Post', w: 1080, h: 1350 },
  { name: 'Twitter / X Banner', w: 1500, h: 500 },
  { name: 'Avatar / Profile Picture', w: 500, h: 500 },
];

export const ImageResizerTool: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string>('');
  const [origW, setOrigW] = useState<number>(0);
  const [origH, setOrigH] = useState<number>(0);

  const [width, setWidth] = useState<number>(1080);
  const [height, setHeight] = useState<number>(1920);
  const [lockRatio, setLockRatio] = useState<boolean>(true);
  const [aspectRatioVal, setAspectRatioVal] = useState<number>(1);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (imageUrl) URL.revokeObjectURL(imageUrl);
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.src = url;
    img.onload = () => {
      setOrigW(img.width);
      setOrigH(img.height);
      setWidth(img.width);
      setHeight(img.height);
      setAspectRatioVal(img.width / img.height);
      setImageFile(file);
      setImageUrl(url);
      toast.success('Gambar Dimuat', `${img.width}x${img.height} px`);
    };
  };

  const handleWidthChange = (val: number) => {
    setWidth(val);
    if (lockRatio && aspectRatioVal > 0) {
      setHeight(Math.round(val / aspectRatioVal));
    }
  };

  const handleHeightChange = (val: number) => {
    setHeight(val);
    if (lockRatio && aspectRatioVal > 0) {
      setWidth(Math.round(val * aspectRatioVal));
    }
  };

  const applyScalePercentage = (pct: number) => {
    if (origW === 0) return;
    const newW = Math.round(origW * (pct / 100));
    const newH = Math.round(origH * (pct / 100));
    setWidth(newW);
    setHeight(newH);
  };

  const handleDownload = () => {
    if (!imageUrl) return;
    const img = new Image();
    img.src = imageUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      ctx.drawImage(img, 0, 0, width, height);
      const a = document.createElement('a');
      a.href = canvas.toDataURL('image/png');
      a.download = `resized-${width}x${height}-${imageFile?.name || 'image.png'}`;
      a.click();
      toast.success('Diunduh', `Gambar ${width}x${height}px berhasil disimpan.`);
    };
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Crop className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Image Resizer & Dimension Converter</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Preset Sosial Media
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ubah ukuran resolusi piksel lebar & tinggi gambar dengan rasio aspek terkunci atau preset instan TikTok, YouTube, dan Instagram.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!imageUrl ? (
        <div className="p-10 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl bg-white dark:bg-slate-900 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center">
            <Upload className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Pilih Gambar yang Ingin Diubah Ukurannya
            </h3>
            <p className="text-xs text-slate-500 mt-1">Format JPG, PNG, WEBP didukung.</p>
          </div>
          <label className="inline-block cursor-pointer px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors">
            Pilih Berkas Foto
            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Dimension Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Dimensi Target (Piksel):
                </span>
                <button
                  onClick={() => setLockRatio(!lockRatio)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold ${
                    lockRatio
                      ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  {lockRatio ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  <span>{lockRatio ? 'Rasio Terkunci' : 'Bebas (Stretch)'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-500">Lebar (Width px):</label>
                  <input
                    type="number"
                    value={width}
                    onChange={(e) => handleWidthChange(Math.max(1, Number(e.target.value)))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-500">Tinggi (Height px):</label>
                  <input
                    type="number"
                    value={height}
                    onChange={(e) => handleHeightChange(Math.max(1, Number(e.target.value)))}
                    className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              {/* Percentage Scaling */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-semibold text-slate-500">Skala Cepat:</span>
                <div className="flex gap-2">
                  {[25, 50, 75, 100, 150, 200].map((pct) => (
                    <button
                      key={pct}
                      onClick={() => applyScalePercentage(pct)}
                      className="flex-1 py-1.5 text-xs font-bold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>

              {/* Download */}
              <button
                onClick={handleDownload}
                className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download Gambar {width}x{height} px</span>
              </button>
            </div>

            {/* Presets Grid */}
            <div className="lg:col-span-6 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Preset Sosial Media Populer:
              </span>
              <div className="grid grid-cols-2 gap-2.5">
                {SOCIAL_PRESETS.map((p) => (
                  <button
                    key={p.name}
                    onClick={() => {
                      setLockRatio(false);
                      setWidth(p.w);
                      setHeight(p.h);
                    }}
                    className="p-3 text-left rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-blue-50 dark:hover:bg-blue-950/20 border border-slate-200 dark:border-slate-700/60 transition-colors"
                  >
                    <div className="text-xs font-bold text-slate-800 dark:text-slate-200">{p.name}</div>
                    <div className="text-[11px] font-mono text-blue-600 dark:text-blue-400 mt-0.5">
                      {p.w} × {p.h} px
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Preview */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2 shadow-xs text-center">
            <div className="text-xs font-bold text-slate-500">Pratinjau Gambar:</div>
            <img
              src={imageUrl}
              alt="Preview"
              className="max-h-72 mx-auto object-contain rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm"
            />
          </div>
        </div>
      )}
    </div>
  );
};
