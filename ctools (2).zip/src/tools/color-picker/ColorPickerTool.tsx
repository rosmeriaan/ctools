import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  Pipette,
  Copy,
  Check,
  Sparkles,
  Sliders,
  Bookmark,
  RefreshCw,
} from 'lucide-react';

export const ColorPickerTool: React.FC = () => {
  const [colorHex, setColorHex] = useState<string>('#3B82F6');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [savedColors, setSavedColors] = useState<string[]>([
    '#3B82F6',
    '#10B981',
    '#F59E0B',
    '#EF4444',
    '#8B5CF6',
    '#EC4899',
    '#0F172A',
  ]);

  // Color conversions
  const hexToRgb = (hex: string) => {
    let c = hex.replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    const num = parseInt(c, 16);
    return {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255,
    };
  };

  const rgbToHsl = (r: number, g: number, b: number) => {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0;
    let s = 0;
    let l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r:
          h = (g - b) / d + (g < b ? 6 : 0);
          break;
        case g:
          h = (b - r) / d + 2;
          break;
        case b:
          h = (r - g) / d + 4;
          break;
      }
      h /= 6;
    }

    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100),
    };
  };

  const rgb = hexToRgb(colorHex);
  const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);

  const formats = [
    { label: 'HEX', val: colorHex.toUpperCase() },
    { label: 'RGB', val: `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})` },
    { label: 'RGBA', val: `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 1)` },
    { label: 'HSL', val: `hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)` },
    { label: 'CSS Var', val: `--primary-color: ${colorHex};` },
  ];

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    toast.success('Disalin', `"${text}" disalin ke clipboard.`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleEyeDropper = async () => {
    if ('EyeDropper' in window) {
      try {
        const eyeDropper = new (window as any).EyeDropper();
        const res = await eyeDropper.open();
        if (res?.sRGBHex) {
          setColorHex(res.sRGBHex);
          toast.success('Warna Diambil', `Warna ${res.sRGBHex} berhasil dideteksi.`);
        }
      } catch {
        // User canceled
      }
    } else {
      toast.info('Info', 'EyeDropper API didukung pada browser Chromium desktop.');
    }
  };

  const handleSaveColor = () => {
    if (!savedColors.includes(colorHex)) {
      setSavedColors([colorHex, ...savedColors]);
      toast.success('Disimpan', `Warna ${colorHex} disimpan ke daftar palet.`);
    }
  };

  // Generate Shades & Tints
  const getShadesAndTints = () => {
    const list = [];
    for (let i = 10; i <= 90; i += 10) {
      list.push(`hsl(${hsl.h}, ${hsl.s}%, ${i}%)`);
    }
    return list;
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Pipette className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Color Picker & Color Inspector</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              HEX / RGB / HSL
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Pilih warna, uji kontras WCAG AA/AAA, salin format CSS/HEX/RGB, dan hasilkan skala gradasi tone 100% offline.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Main Color Swatch */}
        <div className="md:col-span-5 space-y-4">
          <div
            className="w-full h-56 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-800 flex flex-col justify-between p-5 transition-all"
            style={{ backgroundColor: colorHex }}
          >
            <div className="flex justify-between items-start">
              <span
                className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold backdrop-blur-md"
                style={{
                  backgroundColor: hsl.l > 50 ? 'rgba(0,0,0,0.2)' : 'rgba(255,255,255,0.3)',
                  color: hsl.l > 50 ? '#000' : '#FFF',
                }}
              >
                {colorHex.toUpperCase()}
              </span>

              <button
                onClick={handleSaveColor}
                className="p-2 rounded-xl backdrop-blur-md hover:scale-105 transition-transform"
                style={{
                  backgroundColor: hsl.l > 50 ? 'rgba(0,0,0,0.15)' : 'rgba(255,255,255,0.25)',
                  color: hsl.l > 50 ? '#000' : '#FFF',
                }}
                title="Simpan ke favorit"
              >
                <Bookmark className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span
                className="text-xs font-semibold"
                style={{ color: hsl.l > 50 ? 'rgba(0,0,0,0.7)' : 'rgba(255,255,255,0.8)' }}
              >
                Luminance: {hsl.l}%
              </span>
              <span
                className="text-xs font-semibold"
                style={{ color: hsl.l > 50 ? 'rgba(0,0,0,0.7)' : 'rgba(255,255,255,0.8)' }}
              >
                Saturation: {hsl.s}%
              </span>
            </div>
          </div>

          {/* Color Input Controls */}
          <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
            <div className="flex items-center gap-3">
              <input
                type="color"
                value={colorHex}
                onChange={(e) => setColorHex(e.target.value)}
                className="w-12 h-12 rounded-xl cursor-pointer border-0 bg-transparent"
              />
              <div className="flex-1 space-y-1">
                <label className="text-[11px] font-semibold text-slate-500">Ketik Kode HEX:</label>
                <input
                  type="text"
                  value={colorHex}
                  onChange={(e) => setColorHex(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-mono font-bold uppercase"
                />
              </div>
            </div>

            <button
              onClick={handleEyeDropper}
              className="w-full py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <Pipette className="w-3.5 h-3.5" />
              <span>Gunakan Pipette EyeDropper Layar</span>
            </button>
          </div>
        </div>

        {/* Color Formats & Scale */}
        <div className="md:col-span-7 space-y-4">
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Format Nilai Warna:
            </h3>

            <div className="space-y-2">
              {formats.map((f) => (
                <div
                  key={f.label}
                  className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] font-bold text-slate-400 w-12">{f.label}</span>
                    <span className="text-xs font-mono font-bold text-slate-800 dark:text-slate-200">
                      {f.val}
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy(f.val, f.label)}
                    className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500"
                    title={`Salin ${f.label}`}
                  >
                    {copiedKey === f.label ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Shades & Tints */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Tonal Shades & Tints (10% - 90% Lightness):
            </h3>
            <div className="grid grid-cols-9 gap-1.5 h-10 rounded-xl overflow-hidden">
              {getShadesAndTints().map((c, i) => (
                <button
                  key={i}
                  style={{ backgroundColor: c }}
                  onClick={() => {
                    const parsedHex = '#' + Math.floor(Math.random() * 16777215).toString(16);
                    handleCopy(c, `shade-${i}`);
                  }}
                  className="h-full rounded-md hover:scale-105 transition-transform"
                  title={`Klik untuk salin ${c}`}
                />
              ))}
            </div>
          </div>

          {/* Saved Palette */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Palet Warna Tersimpan:
            </h3>
            <div className="flex flex-wrap gap-2">
              {savedColors.map((hex) => (
                <button
                  key={hex}
                  onClick={() => setColorHex(hex)}
                  className="w-9 h-9 rounded-xl border-2 border-white dark:border-slate-800 shadow-sm hover:scale-110 transition-transform"
                  style={{ backgroundColor: hex }}
                  title={hex}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
