import React, { useState, useRef, useEffect } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatDuration, formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { FFmpegCommands } from '../../core/ffmpeg/commands';
import { Scissors, Play, Pause, Download, Music2, Clock } from 'lucide-react';

export const AudioCutterTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [duration, setDuration] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const [startTime, setStartTime] = useState<number>(0);
  const [endTime, setEndTime] = useState<number>(0);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap memotong audio',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const audioRef = useRef<HTMLAudioElement>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setAudioUrl(url);
    setOutputBlob(null);
    setOutputUrl('');
    setStartTime(0);
    setEndTime(0);
    setCurrentTime(0);

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      const dur = audioRef.current.duration || 0;
      setDuration(dur);
      setEndTime(Math.min(dur, Math.max(1, Math.round(dur))));
      if (fileMetadata) {
        setFileMetadata({
          ...fileMetadata,
          duration: dur,
        });
      }
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const handleCutAudio = async () => {
    if (!file) return;
    const cutDur = endTime - startTime;
    if (cutDur <= 0.1) {
      toast.warning('Rentang Terlalu Pendek', 'Durasi minimal 0.2 detik.');
      return;
    }

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan engine FFmpeg audio...',
      step: 'preparing',
    });

    try {
      const inputExt = file.name.split('.').pop() || 'mp3';
      const inputName = `input.${inputExt}`;
      const outputName = 'cut_audio.mp3';

      const args = FFmpegCommands.cutAudio(inputName, outputName, startTime, cutDur);

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'audio/mpeg',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Memotong audio (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Pemotongan audio selesai!',
        step: 'completed',
      });
      toast.success('Berhasil', 'Audio berhasil dipotong.');
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal memotong audio.',
        step: 'error',
        error: err?.message,
      });
      toast.error('Gagal', err?.message || 'Gagal memotong audio.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob || !file) return;
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    downloadBlob(outputBlob, `ctools-trimmed-${baseName}.mp3`);
  };

  const handleReset = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setAudioUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Scissors className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Audio Cutter & Ringtone Maker</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              MP3 Lossless Cut
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Potong lagu atau sound effect dengan penanda waktu mulai dan selesai yang presisi.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4', 'audio/webm']}
          maxSizeMB={80}
          title="Pilih File Audio untuk Dipotong"
          description="Mendukung MP3, WAV, OGG, M4A hingga 80 MB"
          icon={<Music2 className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <audio
                ref={audioRef}
                src={audioUrl}
                onLoadedMetadata={handleLoadedMetadata}
                onTimeUpdate={handleTimeUpdate}
                onEnded={() => setIsPlaying(false)}
                className="hidden"
              />

              {/* Player UI */}
              <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white flex flex-col items-center justify-center gap-4">
                <div className="w-16 h-16 rounded-full bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400 shadow-inner">
                  <Music2 className="w-8 h-8" />
                </div>
                <div className="text-center">
                  <p className="font-bold text-sm truncate max-w-xs">{file.name}</p>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    {formatDuration(currentTime)} / {formatDuration(duration)}
                  </p>
                </div>

                <div className="flex items-center gap-3 w-full max-w-md">
                  <button
                    onClick={togglePlay}
                    className="p-3 rounded-full bg-blue-600 hover:bg-blue-500 text-white shadow-lg cursor-pointer shrink-0"
                  >
                    {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max={duration || 100}
                    step="0.01"
                    value={currentTime}
                    onChange={(e) => {
                      const t = Number(e.target.value);
                      if (audioRef.current) audioRef.current.currentTime = t;
                      setCurrentTime(t);
                    }}
                    className="flex-1 accent-blue-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Trim inputs */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 space-y-3">
                <div className="flex justify-between items-center text-xs font-bold">
                  <span className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                    <Clock className="w-4 h-4 text-blue-500" />
                    Rentang Waktu Audio
                  </span>
                  <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 font-mono">
                    Durasi: {(endTime - startTime).toFixed(2)}s
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-500 block mb-1">Start Time (Detik):</label>
                    <input
                      type="number"
                      min="0"
                      max={endTime - 0.1}
                      step="0.1"
                      value={startTime}
                      onChange={(e) => setStartTime(Math.max(0, Number(e.target.value)))}
                      className="w-full px-3 py-1.5 text-xs font-mono font-bold rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-500 block mb-1">End Time (Detik):</label>
                    <input
                      type="number"
                      min={startTime + 0.1}
                      max={duration}
                      step="0.1"
                      value={endTime}
                      onChange={(e) => setEndTime(Math.min(duration, Number(e.target.value)))}
                      className="w-full px-3 py-1.5 text-xs font-mono font-bold rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    />
                  </div>
                </div>
              </div>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Aksi Pemotongan
              </h3>

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputUrl ? (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                      Pratinjau Hasil Potongan:
                    </p>
                    <audio src={outputUrl} controls className="w-full" />
                  </div>
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download MP3 ({formatFileSize(outputBlob?.size || 0)})</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleCutAudio}
                  disabled={processing.isProcessing}
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                >
                  <Scissors className="w-4 h-4" />
                  <span>{processing.isProcessing ? 'Memotong...' : 'Potong Audio Sekarang'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
