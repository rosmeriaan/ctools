import React, { useState, useMemo } from 'react';
import {
  Download,
  Share2,
  Copy,
  Check,
  Play,
  Layers,
  Sparkles,
  Code2,
  ShieldCheck,
  Plus,
  Trash2,
  Sliders,
  Type,
  Square,
  Circle,
  Eye,
  EyeOff,
  AlertTriangle,
  FileCode,
  Smartphone,
  ChevronRight,
  RefreshCw,
} from 'lucide-react';
import { AMScene, AMElement, AMShapeElement, AMTextElement, AMNullObjectElement, AMEmbedSceneElement } from '../../core/alightmotion/types';
import { AlightMotionSerializer } from '../../core/alightmotion/serializer';
import { AlightMotionValidator } from '../../core/alightmotion/validator';
import { AlightMotionExportBridge } from '../../core/alightmotion/adapter';
import { PROJECT_TEMPLATES } from '../../core/alightmotion/presets';
import { AlightMotionTestSuite, TestCaseResult } from '../../core/alightmotion/tests';
import { EASING_PRESETS } from '../../core/alightmotion/easingConverter';
import { EFFECT_TEMPLATES } from '../../core/alightmotion/effectRegistry';
import { ALIGHT_MOTION_DEFAULTS, SHAPE_TYPES, GOOGLE_FONTS_POPULAR } from '../../core/alightmotion/constants';
import { toAMColor, amColorToHex6, fromAMColorToCSS } from '../../core/alightmotion/colorSerializer';
import { toast } from '../../utils/toast';

export const AlightMotionExporterTool: React.FC = () => {
  // Active Scene State (initialized with JJ Beat Bounce preset)
  const [scene, setScene] = useState<AMScene>(() => PROJECT_TEMPLATES[0].createScene());

  // UI Tabs: 'editor' | 'presets' | 'xml' | 'validator' | 'tests'
  const [activeTab, setActiveTab] = useState<'editor' | 'presets' | 'xml' | 'validator' | 'tests'>('editor');

  // Selected Element ID for editing
  const [selectedElemId, setSelectedElemId] = useState<string | null>(null);

  // Copied state indicator
  const [copied, setCopied] = useState<boolean>(false);

  // Test suite results state
  const [testResults, setTestResults] = useState<TestCaseResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);

  // Memoized serialized XML
  const xmlOutput = useMemo(() => {
    try {
      return AlightMotionSerializer.serializeScene(scene);
    } catch (err) {
      return `<!-- Error serializing XML: ${String(err)} -->`;
    }
  }, [scene]);

  // Memoized validation result
  const validationResult = useMemo(() => {
    return AlightMotionValidator.validate(scene);
  }, [scene]);

  // Currently selected element object
  const selectedElement = useMemo(() => {
    if (!selectedElemId) return null;
    return scene.elements.find((e) => e.id === selectedElemId) || null;
  }, [scene.elements, selectedElemId]);

  // Available parent options (excluding self to prevent circular references)
  const availableParents = useMemo(() => {
    return scene.elements.filter((e) => e.id !== selectedElemId);
  }, [scene.elements, selectedElemId]);

  // Handlers
  const handleUpdateSceneMeta = (field: keyof AMScene, value: any) => {
    setScene((prev) => ({
      ...prev,
      [field]: value,
      modifiedTime: Date.now(),
    }));
  };

  const handleSelectPreset = (templateId: string) => {
    const tpl = PROJECT_TEMPLATES.find((p) => p.id === templateId);
    if (tpl) {
      const newScene = tpl.createScene();
      setScene(newScene);
      setSelectedElemId(newScene.elements[0]?.id || null);
      toast.success('Preset Dimuat', `Template "${tpl.name}" berhasil diterapkan.`);
      setActiveTab('editor');
    }
  };

  const handleAddElement = (type: 'shape' | 'text' | 'nullobj' | 'embedScene') => {
    const newId = `${Date.now().toString().slice(-6)}${Math.floor(Math.random() * 100)}`;
    let newElement: AMElement;

    if (type === 'shape') {
      newElement = {
        kind: 'shape',
        id: newId,
        label: `Shape ${scene.elements.length + 1}`,
        startTime: 0,
        endTime: scene.totalTime,
        fillType: 'color',
        mediaFillMode: 'fill',
        s: '.roundrect',
        fillColor: '#ff3b82f6',
        transform: {
          location: { value: `${scene.width / 2},${scene.height / 2},0.000000` },
          scale: { value: '1.000000,1.000000' },
          rotation: { value: '0.000000' },
          opacity: { value: '1.000000' },
        },
        properties: [
          { name: 'size', type: 'vec2', value: '240.000000,240.000000' },
          { name: 'cornerRadius', type: 'float', value: '16.000000' },
        ],
      };
    } else if (type === 'text') {
      newElement = {
        kind: 'text',
        id: newId,
        label: `Text ${scene.elements.length + 1}`,
        startTime: 0,
        endTime: scene.totalTime,
        fillType: 'color',
        mediaFillMode: 'fill',
        size: '36.000000',
        font: 'googlefonts?name=Roboto&weight=700',
        wrapWidth: 512,
        align: 'center',
        content: 'New Text',
        fillColor: '#ffffffff',
        transform: {
          location: { value: `${scene.width / 2},${scene.height / 2},0.000000` },
          scale: { value: '1.000000,1.000000' },
        },
      };
    } else if (type === 'nullobj') {
      newElement = {
        kind: 'nullobj',
        id: newId,
        label: `Null 3D ${scene.elements.length + 1}`,
        startTime: 0,
        endTime: scene.totalTime,
        mediaFillMode: 'fill',
        type: 'perspective',
        transform: {
          location: { value: `${scene.width / 2},${scene.height / 2},0.000000` },
          scale: { value: '1.000000,1.000000' },
        },
      };
    } else {
      newElement = {
        kind: 'embedScene',
        id: newId,
        label: `Group Precompose ${scene.elements.length + 1}`,
        startTime: 0,
        endTime: scene.totalTime,
        fillType: 'intrinsic',
        outTime: scene.totalTime,
        mediaFillMode: 'fill',
        fillColor: '#ff000000',
        scene: {
          title: '',
          width: scene.width,
          height: scene.height,
          exportWidth: scene.exportWidth,
          exportHeight: scene.exportHeight,
          precompose: 'dynamicResolution',
          bgcolor: '#00000000',
          totalTime: scene.totalTime,
          fps: scene.fps,
          amver: ALIGHT_MOTION_DEFAULTS.AMVER,
          ffver: ALIGHT_MOTION_DEFAULTS.FFVER,
          am: ALIGHT_MOTION_DEFAULTS.AM_PACKAGE,
          amplatform: 'android',
          retime: 'off',
          retimeAdaptFPS: false,
          elements: [],
        },
      };
    }

    setScene((prev) => ({
      ...prev,
      elements: [...prev.elements, newElement],
      modifiedTime: Date.now(),
    }));
    setSelectedElemId(newId);
    toast.success('Layer Ditambahkan', `Layer "${(newElement as any).label || newElement.kind}" berhasil dibuat.`);
  };

  const handleDeleteElement = (id: string) => {
    setScene((prev) => ({
      ...prev,
      elements: prev.elements.filter((e) => e.id !== id),
      modifiedTime: Date.now(),
    }));
    if (selectedElemId === id) {
      setSelectedElemId(null);
    }
    toast.info('Layer Dihapus', 'Layer telah dihapus dari project.');
  };

  const handleUpdateSelectedElement = (updater: (elem: any) => any) => {
    if (!selectedElemId) return;
    setScene((prev) => ({
      ...prev,
      elements: prev.elements.map((e) => (e.id === selectedElemId ? updater(e) : e)),
      modifiedTime: Date.now(),
    }));
  };

  const handleAddEffectToSelected = (templateId: string) => {
    const tpl = EFFECT_TEMPLATES.find((e) => e.id === templateId);
    if (!tpl || !selectedElement) return;

    const newEffect = tpl.createDefault();
    handleUpdateSelectedElement((elem) => ({
      ...elem,
      effects: [...(elem.effects || []), newEffect],
    }));
    toast.success('Efek Ditambahkan', `Efek "${tpl.name}" berhasil disematkan.`);
  };

  const handleRemoveEffect = (effectIndex: number) => {
    handleUpdateSelectedElement((elem) => ({
      ...elem,
      effects: (elem.effects || []).filter((_: any, idx: number) => idx !== effectIndex),
    }));
  };

  const handleDownload = () => {
    if (!validationResult.isValid) {
      const errorMsg = validationResult.issues.find((i) => i.severity === 'error')?.message || 'Schema XML tidak valid';
      toast.error('Gagal Export', errorMsg);
      return;
    }
    AlightMotionExportBridge.downloadXmlFile(scene);
    toast.success('Download Dimulai', `Berkas XML "${scene.title}.xml" berhasil diunduh.`);
  };

  const handleShare = async () => {
    if (!validationResult.isValid) {
      toast.error('Gagal Membagikan', 'Perbaiki error pada tab Validasi sebelum membagikan.');
      return;
    }
    const res = await AlightMotionExportBridge.shareToAlightMotion(scene);
    if (res.success) {
      toast.success('Share Alight Motion', res.message);
    } else {
      toast.info('Info', res.message);
    }
  };

  const handleCopyXml = async () => {
    const ok = await AlightMotionExportBridge.copyXmlToClipboard(scene);
    if (ok) {
      setCopied(true);
      toast.success('Tersalin', 'Kode XML Alight Motion berhasil disalin ke clipboard.');
      setTimeout(() => setCopied(false), 2000);
    } else {
      toast.error('Gagal Salin', 'Tidak dapat mengakses clipboard peramban.');
    }
  };

  const handleRunAllTests = () => {
    setIsRunningTests(true);
    setTimeout(() => {
      const res = AlightMotionTestSuite.runAllTests();
      setTestResults(res);
      setIsRunningTests(false);
      const passedCount = res.filter((r) => r.passed).length;
      toast.success('Uji Regresi Selesai', `${passedCount} dari ${res.length} test case berhasil diverifikasi.`);
    }, 200);
  };

  return (
    <div className="w-full space-y-6">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400">
                <Smartphone className="w-5 h-5" />
              </span>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100">
                Alight Motion Project Exporter
              </h1>
              <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                XML ffver=106
              </span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-3xl">
              Generator berkas XML project asli untuk Alight Motion (Android). Menghasilkan struktur elemen, keyframe, formula easing, dan efek berbasis format resmi Alight Motion 5.0.273.
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleCopyXml}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 transition cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Tersalin!' : 'Salin XML'}
            </button>
            <button
              onClick={handleShare}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 transition cursor-pointer"
              title="Buka langsung di Alight Motion via Android Share"
            >
              <Share2 className="w-4 h-4" />
              Share ke AM
            </button>
            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Download .xml
            </button>
          </div>
        </div>

        {/* Global Project Metadata Toolbar */}
        <div className="mt-5 pt-5 border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div>
            <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              Judul Proyek
            </label>
            <input
              type="text"
              value={scene.title}
              onChange={(e) => handleUpdateSceneMeta('title', e.target.value)}
              className="w-full text-xs sm:text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              Aspek Rasio / Ukuran
            </label>
            <select
              value={`${scene.width}x${scene.height}`}
              onChange={(e) => {
                const [w, h] = e.target.value.split('x').map(Number);
                handleUpdateSceneMeta('width', w);
                handleUpdateSceneMeta('height', h);
                handleUpdateSceneMeta('exportWidth', w);
                handleUpdateSceneMeta('exportHeight', h);
              }}
              className="w-full text-xs sm:text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="720x720">1:1 Square (720x720)</option>
              <option value="720x1280">9:16 Portrait (720x1280)</option>
              <option value="1080x1920">9:16 HD (1080x1920)</option>
              <option value="1440x1080">4:3 Landscape (1440x1080)</option>
              <option value="1280x720">16:9 HD (1280x720)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              Frame Rate (FPS)
            </label>
            <select
              value={scene.fps}
              onChange={(e) => handleUpdateSceneMeta('fps', Number(e.target.value))}
              className="w-full text-xs sm:text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value={30}>30 FPS</option>
              <option value={60}>60 FPS (Smooth)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              Durasi (Milidetik)
            </label>
            <input
              type="number"
              step={500}
              min={500}
              value={scene.totalTime}
              onChange={(e) => handleUpdateSceneMeta('totalTime', Math.max(500, Number(e.target.value)))}
              className="w-full text-xs sm:text-sm font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              Warna Background
            </label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={amColorToHex6(scene.bgcolor)}
                onChange={(e) => handleUpdateSceneMeta('bgcolor', toAMColor(e.target.value))}
                className="w-8 h-8 rounded-lg cursor-pointer border border-slate-300 dark:border-slate-700 bg-transparent p-0"
              />
              <span className="text-xs font-mono text-slate-600 dark:text-slate-400 uppercase">
                {scene.bgcolor}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
              Status Validasi
            </label>
            <div className="flex items-center gap-1.5 pt-1 text-xs font-semibold">
              {validationResult.isValid ? (
                <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                  <ShieldCheck className="w-4 h-4" />
                  XML Valid (ffver={scene.ffver})
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                  {validationResult.issues.filter((i) => i.severity === 'error').length} Error Terdeteksi
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('editor')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
            activeTab === 'editor'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          Layer Editor ({scene.elements.length})
        </button>

        <button
          onClick={() => setActiveTab('presets')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
            activeTab === 'presets'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          Preset Template ({PROJECT_TEMPLATES.length})
        </button>

        <button
          onClick={() => setActiveTab('xml')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
            activeTab === 'xml'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Code2 className="w-4 h-4" />
          Live XML Code
        </button>

        <button
          onClick={() => setActiveTab('validator')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
            activeTab === 'validator'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          Validasi & Diagnostik
          {validationResult.issues.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-600 dark:text-amber-400">
              {validationResult.issues.length}
            </span>
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab('tests');
            if (testResults.length === 0) handleRunAllTests();
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
            activeTab === 'tests'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Play className="w-4 h-4" />
          Uji Regresi Golden (13 Test)
        </button>
      </div>

      {/* TAB 1: VISUAL LAYER EDITOR */}
      {activeTab === 'editor' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Layer Hierarchy Tree */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                  <Layers className="w-4 h-4 text-blue-500" />
                  Daftar Layer Project
                </h3>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleAddElement('shape')}
                    className="p-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    title="Tambah Shape"
                  >
                    <Square className="w-3.5 h-3.5" />
                    +Shape
                  </button>
                  <button
                    onClick={() => handleAddElement('text')}
                    className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    title="Tambah Text"
                  >
                    <Type className="w-3.5 h-3.5" />
                    +Text
                  </button>
                  <button
                    onClick={() => handleAddElement('nullobj')}
                    className="p-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 hover:bg-amber-100 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    title="Tambah Null 3D"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    +Null
                  </button>
                </div>
              </div>

              {/* Elements List */}
              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                {scene.elements.length === 0 ? (
                  <div className="py-8 text-center text-xs text-slate-400">
                    Belum ada layer. Klik tombol di atas untuk menambahkan Shape, Text, atau Null Object.
                  </div>
                ) : (
                  scene.elements.map((elem, idx) => {
                    const isSelected = elem.id === selectedElemId;
                    return (
                      <div
                        key={elem.id}
                        onClick={() => setSelectedElemId(elem.id)}
                        className={`p-3 rounded-xl border transition flex items-center justify-between cursor-pointer ${
                          isSelected
                            ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/30 ring-1 ring-blue-500'
                            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className="text-xs font-mono font-bold text-slate-400">
                            #{idx + 1}
                          </span>
                          <span className="p-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300">
                            {elem.kind === 'shape' && <Square className="w-3.5 h-3.5" />}
                            {elem.kind === 'text' && <Type className="w-3.5 h-3.5" />}
                            {elem.kind === 'nullobj' && <Sliders className="w-3.5 h-3.5 text-amber-500" />}
                            {elem.kind === 'embedScene' && <Layers className="w-3.5 h-3.5 text-purple-500" />}
                          </span>
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
                              {(elem as any).label || `${elem.kind} [id: ${elem.id}]`}
                            </p>
                            <p className="text-[10px] text-slate-500 dark:text-slate-400">
                              {elem.startTime}ms - {elem.endTime}ms
                              {elem.parent && ` • parent: #${elem.parent}`}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => handleDeleteElement(elem.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition cursor-pointer"
                            title="Hapus Layer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>

          {/* Right: Selected Element Property Inspector */}
          <div className="lg:col-span-7 space-y-4">
            {selectedElement ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                      Inspector: {(selectedElement as any).label || selectedElement.kind}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                      Tag: &lt;{selectedElement.kind}&gt; (ID: {selectedElement.id})
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedElemId(null)}
                    className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                  >
                    Tutup
                  </button>
                </div>

                {/* Layer Timing & Hierarchy */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                      Label / Nama Layer
                    </label>
                    <input
                      type="text"
                      value={(selectedElement as any).label || ''}
                      onChange={(e) =>
                        handleUpdateSelectedElement((elem) => ({ ...elem, label: e.target.value }))
                      }
                      className="w-full text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                      Start Time (ms)
                    </label>
                    <input
                      type="number"
                      value={selectedElement.startTime}
                      onChange={(e) =>
                        handleUpdateSelectedElement((elem) => ({
                          ...elem,
                          startTime: Number(e.target.value),
                        }))
                      }
                      className="w-full text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                      End Time (ms)
                    </label>
                    <input
                      type="number"
                      value={selectedElement.endTime}
                      onChange={(e) =>
                        handleUpdateSelectedElement((elem) => ({
                          ...elem,
                          endTime: Number(e.target.value),
                        }))
                      }
                      className="w-full text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                    />
                  </div>
                </div>

                {/* Parent Reference Selector */}
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                    Parent Controller Layer (Hierarki 3D / Null)
                  </label>
                  <select
                    value={selectedElement.parent || ''}
                    onChange={(e) =>
                      handleUpdateSelectedElement((elem) => ({
                        ...elem,
                        parent: e.target.value || undefined,
                      }))
                    }
                    className="w-full text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                  >
                    <option value="">Tanpa Parent (Root Scene)</option>
                    {availableParents.map((p) => (
                      <option key={p.id} value={p.id}>
                        {`ID: ${p.id} - ${(p as any).label || p.kind}`}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Specific Shape Properties */}
                {selectedElement.kind === 'shape' && (
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-750 space-y-3">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Properti Shape & Warna
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-1">
                          Tipe Bentuk (s=...)
                        </label>
                        <select
                          value={selectedElement.s}
                          onChange={(e) =>
                            handleUpdateSelectedElement((elem) => ({ ...elem, s: e.target.value }))
                          }
                          className="w-full text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        >
                          {SHAPE_TYPES.map((st) => (
                            <option key={st.id} value={st.id}>
                              {st.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-1">
                          Fill Type
                        </label>
                        <select
                          value={selectedElement.fillType}
                          onChange={(e) =>
                            handleUpdateSelectedElement((elem) => ({
                              ...elem,
                              fillType: e.target.value,
                            }))
                          }
                          className="w-full text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        >
                          <option value="color">Solid Color</option>
                          <option value="gradient">Linear Gradient</option>
                          <option value="media">Media Image / Video</option>
                          <option value="none">None (Outline Only)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-1">
                          Fill Color (#AARRGGBB)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={amColorToHex6(selectedElement.fillColor || '#ffffffff')}
                            onChange={(e) =>
                              handleUpdateSelectedElement((elem) => ({
                                ...elem,
                                fillColor: toAMColor(e.target.value),
                              }))
                            }
                            className="w-7 h-7 rounded border border-slate-300 dark:border-slate-700 bg-transparent"
                          />
                          <span className="text-[11px] font-mono">
                            {selectedElement.fillColor || '#ffffffff'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Specific Text Properties */}
                {selectedElement.kind === 'text' && (
                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-750 space-y-3">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Properti Tipografi & Konten
                    </h4>
                    <div>
                      <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-1">
                        Konten Teks (&lt;content&gt;)
                      </label>
                      <input
                        type="text"
                        value={selectedElement.content}
                        onChange={(e) =>
                          handleUpdateSelectedElement((elem) => ({ ...elem, content: e.target.value }))
                        }
                        className="w-full text-xs font-medium px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-1">
                          Ukuran Font (size)
                        </label>
                        <input
                          type="number"
                          value={parseFloat(selectedElement.size)}
                          onChange={(e) =>
                            handleUpdateSelectedElement((elem) => ({
                              ...elem,
                              size: `${e.target.value}.000000`,
                            }))
                          }
                          className="w-full text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-1">
                          Font Family
                        </label>
                        <select
                          value={selectedElement.font}
                          onChange={(e) =>
                            handleUpdateSelectedElement((elem) => ({ ...elem, font: e.target.value }))
                          }
                          className="w-full text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        >
                          {GOOGLE_FONTS_POPULAR.map((f) => (
                            <option key={f.name} value={`googlefonts?name=${f.name}&weight=700`}>
                              {f.name} (700 Bold)
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-1">
                          Align
                        </label>
                        <select
                          value={selectedElement.align}
                          onChange={(e) =>
                            handleUpdateSelectedElement((elem) => ({ ...elem, align: e.target.value }))
                          }
                          className="w-full text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                        >
                          <option value="center">Center</option>
                          <option value="left">Left</option>
                          <option value="right">Right</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* Effect Manager Section */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Efek Tersemat ({selectedElement.effects?.length || 0})
                    </h4>
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          handleAddEffectToSelected(e.target.value);
                          e.target.value = '';
                        }
                      }}
                      defaultValue=""
                      className="text-xs px-2.5 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-semibold cursor-pointer"
                    >
                      <option value="" disabled>
                        + Tambah Efek AM...
                      </option>
                      {EFFECT_TEMPLATES.map((eff) => (
                        <option key={eff.id} value={eff.id}>
                          {eff.name} ({eff.category})
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedElement.effects && selectedElement.effects.length > 0 ? (
                    <div className="space-y-1.5">
                      {selectedElement.effects.map((eff, effIdx) => (
                        <div
                          key={effIdx}
                          className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between"
                        >
                          <div>
                            <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                              {eff.id.split('.').pop()}
                            </p>
                            <p className="text-[10px] text-slate-500 font-mono">{eff.id}</p>
                          </div>
                          <button
                            onClick={() => handleRemoveEffect(effIdx)}
                            className="text-slate-400 hover:text-rose-500 p-1"
                            title="Hapus Efek"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-400 italic">
                      Belum ada efek tersemat pada layer ini.
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-12 text-center text-slate-400">
                <Layers className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-700" />
                <p className="text-sm font-semibold">Pilih salah satu layer di sebelah kiri</p>
                <p className="text-xs mt-1">untuk mengubah posisi, skala, warna, dan menyematkan efek.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PRESET TEMPLATES */}
      {activeTab === 'presets' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {PROJECT_TEMPLATES.map((tpl) => (
            <div
              key={tpl.id}
              className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-blue-500/50 dark:hover:border-blue-500/50 shadow-sm transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                    {tpl.badge}
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1.5">
                  {tpl.name}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                  {tpl.description}
                </p>
              </div>

              <button
                onClick={() => handleSelectPreset(tpl.id)}
                className="w-full py-2 px-3 rounded-xl text-xs font-semibold bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/40 dark:hover:bg-blue-900/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 transition cursor-pointer flex items-center justify-center gap-1.5"
              >
                Gunakan Template Ini
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: LIVE XML INSPECTOR */}
      {activeTab === 'xml' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Kode XML ter-generate secara real-time berdasarkan struktur resmi Alight Motion XML.
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyXml}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'Tersalin' : 'Salin Kode'}
              </button>
            </div>
          </div>

          <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-[#0a0e17] text-slate-200 font-mono text-xs p-4 sm:p-5 max-h-[600px] overflow-y-auto leading-relaxed shadow-inner">
            <pre className="whitespace-pre-wrap selection:bg-blue-600 selection:text-white">
              {xmlOutput}
            </pre>
          </div>
        </div>
      )}

      {/* TAB 4: VALIDATOR & DIAGNOSTICS */}
      {activeTab === 'validator' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-500" />
              Laporan Validasi Multi-Tahap (Pipeline)
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
              Pemeriksaan mencakup validitas schema root &lt;scene&gt;, referensi parent antar ID layer, konsistensi durasi, dan pengujian parser XML peramban asli.
            </p>

            {validationResult.issues.length === 0 ? (
              <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 flex items-center gap-3">
                <Check className="w-5 h-5 text-emerald-500 shrink-0" />
                <div>
                  <p className="text-xs font-bold">Seluruh Pengujian Validasi Lolos (100% Valid)</p>
                  <p className="text-[11px] opacity-90">
                    Proyek ini memenuhi standar XML Alight Motion 5.0.273 dan siap diexport.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                {validationResult.issues.map((issue, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border flex items-start gap-3 ${
                      issue.severity === 'error'
                        ? 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300'
                        : 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-[10px] font-mono uppercase font-bold px-1.5 py-0.5 rounded bg-black/10 dark:bg-white/10 mr-2">
                        {issue.code}
                      </span>
                      <span className="text-xs font-medium">{issue.message}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: REGRESSION & GOLDEN TEST SUITE */}
      {activeTab === 'tests' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <Play className="w-4 h-4 text-blue-500" />
                  Alight Motion Golden Reference Test Runner
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  13 Unit Test Case memverifikasi kepatuhan terhadap export Alight Motion asli (Proyek Baru 5.xml).
                </p>
              </div>
              <button
                onClick={handleRunAllTests}
                disabled={isRunningTests}
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRunningTests ? 'animate-spin' : ''}`} />
                Jalankan Ulang Test
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {testResults.map((t) => (
                <div
                  key={t.id}
                  className={`p-3.5 rounded-xl border flex items-start justify-between gap-3 ${
                    t.passed
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900'
                      : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {t.id}
                      </span>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                        {t.name}
                      </h4>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-400">
                      {t.description}
                    </p>
                  </div>

                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-full shrink-0 flex items-center gap-1 ${
                      t.passed
                        ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20'
                        : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                    }`}
                  >
                    {t.passed ? <Check className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                    {t.passed ? 'PASSED' : 'FAILED'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
