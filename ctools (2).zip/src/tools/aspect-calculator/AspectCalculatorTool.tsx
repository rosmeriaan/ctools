import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { Calculator, Lock, Unlock, Smartphone, Monitor, Sparkles, Copy, Check } from 'lucide-react';
import { toast } from '../../utils/toast';

export const AspectCalculatorTool: React.FC = () => {
  const [width, setWidth] = useState<number>(1920);
  const [height, setHeight] = useState<number>(1080);
  const [isLocked, setIsLocked] = useState<boolean>(true);
  const [ratioW, setRatioW] = useState<number>(16);
  const [ratioH, setRatioH] = useState<number>(9);

  // Bitrate estimator
  const [durationMin, setDurationMin] = useState<number>(1);
  const [durationSec, setDurationSec] = useState<number>(30);
  const [bitrateMbps, setBitrateMbps] = useState<number>(8);

  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));

  const currentGcd = gcd(Math.round(width), Math.round(height)) || 1;
  const simplifiedW = Math.round(width / currentGcd);
  const simplifiedH = Math.round(height / currentGcd);

  const totalPixels = width * height;
  const megapixels = (totalPixels / 1000000).toFixed(2);

  const handleWidthChange = (val: number) => {
    setWidth(val);
    if (isLocked && ratioW > 0) {
      setHeight(Math.round((val * ratioH) / ratioW));
    }
  };

  const handleHeightChange = (val: number) => {
    setHeight(val);
    if (isLocked && ratioH > 0) {
      setWidth(Math.round((val * ratioW) / ratioH));
    }
  };

  const setPreset = (w: number, h: number, rw: number, rh: number) => {
    setWidth(w);
    setHeight(h);
    setRatioW(rw);
    setRatioH(rh);
  };

  // Estimated Video File Size: (Bitrate in Mbps * total seconds) / 8 = MB
  const totalSeconds = durationMin * 60 + durationSec;
  const estimatedFileSizeMB = ((bitrateMbps * totalSeconds) / 8).toFixed(1);

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Calculator className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Aspect Ratio & Bitrate Calculator</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Creator Math Tools
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Hitung rasio aspek, skala resolusi piksel, dan estimasi ukuran file video berdasarkan bitrate.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Dimension & Aspect Section */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Kalkulator Resolusi & Rasio Aspek
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-500">Lebar Piksel (Width):</label>
                <input
                  type="number"
                  min="1"
                  value={width}
                  onChange={(e) => handleWidthChange(Math.max(1, Number(e.target.value)))}
                  className="w-full px-4 py-2.5 text-base font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-blue-600"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-500">Tinggi Piksel (Height):</label>
                <input
                  type="number"
                  min="1"
                  value={height}
                  onChange={(e) => handleHeightChange(Math.max(1, Number(e.target.value)))}
                  className="w-full px-4 py-2.5 text-base font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-blue-600"
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
              <button
                onClick={() => setIsLocked(!isLocked)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                  isLocked
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                <span>{isLocked ? 'Kunci Rasio Aktif' : 'Rasio Bebas'}</span>
              </button>

              <div className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                Rasio: <span className="text-blue-600">{simplifiedW}:{simplifiedH}</span> ({(width / height).toFixed(2)})
              </div>
            </div>

            {/* Quick scale multiplier */}
            <div className="space-y-1.5">
              <span className="text-xs text-slate-500 font-semibold">Skala Cepat:</span>
              <div className="grid grid-cols-5 gap-2">
                {[0.5, 0.75, 1.5, 2.0, 4.0].map((s) => (
                  <button
                    key={s}
                    onClick={() => {
                      setWidth(Math.round(width * s));
                      setHeight(Math.round(height * s));
                    }}
                    className="py-2 text-xs font-bold rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    {s}x
                  </button>
                ))}
              </div>
            </div>

            {/* Presets */}
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Preset Resolusi Standar:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { label: '9:16 TikTok HD', w: 1080, h: 1920, rw: 9, rh: 16 },
                  { label: '16:9 YouTube 1080p', w: 1920, h: 1080, rw: 16, rh: 9 },
                  { label: '16:9 4K UHD', w: 3840, h: 2160, rw: 16, rh: 9 },
                  { label: '1:1 Square Feed', w: 1080, h: 1080, rw: 1, rh: 1 },
                  { label: '4:5 IG Portrait', w: 1080, h: 1350, rw: 4, rh: 5 },
                  { label: '21:9 Ultrawide', w: 2560, h: 1080, rw: 21, rh: 9 },
                ].map((item) => (
                  <button
                    key={item.label}
                    onClick={() => setPreset(item.w, item.h, item.rw, item.rh)}
                    className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-left cursor-pointer"
                  >
                    <div className="text-[11px] font-bold text-slate-800 dark:text-slate-200">{item.label}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{item.w}x{item.h}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Video Bitrate Estimator */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Estimasi Ukuran File Video
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs text-slate-500">Durasi (Menit):</label>
                <input
                  type="number"
                  min="0"
                  value={durationMin}
                  onChange={(e) => setDurationMin(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-500">Durasi (Detik):</label>
                <input
                  type="number"
                  min="0"
                  max="59"
                  value={durationSec}
                  onChange={(e) => setDurationSec(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-500 flex justify-between">
                <span>Video Target Bitrate:</span>
                <span className="font-mono font-bold text-blue-600">{bitrateMbps} Mbps</span>
              </label>
              <input
                type="range"
                min="1"
                max="50"
                value={bitrateMbps}
                onChange={(e) => setBitrateMbps(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400">
                <span>1 Mbps (Kompres)</span>
                <span>8 Mbps (TikTok/YT)</span>
                <span>50 Mbps (4K Pro)</span>
              </div>
            </div>

            {/* File size result card */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white text-center space-y-1 shadow-lg">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold">
                Perkiraan Ukuran File:
              </span>
              <div className="text-3xl font-black font-mono text-emerald-400">
                ~{estimatedFileSizeMB} MB
              </div>
              <p className="text-[10px] text-slate-400">
                Total durasi: {totalSeconds} detik • {megapixels} Megapixels / frame
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
