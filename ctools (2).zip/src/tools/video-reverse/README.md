# Video Reverse Tool

Putar balik urutan frame video dan trek suara audio untuk menciptakan efek rewind tanpa mengunggah ke server.

## Fitur
- Dukungan format: MP4, WebM, MOV.
- Mode audio: Reverse Audio, Mute (Hening), atau Original Audio.
- Pengaturan kecepatan: 0.75x, 1.0x, 1.25x, 1.5x.
- Target FPS: 24 FPS atau 30 FPS.
- Pemrosesan lokal menggunakan Canvas capture stream & Web Audio API buffer reverse.

## File Terkait
- `VideoReverseTool.tsx`: Antarmuka upload, opsi kontrol, progress bar, dan player.
- `videoReverseEngine.ts`: Canvas frame-by-frame renderer & MediaRecorder stream encoder.
