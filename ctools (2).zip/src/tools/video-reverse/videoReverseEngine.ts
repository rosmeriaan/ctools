/**
 * Browser-based Video Reverser Engine
 * Architecture:
 * - Extracts video frames using HTML5 Video + Offscreen/Hidden Canvas
 * - Decodes audio track using AudioContext, reverses the PCM audio buffer if requested
 * - Records reversed frames sequentially through canvas.captureStream() + WebAudio MediaStreamDestination into MediaRecorder
 * - Emits real-time progress callbacks (frame extraction, reverse composition, encoding)
 */

export interface VideoReverseOptions {
  reverseAudio: 'reverse' | 'mute' | 'original';
  playbackRate?: number; // 0.5 to 2.0
  fps?: number; // 24, 30
}

export class VideoReverseEngine {
  private isCancelled: boolean = false;

  cancel() {
    this.isCancelled = true;
  }

  async reverseVideo(
    videoFile: File,
    options: VideoReverseOptions,
    onProgress?: (progress: number, status: string, step: string) => void
  ): Promise<{ blob: Blob; format: string }> {
    this.isCancelled = false;
    onProgress?.(5, 'Menyiapkan decoding video di browser...', 'prepare');

    const videoUrl = URL.createObjectURL(videoFile);
    const video = document.createElement('video');
    video.preload = 'auto';
    video.muted = true;
    video.playsInline = true;
    video.src = videoUrl;

    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = () => reject(new Error('Gagal memuat metadata video.'));
    });

    const duration = video.duration;
    if (!duration || duration <= 0) {
      URL.revokeObjectURL(videoUrl);
      throw new Error('Durasi video tidak valid.');
    }

    const width = video.videoWidth || 640;
    const height = video.videoHeight || 360;

    // Target FPS (default 24 or 30)
    const targetFps = options.fps || 24;
    const totalFrames = Math.max(1, Math.floor(duration * targetFps));
    const frameInterval = 1 / targetFps;

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (!ctx) {
      URL.revokeObjectURL(videoUrl);
      throw new Error('Canvas 2D context tidak dapat diinisialisasi.');
    }

    // Step 1: Decode Audio if audio is desired
    let reversedAudioBuffer: AudioBuffer | null = null;
    let audioContext: AudioContext | null = null;

    if (options.reverseAudio !== 'mute') {
      try {
        onProgress?.(10, 'Mengekstrak dan mendekode trek audio...', 'audio');
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          audioContext = new AudioCtx();
          const arrayBuffer = await videoFile.arrayBuffer();
          const decoded = await audioContext.decodeAudioData(arrayBuffer.slice(0));

          if (options.reverseAudio === 'reverse') {
            // Reverse channels
            const reversed = audioContext.createBuffer(
              decoded.numberOfChannels,
              decoded.length,
              decoded.sampleRate
            );
            for (let c = 0; c < decoded.numberOfChannels; c++) {
              const srcData = decoded.getChannelData(c);
              const destData = reversed.getChannelData(c);
              for (let i = 0, j = decoded.length - 1; i < decoded.length; i++, j--) {
                destData[i] = srcData[j];
              }
            }
            reversedAudioBuffer = reversed;
          } else {
            reversedAudioBuffer = decoded;
          }
        }
      } catch (err) {
        console.warn('Audio decoding not supported or video has no audio track:', err);
      }
    }

    // Step 2: Extract frames in reverse order or extract all frames
    // To maintain fast performance and avoid out-of-memory for high-res videos, we seek backwards
    onProgress?.(20, 'Mengekstrak frame video secara terbalik...', 'frames');

    // Create stream from canvas
    const canvasStream = canvas.captureStream(targetFps);
    const combinedStream = new MediaStream();
    canvasStream.getVideoTracks().forEach((track) => combinedStream.addTrack(track));

    let audioDest: MediaStreamAudioDestinationNode | null = null;
    let audioSourceNode: AudioBufferSourceNode | null = null;

    if (reversedAudioBuffer && audioContext) {
      audioDest = audioContext.createMediaStreamDestination();
      audioSourceNode = audioContext.createBufferSource();
      audioSourceNode.buffer = reversedAudioBuffer;
      audioSourceNode.playbackRate.value = options.playbackRate || 1.0;
      audioSourceNode.connect(audioDest);
      audioDest.stream.getAudioTracks().forEach((track) => combinedStream.addTrack(track));
    }

    // Determine MediaRecorder mimeType
    let mimeType = 'video/webm;codecs=vp9,opus';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
      mimeType = 'video/webm;codecs=vp8,opus';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = '';
        }
      }
    }

    const recordedChunks: Blob[] = [];
    const recorder = mimeType
      ? new MediaRecorder(combinedStream, { mimeType, videoBitsPerSecond: 3_500_000 })
      : new MediaRecorder(combinedStream);

    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    const completionPromise = new Promise<{ blob: Blob; format: string }>((resolve, reject) => {
      recorder.onstop = () => {
        URL.revokeObjectURL(videoUrl);
        if (audioContext && audioContext.state !== 'closed') {
          audioContext.close().catch(() => {});
        }
        const outputBlob = new Blob(recordedChunks, { type: recorder.mimeType || 'video/webm' });
        resolve({
          blob: outputBlob,
          format: recorder.mimeType.includes('mp4') ? 'mp4' : 'webm',
        });
      };
      recorder.onerror = (e) => {
        URL.revokeObjectURL(videoUrl);
        reject(e);
      };
    });

    recorder.start(100);
    if (audioSourceNode) {
      audioSourceNode.start();
    }

    // Render reversed frames
    const stepDuration = 1000 / (targetFps * (options.playbackRate || 1.0));

    for (let frameIdx = totalFrames - 1; frameIdx >= 0; frameIdx--) {
      if (this.isCancelled) {
        recorder.stop();
        URL.revokeObjectURL(videoUrl);
        throw new Error('Proses dibatalkan oleh pengguna.');
      }

      const targetTime = Math.max(0, Math.min(duration, frameIdx * frameInterval));

      // Seek video
      await new Promise<void>((res) => {
        const onSeeked = () => {
          video.removeEventListener('seeked', onSeeked);
          res();
        };
        video.addEventListener('seeked', onSeeked);
        video.currentTime = targetTime;
      });

      // Draw onto canvas
      ctx.drawImage(video, 0, 0, width, height);

      // Report progress
      const progressPercent = Math.round(20 + ((totalFrames - frameIdx) / totalFrames) * 75);
      const remainingFrames = frameIdx;
      onProgress?.(
        progressPercent,
        `Me-render frame terbalik ${totalFrames - frameIdx} / ${totalFrames}...`,
        'render'
      );

      // Small tick delay to allow MediaRecorder to catch frame
      await new Promise((r) => setTimeout(r, Math.max(8, stepDuration * 0.5)));
    }

    onProgress?.(98, 'Memfinalisasi berkas video terbalik...', 'finalize');
    recorder.stop();

    return completionPromise;
  }
}
