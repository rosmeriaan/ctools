import React, { useState, useRef, useEffect } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { VideoReverseEngine } from './videoReverseEngine';
import { FileMetadata, ProcessingState } from '../../types';
import { downloadBlob, revokeObjectURL } from '../../utils/file';
import { toast } from '../../utils/toast';
import {
  Rewind,
  RotateCcw,
  Download,
  Play,
  Volume2,
  VolumeX,
  Gauge,
  Film,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Video,
} from 'lucide-react';

export const VideoReverseTool: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileMeta, setFileMeta] = useState<FileMetadata | null>(null);
  const [videoSrc, setVideoSrc] = useState<string | null>(null);

  const [reversedBlob, setReversedBlob] = useState<Blob | null>(null);
  const [reversedVideoUrl, setReversedVideoUrl] = useState<string | null>(null);
  const [outputFormat, setOutputFormat] = useState<string>('webm');

  // Options
  const [audioMode, setAudioMode] = useState<'reverse' | 'mute' | 'original'>('reverse');
  const [speed, setSpeed] = useState<number>(1.0);
  const [fps, setFps] = useState<number>(24);

  // Processing state
  const [procState, setProcState] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: '',
  });

  const engineRef = useRef<VideoReverseEngine | null>(null);

  useEffect(() => {
    return () => {
      revokeObjectURL(videoSrc);
      revokeObjectURL(reversedVideoUrl);
    };
  }, [videoSrc, reversedVideoUrl]);

  const handleFileSelect = (file: File) => {
    revokeObjectURL(videoSrc);
    revokeObjectURL(reversedVideoUrl);
    setReversedBlob(null);
    setReversedVideoUrl(null);

    const url = URL.createObjectURL(file);
    setVideoSrc(url);
    setSelectedFile(file);

    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      setFileMeta({
        name: file.name,
        size: file.size,
        type: file.type,
        dimensions: { width: video.videoWidth, height: video.videoHeight },
        duration: video.duration,
      });
    };
    video.src = url;
  };

  const handleStartReversing = async () => {
    if (!selectedFile) return;

    const engine = new VideoReverseEngine();
    engineRef.current = engine;

    setProcState({
      isProcessing: true,
      progress: 5,
      statusText: 'Menyiapkan decoding video di browser...',
    });

    try {
      const result = await engine.reverseVideo(
        selectedFile,
        {
          reverseAudio: audioMode,
          playbackRate: speed,
          fps: fps,
        },
        (progress, statusText) => {
          setProcState({
            isProcessing: true,
            progress,
            statusText,
          });
        }
      );

      revokeObjectURL(reversedVideoUrl);
      const outputUrl = URL.createObjectURL(result.blob);
      setReversedBlob(result.blob);
      setReversedVideoUrl(outputUrl);
      setOutputFormat(result.format);

      setProcState({
        isProcessing: false,
        progress: 100,
        statusText: 'Video berhasil diputar terbalik!',
      });

      toast.success('Video Selesai Dibalik', 'Pratinjau video rewind siap ditonton dan diunduh.');
    } catch (err: any) {
      console.error(err);
      setProcState({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal memproses video',
        error: err.message,
      });
      toast.error('Gagal Membalik Video', err.message || 'Terjadi kesalahan saat merender video');
    }
  };

  const handleCancel = () => {
    if (engineRef.current) {
      engineRef.current.cancel();
      setProcState({
        isProcessing: false,
        progress: 0,
        statusText: 'Dibatalkan',
      });
      toast.info('Dibatalkan', 'Proses pembalikan video dihentikan.');
    }
  };

  const handleDownload = () => {
    if (reversedBlob) {
      const ext = outputFormat === 'mp4' ? 'mp4' : 'webm';
      downloadBlob(reversedBlob, `ctools-reversed.${ext}`);
    }
  };

  const handleReset = () => {
    if (procState.isProcessing && engineRef.current) {
      engineRef.current.cancel();
    }
    revokeObjectURL(videoSrc);
    revokeObjectURL(reversedVideoUrl);
    setSelectedFile(null);
    setFileMeta(null);
    setVideoSrc(null);
    setReversedBlob(null);
    setReversedVideoUrl(null);
    setProcState({ isProcessing: false, progress: 0, statusText: '' });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <span>Video Reverse</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20">
              Rewind FX
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Putar balik urutan frame video dan audio secara lokal langsung di browser.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!selectedFile ? (
        <div className="space-y-4">
          <UploadBox
            onFileSelect={handleFileSelect}
            allowedTypes={['video/mp4', 'video/webm', 'video/quicktime']}
            maxSizeMB={80}
            title="Pilih atau Tarik File Video"
            subtitle="Mendukung format MP4, WebM, MOV hingga 80 MB"
            icon={<Film className="w-8 h-8 sm:w-10 sm:h-10" />}
          />

          <div className="p-4 rounded-xl bg-slate-100/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
            <p>
              <strong>Fitur:</strong> Mendukung pembalikan audio (reverse sound), kecepatan playback kustom (0.75x - 1.5x), dan ekspor langsung tanpa upload ke server.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* File Meta & Action Buttons */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {fileMeta && <FileInfo metadata={fileMeta} onClear={handleReset} className="flex-1" />}

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleReset}
                disabled={procState.isProcessing}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Ganti Video</span>
              </button>

              {reversedVideoUrl && (
                <button
                  onClick={handleDownload}
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download ({outputFormat.toUpperCase()})</span>
                </button>
              )}
            </div>
          </div>

          {/* Progress Bar when processing */}
          {procState.isProcessing && (
            <div className="p-5 rounded-2xl bg-indigo-500/5 dark:bg-indigo-950/30 border border-indigo-500/20 space-y-3">
              <ProgressBar
                progress={procState.progress}
                statusText={procState.statusText}
                subText="Membalik frame video & audio di memori browser..."
              />
              <div className="flex justify-end">
                <button
                  onClick={handleCancel}
                  className="text-xs font-semibold px-3 py-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                >
                  Batalkan Proses
                </button>
              </div>
            </div>
          )}

          {/* Settings and Preview Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Options Panel (Left) */}
            <div className="lg:col-span-5 space-y-5 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                <Rewind className="w-4 h-4 text-indigo-500" />
                <span>Pengaturan Reverse</span>
              </h3>

              {/* Audio Mode */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Mode Suara / Audio</span>
                </label>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                  <button
                    onClick={() => setAudioMode('reverse')}
                    className={`py-2 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      audioMode === 'reverse'
                        ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    Reverse Audio
                  </button>
                  <button
                    onClick={() => setAudioMode('mute')}
                    className={`py-2 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      audioMode === 'mute'
                        ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    Mute (Hening)
                  </button>
                  <button
                    onClick={() => setAudioMode('original')}
                    className={`py-2 px-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                      audioMode === 'original'
                        ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    Original
                  </button>
                </div>
              </div>

              {/* Speed / Playback rate */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                  <Gauge className="w-3.5 h-3.5 text-slate-400" />
                  <span>Kecepatan Pemutaran ({speed}x)</span>
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[0.75, 1.0, 1.25, 1.5].map((s) => (
                    <button
                      key={s}
                      onClick={() => setSpeed(s)}
                      className={`py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                        speed === s
                          ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {s}x
                    </button>
                  ))}
                </div>
              </div>

              {/* Target FPS */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                  <Film className="w-3.5 h-3.5 text-slate-400" />
                  <span>Frame Rate Target</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[24, 30].map((f) => (
                    <button
                      key={f}
                      onClick={() => setFps(f)}
                      className={`py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                        fps === f
                          ? 'border-indigo-500 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {f} FPS {f === 24 ? '(Standar Cepat)' : '(Super Smooth)'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Start Reverse Button */}
              <button
                onClick={handleStartReversing}
                disabled={procState.isProcessing}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/25 transition-all cursor-pointer"
              >
                <Rewind className="w-4 h-4" />
                <span>{procState.isProcessing ? 'Sedang Memproses...' : 'Mulai Putar Terbalik'}</span>
              </button>
            </div>

            {/* Video Players (Right) */}
            <div className="lg:col-span-7 space-y-4">
              {reversedVideoUrl ? (
                /* Reversed Video Result */
                <div className="bg-slate-950 rounded-2xl border border-indigo-500/40 p-4 space-y-3 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                        Hasil Video Terbalik (Rewind)
                      </span>
                    </div>
                    <button
                      onClick={handleDownload}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>

                  <video
                    src={reversedVideoUrl}
                    controls
                    autoPlay
                    loop
                    className="w-full max-h-[380px] rounded-xl bg-black object-contain mx-auto"
                  />
                </div>
              ) : null}

              {/* Original Video Preview */}
              <div className="bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-bold uppercase tracking-wider">
                    {reversedVideoUrl ? 'Video Asli (Referensi)' : 'Pratinjau Video'}
                  </span>
                  {fileMeta?.duration && (
                    <span>Durasi: {Math.round(fileMeta.duration)} detik</span>
                  )}
                </div>

                {videoSrc && (
                  <video
                    src={videoSrc}
                    controls
                    className="w-full max-h-[320px] rounded-xl bg-black object-contain mx-auto"
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
