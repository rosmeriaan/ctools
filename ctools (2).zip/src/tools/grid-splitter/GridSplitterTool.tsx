import React, { useState, useRef } from 'react';
import JSZip from 'jszip';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata } from '../../types';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { Grid, Download, Image as ImageIcon, Sparkles, FileArchive } from 'lucide-react';

interface GridConfig {
  id: string;
  name: string;
  cols: number;
  rows: number;
}

const GRID_PRESETS: GridConfig[] = [
  { id: '3x3', name: '3x3 Giant Grid (9 Kotak)', cols: 3, rows: 3 },
  { id: '3x2', name: '3x2 Panorama (6 Kotak)', cols: 3, rows: 2 },
  { id: '3x1', name: '3x1 Horizontal Strip (3 Kotak)', cols: 3, rows: 1 },
  { id: '2x2', name: '2x2 Square Grid (4 Kotak)', cols: 2, rows: 2 },
  { id: '1x3', name: '1x3 Vertical Strip (3 Kotak)', cols: 1, rows: 3 },
];

export const GridSplitterTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [imageSrc, setImageSrc] = useState<string>('');
  const [selectedGrid, setSelectedGrid] = useState<string>('3x3');

  const [tiles, setTiles] = useState<{ id: number; dataUrl: string; blob: Blob; col: number; row: number }[]>([]);
  const [isSplitting, setIsSplitting] = useState<boolean>(false);

  const originalImgRef = useRef<HTMLImageElement | null>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (imageSrc) URL.revokeObjectURL(imageSrc);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setImageSrc(url);
    setTiles([]);

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });

    const img = new Image();
    img.src = url;
    img.onload = () => {
      originalImgRef.current = img;
      splitImage(img, selectedGrid);
    };
  };

  const splitImage = async (img: HTMLImageElement, gridId: string) => {
    const config = GRID_PRESETS.find((g) => g.id === gridId) || GRID_PRESETS[0];
    const { cols, rows } = config;

    setIsSplitting(true);
    const tileW = Math.floor(img.naturalWidth / cols);
    const tileH = Math.floor(img.naturalHeight / rows);

    const resultList: { id: number; dataUrl: string; blob: Blob; col: number; row: number }[] = [];
    let count = 1;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const canvas = document.createElement('canvas');
        canvas.width = tileW;
        canvas.height = tileH;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(
            img,
            c * tileW,
            r * tileH,
            tileW,
            tileH,
            0,
            0,
            tileW,
            tileH
          );

          const dataUrl = canvas.toDataURL('image/png', 1.0);
          const blob = await new Promise<Blob>((res) => canvas.toBlob((b) => res(b!), 'image/png'));

          resultList.push({
            id: count++,
            dataUrl,
            blob,
            col: c,
            row: r,
          });
        }
      }
    }

    setTiles(resultList);
    setIsSplitting(false);
  };

  const handleGridChange = (gridId: string) => {
    setSelectedGrid(gridId);
    if (originalImgRef.current) {
      splitImage(originalImgRef.current, gridId);
    }
  };

  const handleDownloadZip = async () => {
    if (tiles.length === 0 || !file) return;

    const zip = new JSZip();
    const folder = zip.folder('instagram-grid') || zip;

    // Instagram feeds are uploaded in reverse order (bottom-right first to top-left last)
    tiles.forEach((t) => {
      const orderNum = String(t.id).padStart(2, '0');
      folder.file(`grid_tile_${orderNum}.png`, t.blob);
    });

    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    downloadBlob(zipBlob, `ctools-grid-${selectedGrid}-${baseName}.zip`);
    toast.success('Berhasil', 'Seluruh potongan grid berhasil diunduh dalam ZIP.');
  };

  const handleReset = () => {
    if (imageSrc) URL.revokeObjectURL(imageSrc);
    setFile(null);
    setFileMetadata(null);
    setImageSrc('');
    setTiles([]);
    originalImgRef.current = null;
  };

  const currentConfig = GRID_PRESETS.find((g) => g.id === selectedGrid) || GRID_PRESETS[0];

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Grid className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Social Media Grid Splitter</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              3x3 / 3x2 / 3x1 Feed
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Potong foto panorama resolusi tinggi menjadi susunan grid feed Instagram bernomor urut.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['image/png', 'image/jpeg', 'image/webp']}
          maxSizeMB={40}
          title="Pilih Gambar untuk Dipotong Jadi Grid"
          description="Mendukung JPG, PNG, WEBP hingga 40 MB"
          icon={<ImageIcon className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Pratinjau Susunan Grid ({tiles.length} Kotak):
                </h3>
                <span className="text-xs text-slate-400">
                  *Nomor menunjukkan urutan upload feed
                </span>
              </div>

              {/* Grid visual container */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: `repeat(${currentConfig.cols}, minmax(0, 1fr))`,
                  gap: '4px',
                }}
                className="bg-slate-900 p-2 rounded-2xl border border-slate-800 max-h-[460px] overflow-y-auto"
              >
                {tiles.map((t) => (
                  <div key={t.id} className="relative group aspect-square rounded-lg overflow-hidden bg-slate-950">
                    <img src={t.dataUrl} alt={`Tile ${t.id}`} className="w-full h-full object-cover" />
                    <div className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-md bg-blue-600 text-white font-mono font-bold text-xs shadow-md">
                      #{t.id}
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={handleDownloadZip}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
              >
                <FileArchive className="w-4 h-4" />
                <span>Download Semua Potongan (ZIP)</span>
              </button>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Pilih Pola Grid:
              </h3>

              <div className="space-y-2">
                {GRID_PRESETS.map((g) => {
                  const isSel = selectedGrid === g.id;
                  return (
                    <button
                      key={g.id}
                      onClick={() => handleGridChange(g.id)}
                      className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                        isSel
                          ? 'border-blue-600 bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span className="text-xs">{g.name}</span>
                      <span className="text-[11px] font-mono opacity-60">
                        {g.cols}x{g.rows}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs text-slate-500 dark:text-slate-400 space-y-1.5 leading-relaxed">
                <span className="font-bold text-slate-700 dark:text-slate-200 block">Tips Feed Instagram:</span>
                <p>
                  Unggah file mulai dari nomor urut terakhir (misal: <strong>#9</strong>, lalu #8, hingga <strong>#1</strong>) agar susunan foto di profil Instagram tampak sempurna.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
