import React, { useState } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { formatFileSize, formatDuration } from '../../utils/formatters';
import { toast } from '../../utils/toast';
import { Info, Copy, Check, Film, Music, Image as ImageIcon, FileCode, CheckCircle2 } from 'lucide-react';

interface MediaInspectionData {
  fileName: string;
  fileSize: number;
  fileType: string;
  mediaCategory: 'video' | 'audio' | 'image' | 'other';
  lastModified: string;
  duration?: number;
  width?: number;
  height?: number;
  aspectRatio?: string;
  megapixels?: string;
  channels?: number;
  sampleRate?: number;
  estimatedBitrateKbps?: number;
}

export const MediaInfoTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [info, setInfo] = useState<MediaInspectionData | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const handleFileSelect = async (selectedFile: File) => {
    setFile(selectedFile);

    const type = selectedFile.type;
    let category: 'video' | 'audio' | 'image' | 'other' = 'other';
    if (type.startsWith('video/')) category = 'video';
    else if (type.startsWith('audio/')) category = 'audio';
    else if (type.startsWith('image/')) category = 'image';

    const baseData: MediaInspectionData = {
      fileName: selectedFile.name,
      fileSize: selectedFile.size,
      fileType: selectedFile.type || 'Unknown MIME',
      mediaCategory: category,
      lastModified: new Date(selectedFile.lastModified).toLocaleString('id-ID'),
    };

    if (category === 'video') {
      const url = URL.createObjectURL(selectedFile);
      const video = document.createElement('video');
      video.src = url;
      video.onloadedmetadata = () => {
        const dur = video.duration || 0;
        const w = video.videoWidth || 0;
        const h = video.videoHeight || 0;
        const bitrate = dur > 0 ? Math.round(((selectedFile.size * 8) / dur) / 1000) : 0;
        const mp = ((w * h) / 1000000).toFixed(2);

        setInfo({
          ...baseData,
          duration: dur,
          width: w,
          height: h,
          aspectRatio: h > 0 ? `${(w / h).toFixed(2)}:1` : '-',
          megapixels: mp,
          estimatedBitrateKbps: bitrate,
        });
        URL.revokeObjectURL(url);
      };
    } else if (category === 'audio') {
      const url = URL.createObjectURL(selectedFile);
      const audio = document.createElement('audio');
      audio.src = url;
      audio.onloadedmetadata = () => {
        const dur = audio.duration || 0;
        const bitrate = dur > 0 ? Math.round(((selectedFile.size * 8) / dur) / 1000) : 0;
        setInfo({
          ...baseData,
          duration: dur,
          estimatedBitrateKbps: bitrate,
        });
        URL.revokeObjectURL(url);
      };
    } else if (category === 'image') {
      const url = URL.createObjectURL(selectedFile);
      const img = new Image();
      img.src = url;
      img.onload = () => {
        const w = img.naturalWidth;
        const h = img.naturalHeight;
        const mp = ((w * h) / 1000000).toFixed(2);
        setInfo({
          ...baseData,
          width: w,
          height: h,
          aspectRatio: h > 0 ? `${(w / h).toFixed(2)}:1` : '-',
          megapixels: mp,
        });
        URL.revokeObjectURL(url);
      };
    } else {
      setInfo(baseData);
    }
  };

  const copyJson = () => {
    if (!info) return;
    navigator.clipboard.writeText(JSON.stringify(info, null, 2));
    setCopied(true);
    toast.success('Disalin', 'Metadata berhasil disalin ke clipboard.');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    setFile(null);
    setInfo(null);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Info className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Media Info & Metadata Inspector</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Zero Upload Client-Side
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Inspeksi mendalam parameter teknis video, audio, dan gambar secara instan tanpa mengunggah ke server.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['*/*']}
          maxSizeMB={500}
          title="Pilih Berkas Media Apa Saja (Video / Audio / Gambar)"
          description="Mendukung MP4, MP3, WAV, JPG, PNG, WEBM, MOV, GIF hingga 500 MB"
          icon={<FileCode className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-600/10 text-blue-600 flex items-center justify-center">
                  {info?.mediaCategory === 'video' ? (
                    <Film className="w-6 h-6" />
                  ) : info?.mediaCategory === 'audio' ? (
                    <Music className="w-6 h-6" />
                  ) : (
                    <ImageIcon className="w-6 h-6" />
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">{info?.fileName}</h3>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">
                    {formatFileSize(info?.fileSize || 0)} • {info?.fileType}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={copyJson}
                  className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-sm"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'Tersalin' : 'Salin JSON'}</span>
                </button>
                <button
                  onClick={handleReset}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
                >
                  Pilih File Lain
                </button>
              </div>
            </div>

            {/* Technical Specifications Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                <span className="text-[11px] text-slate-400 font-semibold block">MIME Type</span>
                <span className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200 mt-1 block">
                  {info?.fileType}
                </span>
              </div>

              {info?.duration !== undefined && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                  <span className="text-[11px] text-slate-400 font-semibold block">Durasi Total</span>
                  <span className="text-sm font-mono font-bold text-blue-600 dark:text-blue-400 mt-1 block">
                    {formatDuration(info.duration)} ({info.duration.toFixed(2)}s)
                  </span>
                </div>
              )}

              {info?.width !== undefined && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                  <span className="text-[11px] text-slate-400 font-semibold block">Dimensi Resolusi</span>
                  <span className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200 mt-1 block">
                    {info.width} × {info.height} px
                  </span>
                </div>
              )}

              {info?.aspectRatio && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                  <span className="text-[11px] text-slate-400 font-semibold block">Rasio Aspek</span>
                  <span className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200 mt-1 block">
                    {info.aspectRatio}
                  </span>
                </div>
              )}

              {info?.megapixels && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                  <span className="text-[11px] text-slate-400 font-semibold block">Megapixels</span>
                  <span className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200 mt-1 block">
                    {info.megapixels} MP
                  </span>
                </div>
              )}

              {info?.estimatedBitrateKbps !== undefined && info.estimatedBitrateKbps > 0 && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                  <span className="text-[11px] text-slate-400 font-semibold block">Estimasi Bitrate</span>
                  <span className="text-sm font-mono font-bold text-emerald-600 dark:text-emerald-400 mt-1 block">
                    ~{info.estimatedBitrateKbps} kbps ({(info.estimatedBitrateKbps / 1000).toFixed(2)} Mbps)
                  </span>
                </div>
              )}

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                <span className="text-[11px] text-slate-400 font-semibold block">Waktu Modifikasi</span>
                <span className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mt-1 block">
                  {info?.lastModified}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
