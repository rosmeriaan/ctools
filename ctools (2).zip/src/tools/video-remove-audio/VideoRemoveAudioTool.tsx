import React, { useState } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { FFmpegCommands } from '../../core/ffmpeg/commands';
import { VolumeX, Film, Download, CheckCircle } from 'lucide-react';

export const VideoRemoveAudioTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap menghapus audio',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const handleFileSelect = (selectedFile: File) => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setVideoUrl(url);
    setOutputBlob(null);
    setOutputUrl('');

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleRemoveAudio = async () => {
    if (!file) return;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan pemisahan stream audio...',
      step: 'preparing',
    });

    try {
      const inputExt = file.name.split('.').pop() || 'mp4';
      const inputName = `input.${inputExt}`;
      const outputName = 'video_without_audio.mp4';

      const args = FFmpegCommands.removeAudio(inputName, outputName);

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Menghapus audio (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Audio berhasil dihapus!',
        step: 'completed',
      });
      toast.success('Berhasil', 'Trek audio berhasil dihilangkan (Muted video).');
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal memproses video.',
        step: 'error',
        error: err?.message || 'Error',
      });
      toast.error('Gagal', err?.message || 'Gagal menghapus audio.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob || !file) return;
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    downloadBlob(outputBlob, `ctools-mute-${baseName}.mp4`);
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setVideoUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <VolumeX className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Remove Audio (Mute Video)</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Lossless Direct Stream
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Hilangkan suara latar belakang dari video dengan sangat cepat tanpa menurunkan kualitas visual.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['video/mp4', 'video/webm', 'video/quicktime']}
          maxSizeMB={200}
          title="Pilih Video untuk Dihapus Suaranya"
          description="Mendukung MP4, WebM, MOV hingga 200 MB"
          icon={<Film className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                <video src={videoUrl} controls className="w-full h-full object-contain" />
              </div>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Aksi Pembersihan Trek Audio
              </h3>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs space-y-2 text-slate-600 dark:text-slate-300">
                <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                  <span>Proses Cepat & Preservasi Kualitas</span>
                </div>
                <p className="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                  Tool ini menghapus stream trek audio (parameter <code>-an</code>) dan mempertahankan stream video asli (<code>-c:v copy</code>) sehingga proses selesai dalam hitungan detik.
                </p>
              </div>

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputUrl ? (
                <div className="space-y-3">
                  <div className="rounded-xl overflow-hidden bg-black aspect-video">
                    <video src={outputUrl} controls className="w-full h-full object-contain" />
                  </div>
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Video Hening ({formatFileSize(outputBlob?.size || 0)})</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleRemoveAudio}
                  disabled={processing.isProcessing}
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                >
                  <VolumeX className="w-4 h-4" />
                  <span>{processing.isProcessing ? 'Menghapus Suara...' : 'Hapus Audio Sekarang'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
