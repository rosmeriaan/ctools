import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import { downloadTextFile } from '../../utils/file';
import { Sliders, Copy, Check, Download, Zap, Sparkles } from 'lucide-react';

export const KeyframeCalculatorTool: React.FC = () => {
  const [bpm, setBpm] = useState<number>(128);
  const [fps, setFps] = useState<number>(60);
  const [copied, setCopied] = useState<boolean>(false);

  // Math calculations
  const beatSec = 60 / bpm;
  const beatMs = (60 / bpm) * 1000;

  const intervals = [
    { name: '1 Bar (4 Beats / Bar Transisi)', factor: 4 },
    { name: '2 Beats (Setengah Bar)', factor: 2 },
    { name: '1 Beat (Ketukan Utama / Kick)', factor: 1 },
    { name: '1/2 Beat (8th Note / Snare)', factor: 0.5 },
    { name: '1/4 Beat (16th Note / JJ Shake)', factor: 0.25 },
    { name: '1/8 Beat (32nd Note / Ultra Fast Shake)', factor: 0.125 },
    { name: '1/16 Beat (64th Note / Glitch Flash)', factor: 0.0625 },
  ];

  const results = intervals.map((item) => {
    const durMs = beatMs * item.factor;
    const durSec = beatSec * item.factor;
    const exactFrames = durSec * fps;
    const roundedFrames = Math.round(exactFrames);
    return {
      name: item.name,
      durMs: Math.round(durMs),
      durSec: Number(durSec.toFixed(3)),
      exactFrames: Number(exactFrames.toFixed(2)),
      roundedFrames,
    };
  });

  const handleCopy = () => {
    const text = results
      .map((r) => `${r.name}: ${r.roundedFrames} frames (${r.durMs} ms)`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Disalin', 'Tabel keyframe berhasil disalin.');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportCsv = () => {
    let csv = `BPM: ${bpm}, Target FPS: ${fps}\n`;
    csv += 'Ketukan,Durasi (ms),Durasi (detik),Frame Akurat,Frame Dibulatkan\n';
    results.forEach((r) => {
      csv += `"${r.name}",${r.durMs},${r.durSec},${r.exactFrames},${r.roundedFrames}\n`;
    });
    downloadTextFile(csv, `ctools-keyframe-${bpm}bpm-${fps}fps.csv`, 'text/csv');
    toast.success('Berhasil', 'File CSV keyframe berhasil diunduh.');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Sliders className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>JJ Beat to Keyframe Calculator</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Alight Motion & CapCut Frame Sync
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Konversi tempo BPM lagu ke durasi milidetik dan jumlah frame eksak untuk sinkronisasi animasi jedag-jedug.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Parameter Video & Musik:
            </h3>

            <div className="space-y-1.5">
              <label className="text-xs text-slate-500 flex justify-between">
                <span>Tempo Musik (BPM):</span>
                <span className="font-mono font-bold text-blue-600">{bpm} BPM</span>
              </label>
              <input
                type="number"
                min="40"
                max="240"
                value={bpm}
                onChange={(e) => setBpm(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 text-base font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
              {/* Quick BPM buttons */}
              <div className="grid grid-cols-4 gap-1.5 pt-1">
                {[100, 120, 128, 140].map((b) => (
                  <button
                    key={b}
                    onClick={() => setBpm(b)}
                    className="py-1 text-[11px] font-bold rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    {b} BPM
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
              <label className="text-xs text-slate-500">Timeline Frame Rate (FPS):</label>
              <div className="grid grid-cols-4 gap-2">
                {[24, 30, 60, 120].map((f) => (
                  <button
                    key={f}
                    onClick={() => setFps(f)}
                    className={`py-2 text-xs font-bold rounded-xl border cursor-pointer ${
                      fps === f
                        ? 'border-blue-600 bg-blue-600 text-white shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {f} FPS
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-500" />
                <span>Tabel Interval Keyframe ({bpm} BPM @ {fps} FPS)</span>
              </h3>
              <div className="flex gap-2">
                <button
                  onClick={handleCopy}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Tersalin' : 'Salin'}</span>
                </button>
                <button
                  onClick={handleExportCsv}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400">
                    <th className="py-2.5 px-3">Tipe Ritme / Shake</th>
                    <th className="py-2.5 px-3 font-mono">Durasi (ms)</th>
                    <th className="py-2.5 px-3 font-mono">Detik</th>
                    <th className="py-2.5 px-3 font-mono text-right text-blue-600 dark:text-blue-400 font-bold">
                      Jarak Frame (@{fps}fps)
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                  {results.map((r, i) => (
                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-sans font-semibold text-slate-800 dark:text-slate-200">
                        {r.name}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{r.durMs} ms</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{r.durSec}s</td>
                      <td className="py-2.5 px-3 text-right">
                        <span className="px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold">
                          {r.roundedFrames} frames
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
