import React, { useState, useRef, useEffect } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata } from '../../types';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { Type, Download, Layers, Sparkles, Image as ImageIcon, Move } from 'lucide-react';

export const TextBehindSubjectTool: React.FC = () => {
  const [bgFile, setBgFile] = useState<File | null>(null);
  const [bgUrl, setBgUrl] = useState<string>('');
  const [foregroundFile, setForegroundFile] = useState<File | null>(null);
  const [foregroundUrl, setForegroundUrl] = useState<string>('');

  const [text, setText] = useState<string>('CREATOR');
  const [fontFamily, setFontFamily] = useState<string>('Impact, sans-serif');
  const [fontSize, setFontSize] = useState<number>(140);
  const [textColor, setTextColor] = useState<string>('#ffffff');
  const [opacity, setOpacity] = useState<number>(90);
  const [letterSpacing, setLetterSpacing] = useState<number>(12);
  const [posX, setPosX] = useState<number>(50); // in percent
  const [posY, setPosY] = useState<number>(45); // in percent
  const [hasShadow, setHasShadow] = useState<boolean>(true);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bgImgRef = useRef<HTMLImageElement | null>(null);
  const fgImgRef = useRef<HTMLImageElement | null>(null);

  const handleBgSelect = (file: File) => {
    if (bgUrl) URL.revokeObjectURL(bgUrl);
    const url = URL.createObjectURL(file);
    setBgFile(file);
    setBgUrl(url);

    const img = new Image();
    img.src = url;
    img.onload = () => {
      bgImgRef.current = img;
      renderComposite();
    };
  };

  const handleFgSelect = (file: File) => {
    if (foregroundUrl) URL.revokeObjectURL(foregroundUrl);
    const url = URL.createObjectURL(file);
    setForegroundFile(file);
    setForegroundUrl(url);

    const img = new Image();
    img.src = url;
    img.onload = () => {
      fgImgRef.current = img;
      renderComposite();
    };
  };

  const renderComposite = () => {
    const canvas = canvasRef.current;
    const bgImg = bgImgRef.current;
    if (!canvas || !bgImg) return;

    canvas.width = bgImg.naturalWidth;
    canvas.height = bgImg.naturalHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 1. Draw Background Layer
    ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

    // 2. Draw Text Behind Layer
    ctx.save();
    ctx.font = `900 ${fontSize}px ${fontFamily}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = textColor;
    ctx.globalAlpha = opacity / 100;

    if (hasShadow) {
      ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
      ctx.shadowBlur = 20;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 10;
    }

    const xCoord = (canvas.width * posX) / 100;
    const yCoord = (canvas.height * posY) / 100;

    // Support letter spacing manually or via ctx.letterSpacing
    if ('letterSpacing' in ctx) {
      (ctx as any).letterSpacing = `${letterSpacing}px`;
    }
    ctx.fillText(text.toUpperCase(), xCoord, yCoord);
    ctx.restore();

    // 3. Draw Foreground Subject Layer (if provided)
    if (fgImgRef.current) {
      ctx.drawImage(fgImgRef.current, 0, 0, canvas.width, canvas.height);
    }
  };

  useEffect(() => {
    if (bgImgRef.current) {
      renderComposite();
    }
  }, [text, fontFamily, fontSize, textColor, opacity, letterSpacing, posX, posY, hasShadow, foregroundUrl]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.toBlob((blob) => {
      if (blob) {
        downloadBlob(blob, 'ctools-text-behind-subject.png');
        toast.success('Berhasil', 'Poster typography berhasil diunduh.');
      }
    }, 'image/png');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Type className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Text Behind Subject Effect</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Layered Typography
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Buat efek tipografi viral di belakang subjek/orang untuk thumbnail YouTube dan Reels.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!bgFile ? (
        <UploadBox
          onFileSelect={handleBgSelect}
          allowedTypes={['image/png', 'image/jpeg', 'image/webp']}
          maxSizeMB={30}
          title="Langkah 1: Unggah Foto Background / Subjek Utama"
          description="Mendukung JPG, PNG, WEBP hingga 30 MB"
          icon={<ImageIcon className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="relative rounded-xl overflow-hidden bg-slate-950 flex items-center justify-center min-h-64">
                <canvas ref={canvasRef} className="max-h-[460px] w-auto max-w-full object-contain rounded-lg" />
              </div>

              <button
                onClick={handleDownload}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Poster Hasil (PNG)</span>
              </button>
            </div>

            {/* Optional Step 2: Foreground Cutout */}
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-blue-500" />
                  <span>Layer Subjek Depan (Cutout PNG Transparan)</span>
                </span>
                {foregroundFile && (
                  <button
                    onClick={() => {
                      setForegroundFile(null);
                      setForegroundUrl('');
                      fgImgRef.current = null;
                      renderComposite();
                    }}
                    className="text-[11px] text-red-500 hover:underline cursor-pointer"
                  >
                    Hapus Layer
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                *Opsional: Unggah gambar cutout transparan untuk meletakkan teks tepat di belakang orang/objek.
              </p>
              <label className="block w-full py-2.5 px-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 text-center cursor-pointer text-xs font-semibold text-slate-600 dark:text-slate-300">
                <input
                  type="file"
                  accept="image/png,image/webp"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handleFgSelect(e.target.files[0]);
                  }}
                  className="hidden"
                />
                {foregroundFile ? `✓ ${foregroundFile.name}` : '+ Pilih Gambar Subjek Transparan (PNG)'}
              </label>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Kustomisasi Tipografi Teks:
              </h3>

              {/* Text Value */}
              <div className="space-y-1">
                <label className="text-xs text-slate-500">Teks Judul:</label>
                <input
                  type="text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 uppercase"
                />
              </div>

              {/* Font Family & Size */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-slate-500">Font:</label>
                  <select
                    value={fontFamily}
                    onChange={(e) => setFontFamily(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-bold"
                  >
                    <option value="Impact, sans-serif">Impact (Bold Heavy)</option>
                    <option value="'Arial Black', sans-serif">Arial Black</option>
                    <option value="'Trebuchet MS', sans-serif">Trebuchet MS</option>
                    <option value="Georgia, serif">Georgia (Serif)</option>
                    <option value="Courier New, monospace">Courier (Monospace)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-500">Ukuran ({fontSize}px):</label>
                  <input
                    type="range"
                    min="30"
                    max="350"
                    value={fontSize}
                    onChange={(e) => setFontSize(Number(e.target.value))}
                    className="w-full accent-blue-600 cursor-pointer pt-2"
                  />
                </div>
              </div>

              {/* Color & Opacity */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs text-slate-500">Warna Teks:</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={textColor}
                      onChange={(e) => setTextColor(e.target.value)}
                      className="w-8 h-8 rounded-lg border cursor-pointer"
                    />
                    <span className="text-xs font-mono">{textColor}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-500">Opasitas ({opacity}%):</label>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={opacity}
                    onChange={(e) => setOpacity(Number(e.target.value))}
                    className="w-full accent-blue-600 cursor-pointer pt-2"
                  />
                </div>
              </div>

              {/* Position sliders */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Move className="w-3.5 h-3.5 text-blue-500" />
                  <span>Posisi Teks (X: {posX}%, Y: {posY}%)</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-slate-400">Horizontal (X)</span>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={posX}
                      onChange={(e) => setPosX(Number(e.target.value))}
                      className="w-full accent-blue-600 cursor-pointer"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400">Vertikal (Y)</span>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={posY}
                      onChange={(e) => setPosY(Number(e.target.value))}
                      className="w-full accent-blue-600 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Letter spacing & shadow */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Letter Spacing: {letterSpacing}px</span>
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-700 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={hasShadow}
                      onChange={(e) => setHasShadow(e.target.checked)}
                      className="rounded accent-blue-600"
                    />
                    <span>Drop Shadow</span>
                  </label>
                </div>
                <input
                  type="range"
                  min="0"
                  max="40"
                  value={letterSpacing}
                  onChange={(e) => setLetterSpacing(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
