import React, { useState, useRef, useEffect } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata } from '../../types';
import { formatDuration } from '../../utils/formatters';
import { downloadTextFile } from '../../utils/file';
import { toast } from '../../utils/toast';
import { Bookmark, Play, Pause, RotateCcw, Download, Trash2, Music2, Plus, Zap } from 'lucide-react';

interface BeatMarker {
  id: string;
  timeSec: number;
  timeMs: number;
}

export const BeatMarkerTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [duration, setDuration] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const [markers, setMarkers] = useState<BeatMarker[]>([]);
  const [tapEffect, setTapEffect] = useState<boolean>(false);

  const audioRef = useRef<HTMLAudioElement>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setAudioUrl(url);
    setMarkers([]);

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const addMarkerNow = () => {
    if (!audioRef.current) return;
    const timeSec = audioRef.current.currentTime;
    const timeMs = Math.round(timeSec * 1000);

    const newMarker: BeatMarker = {
      id: `${Date.now()}-${Math.random()}`,
      timeSec: Number(timeSec.toFixed(3)),
      timeMs,
    };

    setMarkers((prev) => [...prev, newMarker].sort((a, b) => a.timeSec - b.timeSec));
    setTapEffect(true);
    setTimeout(() => setTapEffect(false), 100);
  };

  // Keyboard shortcut listener (Spacebar for tap when playing, or K key)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyK' || (e.code === 'Space' && e.target === document.body)) {
        e.preventDefault();
        addMarkerNow();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const removeMarker = (id: string) => {
    setMarkers((prev) => prev.filter((m) => m.id !== id));
  };

  const handleExportJSON = () => {
    if (markers.length === 0) return;
    const data = JSON.stringify(
      {
        total_markers: markers.length,
        duration: duration,
        markers: markers.map((m, i) => ({
          index: i + 1,
          time_seconds: m.timeSec,
          time_ms: m.timeMs,
        })),
      },
      null,
      2
    );
    downloadTextFile(data, 'ctools-beat-markers.json', 'application/json');
    toast.success('Berhasil', 'File JSON markers berhasil diunduh.');
  };

  const handleExportCSV = () => {
    if (markers.length === 0) return;
    let csv = 'Index,TimeSeconds,TimeMilliseconds,Frame30fps,Frame60fps\n';
    markers.forEach((m, i) => {
      const f30 = Math.round(m.timeSec * 30);
      const f60 = Math.round(m.timeSec * 60);
      csv += `${i + 1},${m.timeSec},${m.timeMs},${f30},${f60}\n`;
    });
    downloadTextFile(csv, 'ctools-beat-markers.csv', 'text/csv');
    toast.success('Berhasil', 'File CSV markers berhasil diunduh.');
  };

  const handleExportTXT = () => {
    if (markers.length === 0) return;
    const txt = markers.map((m) => m.timeSec.toFixed(3)).join('\n');
    downloadTextFile(txt, 'ctools-beat-timestamps.txt', 'text/plain');
    toast.success('Berhasil', 'File TXT timestamps berhasil diunduh.');
  };

  const handleReset = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setFile(null);
    setFileMetadata(null);
    setAudioUrl('');
    setMarkers([]);
    setIsPlaying(false);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Bookmark className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Beat Marker & Rhythm Tapper</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Keyframe Export (JSON/CSV/TXT)
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Putar audio dan tap tombol / tekan spasi untuk menandai titik ketukan beat bagi JJ editor.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['audio/mpeg', 'audio/wav', 'audio/ogg', 'video/mp4', 'audio/mp4']}
          maxSizeMB={50}
          title="Pilih Audio untuk Ditandai Beat-nya"
          description="Mendukung MP3, WAV, OGG, M4A, MP4"
          icon={<Music2 className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <audio
                ref={audioRef}
                src={audioUrl}
                onLoadedMetadata={handleLoadedMetadata}
                onTimeUpdate={handleTimeUpdate}
                onEnded={() => setIsPlaying(false)}
                className="hidden"
              />

              {/* Player Scrubber */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                  <span>{formatDuration(currentTime)}</span>
                  <span>{formatDuration(duration)}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  step="0.01"
                  value={currentTime}
                  onChange={(e) => {
                    const t = Number(e.target.value);
                    if (audioRef.current) audioRef.current.currentTime = t;
                    setCurrentTime(t);
                  }}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              {/* Play & Giant Tap Button */}
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <button
                  onClick={togglePlay}
                  className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  <span>{isPlaying ? 'Pause Audio' : 'Play Audio'}</span>
                </button>

                <button
                  onClick={addMarkerNow}
                  className={`w-full flex-1 py-4 px-6 rounded-2xl text-white font-black text-base uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xl ${
                    tapEffect
                      ? 'scale-95 bg-amber-500 shadow-amber-500/40'
                      : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-blue-600/30'
                  }`}
                >
                  <Zap className="w-5 h-5" />
                  <span>TAP BEAT SEKARANG (K / Space)</span>
                </button>
              </div>

              {/* Mini timeline marker points */}
              <div className="relative h-6 bg-slate-100 dark:bg-slate-950 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800">
                {markers.map((m) => {
                  const pct = duration > 0 ? (m.timeSec / duration) * 100 : 0;
                  return (
                    <div
                      key={m.id}
                      style={{ left: `${pct}%` }}
                      className="absolute top-0 bottom-0 w-1 bg-amber-400 -translate-x-1/2"
                      title={`Beat @ ${m.timeSec}s`}
                    />
                  );
                })}
              </div>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Daftar Beat ({markers.length} Titik)
                </h3>
                {markers.length > 0 && (
                  <button
                    onClick={() => setMarkers([])}
                    className="text-xs text-red-500 hover:underline cursor-pointer"
                  >
                    Reset
                  </button>
                )}
              </div>

              {markers.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                  Belum ada penanda beat. Putar lagu lalu tekan tombol Tap Beat!
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="max-h-60 overflow-y-auto space-y-1.5 p-1">
                    {markers.map((m, idx) => (
                      <div
                        key={m.id}
                        className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 text-xs font-mono"
                      >
                        <span className="font-bold text-blue-600">#{idx + 1}</span>
                        <span className="text-slate-800 dark:text-slate-200">
                          {formatDuration(m.timeSec)} ({m.timeSec}s)
                        </span>
                        <button
                          onClick={() => removeMarker(m.id)}
                          className="text-slate-400 hover:text-red-500 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={handleExportJSON}
                      className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Ekspor JSON (Keyframe Data)</span>
                    </button>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={handleExportCSV}
                        className="py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Ekspor CSV</span>
                      </button>
                      <button
                        onClick={handleExportTXT}
                        className="py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Ekspor TXT</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
