import * as lamejs from 'lamejs';

/**
 * Pure Browser-side MP4 to MP3 Converter Engine
 * Decodes video audio track to PCM AudioBuffer using Web Audio API
 * Encodes PCM samples into MP3 using lamejs in chunked micro-tasks to keep UI responsive
 */

export interface Mp3ConversionOptions {
  bitrateKbps: 128 | 192 | 256 | 320;
  startTime?: number; // seconds
  endTime?: number; // seconds
  channels?: 1 | 2; // Mono or Stereo
}

export class AudioConverterEngine {
  private isCancelled: boolean = false;

  cancel() {
    this.isCancelled = true;
  }

  async convertToMp3(
    file: File,
    options: Mp3ConversionOptions,
    onProgress?: (progress: number, status: string) => void
  ): Promise<{ blob: Blob; duration: number; sampleRate: number }> {
    this.isCancelled = false;
    onProgress?.(5, 'Membaca data berkas video...');

    // Step 1: Read ArrayBuffer
    const arrayBuffer = await file.arrayBuffer();

    if (this.isCancelled) throw new Error('Dibatalkan oleh pengguna.');

    onProgress?.(15, 'Mendekode trek audio PCM (Web Audio API)...');

    // Step 2: Decode Audio Data
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) {
      throw new Error('Web Audio API tidak didukung pada peramban ini.');
    }

    const audioContext = new AudioCtx();
    let audioBuffer: AudioBuffer;

    try {
      audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    } catch (err: any) {
      if (audioContext.state !== 'closed') audioContext.close().catch(() => {});
      throw new Error('Berkas video tidak memiliki trek audio yang valid atau format tidak didukung.');
    }

    if (this.isCancelled) {
      audioContext.close().catch(() => {});
      throw new Error('Dibatalkan oleh pengguna.');
    }

    const sampleRate = audioBuffer.sampleRate;
    const numChannels = Math.min(options.channels || 2, audioBuffer.numberOfChannels);
    const totalDuration = audioBuffer.duration;

    // Slice range if specified
    const startSec = Math.max(0, options.startTime || 0);
    const endSec = options.endTime && options.endTime > startSec ? Math.min(totalDuration, options.endTime) : totalDuration;
    const startSample = Math.floor(startSec * sampleRate);
    const endSample = Math.floor(endSec * sampleRate);
    const numSamples = endSample - startSample;

    onProgress?.(30, `Menginisialisasi encoder MP3 (${options.bitrateKbps} kbps)...`);

    // Prepare lamejs encoder
    // lamejs Mp3Encoder(channels, sampleRate, kbps)
    const Lame = (lamejs as any).Mp3Encoder || (lamejs as any).default?.Mp3Encoder || (window as any).lamejs?.Mp3Encoder;
    
    if (!Lame) {
      audioContext.close().catch(() => {});
      throw new Error('Pustaka lamejs MP3 encoder tidak dapat dimuat.');
    }

    const mp3Encoder = new Lame(numChannels, sampleRate, options.bitrateKbps);

    // Convert Float32Array to Int16Array
    const leftChannel = audioBuffer.getChannelData(0).subarray(startSample, endSample);
    const rightChannel = numChannels > 1 && audioBuffer.numberOfChannels > 1
      ? audioBuffer.getChannelData(1).subarray(startSample, endSample)
      : leftChannel;

    const leftInt16 = new Int16Array(numSamples);
    const rightInt16 = new Int16Array(numSamples);

    for (let i = 0; i < numSamples; i++) {
      // Clamping float32 (-1.0 to 1.0) to int16 (-32768 to 32767)
      const l = Math.max(-1, Math.min(1, leftChannel[i]));
      leftInt16[i] = l < 0 ? l * 0x8000 : l * 0x7fff;

      if (numChannels > 1) {
        const r = Math.max(-1, Math.min(1, rightChannel[i]));
        rightInt16[i] = r < 0 ? r * 0x8000 : r * 0x7fff;
      }
    }

    // Process encoding in chunks (1152 samples per MP3 frame)
    const chunkSize = 1152;
    const mp3Chunks: Uint8Array[] = [];
    const totalChunks = Math.ceil(numSamples / chunkSize);

    onProgress?.(40, `Meng-encode audio ke MP3 (${options.bitrateKbps} kbps)...`);

    for (let i = 0; i < numSamples; i += chunkSize) {
      if (this.isCancelled) {
        audioContext.close().catch(() => {});
        throw new Error('Dibatalkan oleh pengguna.');
      }

      const leftChunk = leftInt16.subarray(i, i + chunkSize);
      let mp3buf: Int8Array;

      if (numChannels === 1) {
        mp3buf = mp3Encoder.encodeBuffer(leftChunk);
      } else {
        const rightChunk = rightInt16.subarray(i, i + chunkSize);
        mp3buf = mp3Encoder.encodeBuffer(leftChunk, rightChunk);
      }

      if (mp3buf.length > 0) {
        mp3Chunks.push(new Uint8Array(mp3buf));
      }

      // Periodically yield to main loop so UI stays responsive and update progress
      if (i % (chunkSize * 30) === 0) {
        const currentChunkIdx = Math.floor(i / chunkSize);
        const percent = Math.min(96, Math.round(40 + (currentChunkIdx / totalChunks) * 55));
        onProgress?.(percent, `Meng-encode MP3 (${percent}%)...`);
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }

    // Flush remaining buffer
    const finalBuf = mp3Encoder.flush();
    if (finalBuf.length > 0) {
      mp3Chunks.push(new Uint8Array(finalBuf));
    }

    onProgress?.(99, 'Menyelesaikan berkas MP3...');

    if (audioContext.state !== 'closed') {
      audioContext.close().catch(() => {});
    }

    const outputBlob = new Blob(mp3Chunks, { type: 'audio/mp3' });

    return {
      blob: outputBlob,
      duration: endSec - startSec,
      sampleRate,
    };
  }
}
