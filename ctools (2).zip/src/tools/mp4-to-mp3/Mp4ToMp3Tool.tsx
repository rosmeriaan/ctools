import React, { useState, useRef, useEffect } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { AudioConverterEngine, Mp3ConversionOptions } from './audioConverterEngine';
import { FileMetadata, ProcessingState } from '../../types';
import { downloadBlob, revokeObjectURL } from '../../utils/file';
import { formatDuration, formatFileSize } from '../../utils/formatters';
import { toast } from '../../utils/toast';
import {
  Music2,
  RotateCcw,
  Download,
  Play,
  Pause,
  Sliders,
  Scissors,
  CheckCircle2,
  Radio,
  FileAudio,
} from 'lucide-react';

export const Mp4ToMp3Tool: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileMeta, setFileMeta] = useState<FileMetadata | null>(null);
  const [videoSrc, setVideoSrc] = useState<string | null>(null);

  // Conversion options
  const [bitrate, setBitrate] = useState<128 | 192 | 256 | 320>(256);
  const [channels, setChannels] = useState<1 | 2>(2);
  const [trimEnabled, setTrimEnabled] = useState<boolean>(false);
  const [startTime, setStartTime] = useState<number>(0);
  const [endTime, setEndTime] = useState<number>(0);

  // Result state
  const [mp3Blob, setMp3Blob] = useState<Blob | null>(null);
  const [mp3Url, setMp3Url] = useState<string | null>(null);
  const [audioDuration, setAudioDuration] = useState<number>(0);

  // Audio player state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Processing state
  const [procState, setProcState] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: '',
  });

  const engineRef = useRef<AudioConverterEngine | null>(null);

  useEffect(() => {
    return () => {
      revokeObjectURL(videoSrc);
      revokeObjectURL(mp3Url);
    };
  }, [videoSrc, mp3Url]);

  const handleFileSelect = (file: File) => {
    revokeObjectURL(videoSrc);
    revokeObjectURL(mp3Url);
    setMp3Blob(null);
    setMp3Url(null);
    setIsPlaying(false);

    const url = URL.createObjectURL(file);
    setVideoSrc(url);
    setSelectedFile(file);

    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      const dur = video.duration || 0;
      setFileMeta({
        name: file.name,
        size: file.size,
        type: file.type,
        duration: dur,
      });
      setStartTime(0);
      setEndTime(Math.floor(dur));
    };
    video.src = url;
  };

  const handleConvert = async () => {
    if (!selectedFile) return;

    const engine = new AudioConverterEngine();
    engineRef.current = engine;

    setProcState({
      isProcessing: true,
      progress: 5,
      statusText: 'Membaca video...',
    });

    try {
      const options: Mp3ConversionOptions = {
        bitrateKbps: bitrate,
        channels: channels,
        startTime: trimEnabled ? startTime : undefined,
        endTime: trimEnabled ? endTime : undefined,
      };

      const result = await engine.convertToMp3(selectedFile, options, (progress, statusText) => {
        setProcState({
          isProcessing: true,
          progress,
          statusText,
        });
      });

      revokeObjectURL(mp3Url);
      const url = URL.createObjectURL(result.blob);
      setMp3Blob(result.blob);
      setMp3Url(url);
      setAudioDuration(result.duration);

      setProcState({
        isProcessing: false,
        progress: 100,
        statusText: 'Konversi MP3 Selesai!',
      });

      toast.success('Audio Berhasil Dikonversi', `MP3 (${bitrate} kbps) siap diputar dan diunduh.`);
    } catch (err: any) {
      console.error(err);
      setProcState({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal mengonversi MP3',
        error: err.message,
      });
      toast.error('Gagal Mengonversi', err.message || 'Terjadi kesalahan saat memproses audio');
    }
  };

  const handleCancel = () => {
    if (engineRef.current) {
      engineRef.current.cancel();
      setProcState({
        isProcessing: false,
        progress: 0,
        statusText: 'Dibatalkan',
      });
      toast.info('Dibatalkan', 'Konversi MP3 dihentikan.');
    }
  };

  const handleDownload = () => {
    if (mp3Blob) {
      const baseName = selectedFile ? selectedFile.name.replace(/\.[^/.]+$/, '') : 'ctools-audio';
      downloadBlob(mp3Blob, `${baseName}.mp3`);
    }
  };

  const handleReset = () => {
    if (procState.isProcessing && engineRef.current) {
      engineRef.current.cancel();
    }
    revokeObjectURL(videoSrc);
    revokeObjectURL(mp3Url);
    setSelectedFile(null);
    setFileMeta(null);
    setVideoSrc(null);
    setMp3Blob(null);
    setMp3Url(null);
    setIsPlaying(false);
    setProcState({ isProcessing: false, progress: 0, statusText: '' });
  };

  const togglePlayAudio = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <span>MP4 to MP3 Converter</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
              Hi-Fi Audio
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ekstrak audio dari video MP4/WebM menjadi file MP3 berkualitas tinggi secara lokal.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!selectedFile ? (
        <div className="space-y-4">
          <UploadBox
            onFileSelect={handleFileSelect}
            allowedTypes={['video/mp4', 'video/webm', 'video/ogg']}
            maxSizeMB={100}
            title="Pilih atau Tarik Video MP4 / WebM"
            subtitle="Ekstrak trek audio menjadi MP3 berbitrate tinggi hingga 100 MB"
            icon={<Music2 className="w-8 h-8 sm:w-10 sm:h-10" />}
          />
        </div>
      ) : (
        <div className="space-y-6">
          {/* File Meta & Action Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {fileMeta && <FileInfo metadata={fileMeta} onClear={handleReset} className="flex-1" />}

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleReset}
                disabled={procState.isProcessing}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Ganti Video</span>
              </button>

              {mp3Url && (
                <button
                  onClick={handleDownload}
                  className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-md shadow-amber-600/20 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download MP3</span>
                </button>
              )}
            </div>
          </div>

          {/* Processing Progress Bar */}
          {procState.isProcessing && (
            <div className="p-5 rounded-2xl bg-amber-500/5 dark:bg-amber-950/30 border border-amber-500/20 space-y-3">
              <ProgressBar
                progress={procState.progress}
                statusText={procState.statusText}
                subText="Mendekode PCM dan meng-encode MP3 frame-by-frame..."
              />
              <div className="flex justify-end">
                <button
                  onClick={handleCancel}
                  className="text-xs font-semibold px-3 py-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 transition-colors cursor-pointer"
                >
                  Batalkan Konversi
                </button>
              </div>
            </div>
          )}

          {/* Settings & Player Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Options Panel (Left) */}
            <div className="lg:col-span-5 space-y-5 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                <Sliders className="w-4 h-4 text-amber-500" />
                <span>Kualitas & Format Audio</span>
              </h3>

              {/* Bitrate Selector */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center justify-between">
                  <span>Audio Bitrate (Kualitas)</span>
                  <span className="text-amber-600 dark:text-amber-400 font-bold">{bitrate} kbps</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  {([128, 192, 256, 320] as const).map((b) => (
                    <button
                      key={b}
                      onClick={() => setBitrate(b)}
                      className={`py-2 px-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer flex flex-col items-center ${
                        bitrate === b
                          ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400 ring-1 ring-amber-500/30'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span className="font-bold">{b} kbps</span>
                      <span className="text-[10px] opacity-70">
                        {b === 128 ? 'Standar' : b === 192 ? 'Medium' : b === 256 ? 'High' : 'Ultra HD'}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Channels (Stereo / Mono) */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  Channel Output
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setChannels(2)}
                    className={`py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      channels === 2
                        ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    Stereo (2 Channels)
                  </button>
                  <button
                    onClick={() => setChannels(1)}
                    className={`py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      channels === 1
                        ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    Mono (1 Channel)
                  </button>
                </div>
              </div>

              {/* Optional Audio Trimmer */}
              <div className="space-y-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={trimEnabled}
                      onChange={(e) => setTrimEnabled(e.target.checked)}
                      className="rounded accent-amber-600 cursor-pointer"
                    />
                    <Scissors className="w-3.5 h-3.5 text-slate-400" />
                    <span>Potong / Trim Bagian Tertentu</span>
                  </label>
                </div>

                {trimEnabled && fileMeta?.duration && (
                  <div className="space-y-2 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700/60">
                    <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                      <span>Mulai: {formatDuration(startTime)}</span>
                      <span>Selesai: {formatDuration(endTime)}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-1">Detik Mulai</label>
                        <input
                          type="number"
                          min="0"
                          max={endTime - 1}
                          value={startTime}
                          onChange={(e) => setStartTime(Math.max(0, Number(e.target.value)))}
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-1">Detik Selesai</label>
                        <input
                          type="number"
                          min={startTime + 1}
                          max={Math.floor(fileMeta.duration)}
                          value={endTime}
                          onChange={(e) => setEndTime(Math.min(Math.floor(fileMeta.duration || 0), Number(e.target.value)))}
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Convert Action Button */}
              <button
                onClick={handleConvert}
                disabled={procState.isProcessing}
                className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-600/25 transition-all cursor-pointer"
              >
                <Music2 className="w-4 h-4" />
                <span>{procState.isProcessing ? 'Mengonversi...' : 'Konversi ke MP3 Sekarang'}</span>
              </button>
            </div>

            {/* Audio Player and Video Preview (Right) */}
            <div className="lg:col-span-7 space-y-4">
              {/* MP3 Audio Result Card */}
              {mp3Url && (
                <div className="p-5 rounded-2xl bg-slate-950 border border-amber-500/40 text-slate-100 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                        <FileAudio className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-100">
                          {selectedFile ? `${selectedFile.name.replace(/\.[^/.]+$/, '')}.mp3` : 'ctools-audio.mp3'}
                        </h4>
                        <p className="text-xs text-slate-400">
                          {mp3Blob && formatFileSize(mp3Blob.size)} • {bitrate} kbps • {formatDuration(audioDuration)}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={handleDownload}
                      className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-md"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>

                  {/* Audio Element & Controls */}
                  <audio
                    ref={audioRef}
                    src={mp3Url}
                    onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                    onEnded={() => setIsPlaying(false)}
                    controls
                    className="w-full"
                  />
                </div>
              )}

              {/* Video Reference */}
              <div className="bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="font-bold uppercase tracking-wider">Video Sumber</span>
                  {fileMeta?.duration && (
                    <span>Total Durasi: {formatDuration(fileMeta.duration)}</span>
                  )}
                </div>

                {videoSrc && (
                  <video
                    src={videoSrc}
                    controls
                    className="w-full max-h-[300px] rounded-xl bg-black object-contain mx-auto"
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
