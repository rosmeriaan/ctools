# MP4 to MP3 Converter Tool

Konversi video MP4 / WebM menjadi file audio MP3 berkualitas tinggi secara lokal di peramban.

## Fitur
- Pilihan Bitrate: 128 kbps (Standar), 192 kbps (Medium), 256 kbps (High), 320 kbps (Ultra HD).
- Channel: Stereo (2-channel) atau Mono (1-channel).
- Pemotong audio (Audio Trimmer) berdasarkan rentang detik.
- Pemutar audio bawaan untuk pratinjau langsung.
- Menggunakan Web Audio API + LameJS pure JavaScript encoder dalam chunk non-blocking.

## File Terkait
- `Mp4ToMp3Tool.tsx`: Antarmuka converter, opsi bitrate, trimmer, dan audio player.
- `audioConverterEngine.ts`: Decoder PCM dan loop encoder MP3.
