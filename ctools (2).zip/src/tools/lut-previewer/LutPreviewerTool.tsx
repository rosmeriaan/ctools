import React, { useState, useRef, useEffect } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata } from '../../types';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { Sliders, Download, Eye, Sparkles, Image as ImageIcon } from 'lucide-react';

interface ColorPreset {
  id: string;
  name: string;
  category: string;
  desc: string;
  filter: (r: number, g: number, b: number) => [number, number, number];
}

const COLOR_PRESETS: ColorPreset[] = [
  {
    id: 'teal-orange',
    name: 'Teal & Orange (Blockbuster)',
    category: 'Cinematic',
    desc: 'Shadows kebiruan cyan dan highlights oranye hangat',
    filter: (r, g, b) => {
      const avg = (r + g + b) / 3;
      const newR = avg > 120 ? Math.min(255, r * 1.25) : r * 0.85;
      const newG = avg > 120 ? g * 1.05 : Math.min(255, g * 1.15);
      const newB = avg > 120 ? b * 0.75 : Math.min(255, b * 1.35);
      return [newR, newG, newB];
    },
  },
  {
    id: 'moody-dark',
    name: 'Moody Dark Tone',
    category: 'Cinematic',
    desc: 'Kontras gelap estetis dengan saturasi muted',
    filter: (r, g, b) => {
      const avg = (r + g + b) / 3;
      return [
        Math.max(0, (r - 20) * 1.15),
        Math.max(0, (g - 20) * 1.1),
        Math.max(0, (b - 10) * 1.2),
      ];
    },
  },
  {
    id: 'anime-vibrant',
    name: 'Anime Makoto Shinkai Glow',
    category: 'Vibrant',
    desc: 'Warna cerah biru langit dan saturasi tinggi bercahaya',
    filter: (r, g, b) => {
      return [
        Math.min(255, r * 1.1 + 10),
        Math.min(255, g * 1.15 + 15),
        Math.min(255, b * 1.25 + 25),
      ];
    },
  },
  {
    id: 'vintage-kodak',
    name: 'Vintage Kodak Gold 1990',
    category: 'Retro',
    desc: 'Warm film tone, sedikit faded blacks dan kuning keemasan',
    filter: (r, g, b) => {
      return [
        Math.min(255, r * 1.15 + 15),
        Math.min(255, g * 1.05 + 10),
        Math.max(10, b * 0.85 + 5),
      ];
    },
  },
  {
    id: 'cyberpunk-neon',
    name: 'Cyberpunk Neon Pink',
    category: 'Stylized',
    desc: 'Highlight magenta menyala dan shadow biru indigo',
    filter: (r, g, b) => {
      return [
        Math.min(255, r * 1.3 + 20),
        Math.max(0, g * 0.75),
        Math.min(255, b * 1.4 + 30),
      ];
    },
  },
  {
    id: 'noir-bw',
    name: 'Dramatic Noir Monochrome',
    category: 'Black & White',
    desc: 'Kontras tinggi hitam putih sinematik',
    filter: (r, g, b) => {
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      const contrastGray = gray > 128 ? Math.min(255, (gray - 128) * 1.4 + 128) : Math.max(0, gray * 0.75);
      return [contrastGray, contrastGray, contrastGray];
    },
  },
];

export const LutPreviewerTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [imageSrc, setImageSrc] = useState<string>('');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('teal-orange');
  const [intensity, setIntensity] = useState<number>(100);
  const [showOriginal, setShowOriginal] = useState<boolean>(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const originalImageRef = useRef<HTMLImageElement | null>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (imageSrc) URL.revokeObjectURL(imageSrc);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setImageSrc(url);

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });

    const img = new Image();
    img.src = url;
    img.onload = () => {
      originalImageRef.current = img;
      renderLut();
    };
  };

  const renderLut = () => {
    const img = originalImageRef.current;
    const canvas = canvasRef.current;
    if (!img || !canvas) return;

    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(img, 0, 0);

    const preset = COLOR_PRESETS.find((p) => p.id === selectedPresetId) || COLOR_PRESETS[0];
    const factor = intensity / 100;

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imgData.data;

    for (let i = 0; i < data.length; i += 4) {
      const origR = data[i];
      const origG = data[i + 1];
      const origB = data[i + 2];

      const [targetR, targetG, targetB] = preset.filter(origR, origG, origB);

      // Lerp intensity
      data[i] = origR + (targetR - origR) * factor;
      data[i + 1] = origG + (targetG - origG) * factor;
      data[i + 2] = origB + (targetB - origB) * factor;
    }

    ctx.putImageData(imgData, 0, 0);
  };

  useEffect(() => {
    if (originalImageRef.current) {
      renderLut();
    }
  }, [selectedPresetId, intensity]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas || !file) return;

    canvas.toBlob((blob) => {
      if (blob) {
        const baseName = file.name.replace(/\.[^/.]+$/, '');
        downloadBlob(blob, `ctools-lut-${selectedPresetId}-${baseName}.png`);
        toast.success('Berhasil', 'Gambar dengan color grading berhasil diunduh.');
      }
    }, 'image/png');
  };

  const handleReset = () => {
    if (imageSrc) URL.revokeObjectURL(imageSrc);
    setFile(null);
    setFileMetadata(null);
    setImageSrc('');
    originalImageRef.current = null;
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Sliders className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>LUT & Film Color Grade Previewer</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Browser DSP Filter
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Uji dan aplikasikan preset pewarnaan sinematik film (Teal & Orange, Moody, Anime) secara lokal.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['image/png', 'image/jpeg', 'image/webp']}
          maxSizeMB={30}
          title="Pilih Gambar untuk Color Grading"
          description="Mendukung JPG, PNG, WEBP hingga 30 MB"
          icon={<ImageIcon className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
              <div className="relative rounded-xl overflow-hidden bg-slate-950 flex items-center justify-center min-h-64">
                {showOriginal ? (
                  <img src={imageSrc} alt="Original" className="max-h-96 object-contain rounded-lg" />
                ) : (
                  <canvas ref={canvasRef} className="max-h-96 w-auto max-w-full object-contain rounded-lg" />
                )}

                <button
                  onMouseDown={() => setShowOriginal(true)}
                  onMouseUp={() => setShowOriginal(false)}
                  onTouchStart={() => setShowOriginal(true)}
                  onTouchEnd={() => setShowOriginal(false)}
                  className="absolute bottom-3 right-3 px-3 py-1.5 rounded-xl bg-black/80 hover:bg-black text-white text-xs font-bold flex items-center gap-1.5 backdrop-blur-sm cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Tahan untuk Gambar Asli</span>
                </button>
              </div>

              <button
                onClick={handleDownload}
                className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Gambar Color Grade (PNG)</span>
              </button>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Pilih Preset Color Grade:
              </h3>

              <div className="space-y-2 max-h-72 overflow-y-auto p-1">
                {COLOR_PRESETS.map((p) => {
                  const isSel = selectedPresetId === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setSelectedPresetId(p.id)}
                      className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        isSel
                          ? 'border-blue-600 bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold">{p.name}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 font-normal">
                          {p.category}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1">{p.desc}</p>
                    </button>
                  );
                })}
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex justify-between">
                  <span>Intensitas Pewarnaan:</span>
                  <span className="font-mono text-blue-600 font-bold">{intensity}%</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={intensity}
                  onChange={(e) => setIntensity(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
