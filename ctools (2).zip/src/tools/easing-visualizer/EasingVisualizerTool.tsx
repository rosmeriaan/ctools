import React, { useState, useEffect } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import { TrendingUp, Copy, Check, Play, RotateCcw, Sparkles } from 'lucide-react';

interface CurvePreset {
  name: string;
  category: 'JJ Motion' | 'Standard' | 'Dramatic';
  p1x: number;
  p1y: number;
  p2x: number;
  p2y: number;
  description: string;
}

const PRESETS: CurvePreset[] = [
  { name: 'JJ Jedag Jedug Hard', category: 'JJ Motion', p1x: 0.1, p1y: 0.9, p2x: 0.2, p2y: 1.0, description: 'Hentakan cepat & keras ala jedag jedug TikTok' },
  { name: 'JJ Pop & Snap', category: 'JJ Motion', p1x: 0.0, p1y: 1.2, p2x: 0.2, p2y: 1.0, description: 'Overshoot pop keluar bingkai lalu snap' },
  { name: 'JJ Smooth Bounce', category: 'JJ Motion', p1x: 0.34, p1y: 1.56, p2x: 0.64, p2y: 1.0, description: 'Pantulan elastis halus untuk transisi zoom' },
  { name: 'Ease Out Expo', category: 'Standard', p1x: 0.16, p1y: 1.0, p2x: 0.3, p2y: 1.0, description: 'Akselerasi instan lalu melambat anggun' },
  { name: 'Ease In Out Quart', category: 'Standard', p1x: 0.77, p1y: 0.0, p2x: 0.175, p2y: 1.0, description: 'Transisi klasik seimbang' },
  { name: 'Dramatic Snap', category: 'Dramatic', p1x: 0.85, p1y: 0.0, p2x: 0.15, p2y: 1.0, description: 'Perubahan mendadak di tengah durasi' },
];

export const EasingVisualizerTool: React.FC = () => {
  const [p1x, setP1x] = useState<number>(0.1);
  const [p1y, setP1y] = useState<number>(0.9);
  const [p2x, setP2x] = useState<number>(0.2);
  const [p2y, setP2y] = useState<number>(1.0);

  const [animKey, setAnimKey] = useState<number>(0);
  const [copied, setCopied] = useState<string | null>(null);

  const triggerAnimation = () => {
    setAnimKey((prev) => prev + 1);
  };

  const cubicBezierCss = `cubic-bezier(${p1x}, ${p1y}, ${p2x}, ${p2y})`;

  const copyText = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    toast.success('Disalin', `${type} berhasil disalin ke clipboard.`);
    setTimeout(() => setCopied(null), 2000);
  };

  const alightMotionSnippet = `<curve p1="${p1x},${p1y}" p2="${p2x},${p2y}" />`;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <TrendingUp className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>JJ Easing Curve Visualizer</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Alight Motion / CapCut / CSS
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Visualisasi kurva transisi kecepatan Bézier untuk motion graphic dan animasi jedag-jedug.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Visualizer and Live Test */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Pratinjau Animasi Realtime
            </h3>

            {/* Animation stage */}
            <div className="p-6 rounded-2xl bg-slate-950 text-white space-y-5 overflow-hidden">
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Gerakan Translasi X:
                </span>
                <div className="relative h-10 bg-slate-900 rounded-xl p-1 flex items-center">
                  <div
                    key={`box-${animKey}`}
                    style={{
                      animation: `slideX 1.2s ${cubicBezierCss} infinite alternate`,
                    }}
                    className="w-8 h-8 rounded-lg bg-blue-500 shadow-md shadow-blue-500/50"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                  Zoom & Scale (JJ Beat Zoom):
                </span>
                <div className="h-20 bg-slate-900 rounded-xl flex items-center justify-center">
                  <div
                    key={`scale-${animKey}`}
                    style={{
                      animation: `zoomBeat 1.2s ${cubicBezierCss} infinite alternate`,
                    }}
                    className="w-12 h-12 rounded-xl bg-gradient-to-tr from-indigo-500 to-pink-500 shadow-lg"
                  />
                </div>
              </div>

              <button
                onClick={triggerAnimation}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Re-trigger Animasi</span>
              </button>
            </div>

            <style>{`
              @keyframes slideX {
                from { transform: translateX(0px); }
                to { transform: translateX(calc(100% + 220px)); }
              }
              @keyframes zoomBeat {
                from { transform: scale(0.5) rotate(0deg); }
                to { transform: scale(1.35) rotate(8deg); }
              }
            `}</style>
          </div>

          {/* Presets List */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Preset Kurva Populer:
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PRESETS.map((p) => (
                <button
                  key={p.name}
                  onClick={() => {
                    setP1x(p.p1x);
                    setP1y(p.p1y);
                    setP2x(p.p2x);
                    setP2y(p.p2y);
                    triggerAnimation();
                  }}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    p1x === p.p1x && p1y === p.p1y && p2x === p.p2x && p2y === p.p2y
                      ? 'border-blue-600 bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="text-xs font-bold">{p.name}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5 leading-tight">{p.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Sliders & Code Snippets */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Parameter Control Points (P1 & P2):
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                <span className="text-xs font-bold text-blue-600 block">Point 1 (P1)</span>
                <div>
                  <label className="text-[11px] text-slate-500 flex justify-between">
                    <span>P1.X</span> <span className="font-mono font-bold">{p1x}</span>
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={p1x}
                    onChange={(e) => setP1x(Number(e.target.value))}
                    className="w-full accent-blue-600 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-500 flex justify-between">
                    <span>P1.Y</span> <span className="font-mono font-bold">{p1y}</span>
                  </label>
                  <input
                    type="range"
                    min="-0.5"
                    max="2.0"
                    step="0.01"
                    value={p1y}
                    onChange={(e) => setP1y(Number(e.target.value))}
                    className="w-full accent-blue-600 cursor-pointer"
                  />
                </div>
              </div>

              <div className="space-y-3 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                <span className="text-xs font-bold text-pink-600 block">Point 2 (P2)</span>
                <div>
                  <label className="text-[11px] text-slate-500 flex justify-between">
                    <span>P2.X</span> <span className="font-mono font-bold">{p2x}</span>
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={p2x}
                    onChange={(e) => setP2x(Number(e.target.value))}
                    className="w-full accent-pink-600 cursor-pointer"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-slate-500 flex justify-between">
                    <span>P2.Y</span> <span className="font-mono font-bold">{p2y}</span>
                  </label>
                  <input
                    type="range"
                    min="-0.5"
                    max="2.0"
                    step="0.01"
                    value={p2y}
                    onChange={(e) => setP2y(Number(e.target.value))}
                    className="w-full accent-pink-600 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* Export Code Snippets */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Salin Format Editor:
              </h4>

              {/* CSS Code */}
              <div className="p-3 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono flex items-center justify-between">
                <span className="truncate pr-2">{cubicBezierCss}</span>
                <button
                  onClick={() => copyText(cubicBezierCss, 'CSS')}
                  className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-sans text-xs flex items-center gap-1 cursor-pointer"
                >
                  {copied === 'CSS' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Salin CSS</span>
                </button>
              </div>

              {/* Alight Motion XML */}
              <div className="p-3 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono flex items-center justify-between">
                <span className="truncate pr-2">{alightMotionSnippet}</span>
                <button
                  onClick={() => copyText(alightMotionSnippet, 'Alight Motion XML')}
                  className="px-2.5 py-1 rounded bg-pink-600 hover:bg-pink-500 text-white font-sans text-xs flex items-center gap-1 cursor-pointer"
                >
                  {copied === 'Alight Motion XML' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Salin AM XML</span>
                </button>
              </div>

              {/* Raw tuple */}
              <div className="p-3 rounded-xl bg-slate-900 text-slate-200 text-xs font-mono flex items-center justify-between">
                <span className="truncate pr-2">{`${p1x}, ${p1y}, ${p2x}, ${p2y}`}</span>
                <button
                  onClick={() => copyText(`${p1x}, ${p1y}, ${p2x}, ${p2y}`, 'Tuple')}
                  className="px-2.5 py-1 rounded bg-slate-700 hover:bg-slate-600 text-white font-sans text-xs flex items-center gap-1 cursor-pointer"
                >
                  {copied === 'Tuple' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Salin Angka</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
