import React, { useState, useRef, useEffect } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatDuration, formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { FFmpegCommands } from '../../core/ffmpeg/commands';
import { Scissors, Play, Pause, Download, RotateCcw, Film, Clock } from 'lucide-react';

export const VideoCutterTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [duration, setDuration] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const [startTime, setStartTime] = useState<number>(0);
  const [endTime, setEndTime] = useState<number>(0);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap memotong video',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const videoRef = useRef<HTMLVideoElement>(null);
  const previewResultRef = useRef<HTMLVideoElement>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setVideoUrl(url);
    setOutputBlob(null);
    setOutputUrl('');
    setStartTime(0);
    setEndTime(0);
    setCurrentTime(0);

    const meta: FileMetadata = {
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    };
    setFileMetadata(meta);
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const dur = videoRef.current.duration || 0;
      setDuration(dur);
      setEndTime(Math.min(dur, Math.max(1, Math.round(dur))));
      if (fileMetadata) {
        setFileMetadata({
          ...fileMetadata,
          duration: dur,
          dimensions: {
            width: videoRef.current.videoWidth,
            height: videoRef.current.videoHeight,
          },
        });
      }
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const seekTo = (sec: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(0, Math.min(duration, sec));
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const setStartToCurrent = () => {
    if (currentTime < endTime) {
      setStartTime(Number(currentTime.toFixed(2)));
    } else {
      toast.warning('Waktu Tidak Valid', 'Start time harus lebih kecil dari End time.');
    }
  };

  const setEndToCurrent = () => {
    if (currentTime > startTime) {
      setEndTime(Number(currentTime.toFixed(2)));
    } else {
      toast.warning('Waktu Tidak Valid', 'End time harus lebih besar dari Start time.');
    }
  };

  const handleProcessTrim = async () => {
    if (!file) {
      toast.error('Gagal', 'Pilih file video terlebih dahulu.');
      return;
    }

    const cutDuration = endTime - startTime;
    if (cutDuration <= 0.1) {
      toast.error('Rentang Terlalu Pendek', 'Durasi pemotongan minimal 0.2 detik.');
      return;
    }

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan engine FFmpeg...',
      step: 'preparing',
    });

    try {
      const inputExt = file.name.split('.').pop() || 'mp4';
      const inputName = `input.${inputExt}`;
      const outputName = 'output.mp4';

      const args = FFmpegCommands.cutVideo(inputName, outputName, startTime, cutDuration);

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Memotong video (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (status) => {
          setProcessing((prev) => ({ ...prev, statusText: status }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Pemotongan video selesai!',
        step: 'completed',
      });
      toast.success('Berhasil', 'Video berhasil dipotong dan siap diunduh.');
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal memproses video.',
        step: 'error',
        error: err?.message || 'Terjadi kesalahan saat memotong video.',
      });
      toast.error('Pemotongan Gagal', err?.message || 'Gagal memotong video.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob) return;
    const originalName = file?.name.replace(/\.[^/.]+$/, '') || 'video';
    downloadBlob(outputBlob, `ctools-trimmed-${originalName}.mp4`);
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setVideoUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setStartTime(0);
    setEndTime(0);
    setDuration(0);
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap memotong video',
      step: 'idle',
    });
  };

  const clipDuration = Math.max(0, endTime - startTime);

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Scissors className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Video Cutter & Trimmer</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              FFmpeg WebAssembly
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Potong durasi video secara presisi dengan timeline interaktif tanpa upload ke server.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['video/mp4', 'video/webm', 'video/quicktime', 'video/ogg']}
          maxSizeMB={200}
          title="Tarik & Letakkan Video di Sini"
          description="Mendukung format MP4, WebM, MOV hingga 200 MB (100% diproses di browser)"
          icon={<Film className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Player & Timeline */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                <video
                  ref={videoRef}
                  src={videoUrl}
                  onLoadedMetadata={handleLoadedMetadata}
                  onTimeUpdate={handleTimeUpdate}
                  onEnded={() => setIsPlaying(false)}
                  className="w-full h-full object-contain"
                  playsInline
                />
              </div>

              {/* Player Controls & Scrubber */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <button
                    onClick={togglePlay}
                    className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-sm cursor-pointer"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>

                  <div className="flex-1 space-y-1">
                    <input
                      type="range"
                      min="0"
                      max={duration || 100}
                      step="0.01"
                      value={currentTime}
                      onChange={(e) => seekTo(Number(e.target.value))}
                      className="w-full accent-blue-600 cursor-pointer"
                    />
                    <div className="flex justify-between text-[11px] font-mono text-slate-500">
                      <span>{formatDuration(currentTime)}</span>
                      <span>{formatDuration(duration)}</span>
                    </div>
                  </div>
                </div>

                {/* Timeline Range Indicator */}
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-blue-500" />
                      Rentang Potongan (Trim Range)
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-600 dark:text-blue-400 font-mono text-xs">
                      Durasi: {clipDuration.toFixed(2)}s
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-500">
                        <span>Mulai (Start)</span>
                        <button
                          onClick={setStartToCurrent}
                          className="text-blue-600 hover:underline cursor-pointer font-semibold"
                        >
                          Gunakan Waktu Saat Ini
                        </button>
                      </div>
                      <input
                        type="number"
                        min="0"
                        max={endTime - 0.1}
                        step="0.1"
                        value={startTime}
                        onChange={(e) => setStartTime(Math.max(0, Number(e.target.value)))}
                        className="w-full px-3 py-2 text-xs font-mono font-bold rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-500">
                        <span>Selesai (End)</span>
                        <button
                          onClick={setEndToCurrent}
                          className="text-blue-600 hover:underline cursor-pointer font-semibold"
                        >
                          Gunakan Waktu Saat Ini
                        </button>
                      </div>
                      <input
                        type="number"
                        min={startTime + 0.1}
                        max={duration}
                        step="0.1"
                        value={endTime}
                        onChange={(e) => setEndTime(Math.min(duration, Number(e.target.value)))}
                        className="w-full px-3 py-2 text-xs font-mono font-bold rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          {/* Right Column: Actions & Output */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                <span>Proses Pemotongan</span>
                <span className="text-xs text-slate-400 font-normal">H.264 MP4</span>
              </h3>

              <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <div className="flex justify-between">
                  <span>Start Time:</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-slate-200">{formatDuration(startTime)} ({startTime}s)</span>
                </div>
                <div className="flex justify-between">
                  <span>End Time:</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-slate-200">{formatDuration(endTime)} ({endTime}s)</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-200 dark:border-slate-700">
                  <span>Output Duration:</span>
                  <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{clipDuration.toFixed(2)} detik</span>
                </div>
              </div>

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputUrl ? (
                <div className="space-y-3 pt-2">
                  <div className="rounded-xl overflow-hidden bg-black aspect-video">
                    <video
                      ref={previewResultRef}
                      src={outputUrl}
                      controls
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Video ({formatFileSize(outputBlob?.size || 0)})</span>
                  </button>
                  <button
                    onClick={handleProcessTrim}
                    className="w-full py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Potong Ulang dengan Rentang Lain</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={handleProcessTrim}
                    disabled={processing.isProcessing}
                    className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer transition-all"
                  >
                    <Scissors className="w-4 h-4" />
                    <span>{processing.isProcessing ? 'Sedang Memotong...' : 'Potong Video Sekarang'}</span>
                  </button>

                  <button
                    onClick={handleReset}
                    disabled={processing.isProcessing}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-600 dark:text-slate-400 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <span>Ganti File Video</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
