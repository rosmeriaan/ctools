import React, { useState, useRef } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  Eye,
  Download,
  Upload,
  Camera,
  Play,
  Pause,
  Clock,
  Sparkles,
  Layers,
  ZoomIn,
} from 'lucide-react';

export const FrameExtractorTool: React.FC = () => {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [extractedImage, setExtractedImage] = useState<string>('');
  const [burstImages, setBurstImages] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (videoUrl) URL.revokeObjectURL(videoUrl);
    const url = URL.createObjectURL(file);
    setVideoFile(file);
    setVideoUrl(url);
    setExtractedImage('');
    setBurstImages([]);
    toast.success('Video Dimuat', `File ${file.name} siap diekstrak.`);
  };

  const captureSingleFrame = () => {
    const video = videoRef.current;
    if (!video) return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1920;
    canvas.height = video.videoHeight || 1080;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/png');
    setExtractedImage(dataUrl);
    toast.success('Frame Ditangkap', `Frame pada ${video.currentTime.toFixed(3)}s berhasil diambil.`);
  };

  const handleCaptureBurst = async () => {
    const video = videoRef.current;
    if (!video) return;

    setIsProcessing(true);
    const burst: string[] = [];
    const baseTime = video.currentTime;
    const step = 0.05; // 50ms interval

    for (let i = -2; i <= 2; i++) {
      const targetT = Math.max(0, Math.min(duration, baseTime + i * step));
      video.currentTime = targetT;
      await new Promise((resolve) => {
        video.onseeked = resolve;
      });

      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1920;
      canvas.height = video.videoHeight || 1080;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        burst.push(canvas.toDataURL('image/png'));
      }
    }

    video.currentTime = baseTime;
    setBurstImages(burst);
    setIsProcessing(false);
    toast.success('Burst Selesai', '5 frame berturut-turut berhasil diambil.');
  };

  const downloadImage = (dataUrl: string, name: string) => {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = name;
    a.click();
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Camera className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Timestamp Frame Extractor & HD Snapshot</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Presisi Milidetik
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ambil snapshot resolusi asli dari video pada detik tertentu atau lakukan pengambilan frame burst 100% lokal di browser.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!videoUrl ? (
        <div className="p-10 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl bg-white dark:bg-slate-900 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center">
            <Upload className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Pilih Video untuk Diekstrak
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Mendukung file MP4, WebM, MOV. Ukuran file tidak dibatasi.
            </p>
          </div>
          <label className="inline-block cursor-pointer px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors">
            Pilih File Video
            <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" />
          </label>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Video Player & Timeline */}
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
              <video
                ref={videoRef}
                src={videoUrl}
                controls
                onTimeUpdate={(e) => setCurrentTime((e.target as HTMLVideoElement).currentTime)}
                onLoadedMetadata={(e) => setDuration((e.target as HTMLVideoElement).duration)}
                className="w-full max-h-[360px] rounded-xl bg-black object-contain shadow-inner"
              />

              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                  <span>Waktu: {currentTime.toFixed(3)}s</span>
                  <span>Durasi: {duration.toFixed(3)}s</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={duration || 1}
                  step={0.01}
                  value={currentTime}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setCurrentTime(val);
                    if (videoRef.current) videoRef.current.currentTime = val;
                  }}
                  className="w-full accent-blue-600"
                />
              </div>

              {/* Extraction Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-2">
                <button
                  onClick={captureSingleFrame}
                  className="flex-1 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
                >
                  <Camera className="w-4 h-4" />
                  <span>Ambil Frame Saat Ini (HD PNG)</span>
                </button>

                <button
                  onClick={handleCaptureBurst}
                  disabled={isProcessing}
                  className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors disabled:opacity-50"
                >
                  <Layers className="w-4 h-4 text-indigo-500" />
                  <span>{isProcessing ? 'Memproses...' : 'Ambil 5 Burst Frame'}</span>
                </button>
              </div>
            </div>

            {/* Frame Output Preview */}
            <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
              <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-blue-500" />
                <span>Hasil Ekstraksi Frame:</span>
              </h3>

              {extractedImage ? (
                <div className="space-y-3">
                  <img
                    src={extractedImage}
                    alt="Extracted Frame"
                    className="w-full max-h-[220px] object-contain rounded-xl border border-slate-200 dark:border-slate-800 shadow-md"
                  />
                  <button
                    onClick={() =>
                      downloadImage(
                        extractedImage,
                        `frame-${videoFile?.name.replace(/\.[^/.]+$/, '')}-${currentTime.toFixed(3)}s.png`
                      )
                    }
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Gambar PNG HD</span>
                  </button>
                </div>
              ) : (
                <div className="h-48 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-800 flex items-center justify-center text-xs text-slate-400 text-center p-4">
                  Posisikan slider pada waktu yang diinginkan lalu klik tombol "Ambil Frame Saat Ini".
                </div>
              )}
            </div>
          </div>

          {/* Burst Gallery */}
          {burstImages.length > 0 && (
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
              <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
                5 Rekaman Frame Berurutan (Burst):
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {burstImages.map((img, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <img
                      src={img}
                      alt={`Burst ${idx + 1}`}
                      className="w-full h-24 object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                    />
                    <button
                      onClick={() => downloadImage(img, `burst-frame-${idx + 1}.png`)}
                      className="w-full py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 text-[10px] font-bold rounded-md flex items-center justify-center gap-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>Unduh #{idx + 1}</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
