import React, { useState, useEffect } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  Minimize2,
  Upload,
  Download,
  Sliders,
  Sparkles,
  Eye,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';

export const ImageCompressorTool: React.FC = () => {
  const [originalFile, setOriginalFile] = useState<File | null>(null);
  const [originalUrl, setOriginalUrl] = useState<string>('');
  const [compressedUrl, setCompressedUrl] = useState<string>('');
  const [compressedBlob, setCompressedBlob] = useState<Blob | null>(null);

  const [quality, setQuality] = useState<number>(80);
  const [maxDimension, setMaxDimension] = useState<number>(1920);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (originalUrl) URL.revokeObjectURL(originalUrl);
    const url = URL.createObjectURL(file);
    setOriginalFile(file);
    setOriginalUrl(url);
    compressImage(file, quality, maxDimension);
  };

  const compressImage = (file: File, q: number, maxDim: number) => {
    setIsProcessing(true);
    const img = new Image();
    img.src = URL.createObjectURL(file);
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      if (maxDim > 0 && (width > maxDim || height > maxDim)) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setIsProcessing(false);
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      // Determine output format
      const mime = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
      canvas.toBlob(
        (blob) => {
          if (blob) {
            if (compressedUrl) URL.revokeObjectURL(compressedUrl);
            const compUrl = URL.createObjectURL(blob);
            setCompressedBlob(blob);
            setCompressedUrl(compUrl);
          }
          setIsProcessing(false);
        },
        mime,
        q / 100
      );
    };
  };

  useEffect(() => {
    if (originalFile) {
      compressImage(originalFile, quality, maxDimension);
    }
  }, [quality, maxDimension]);

  const handleDownload = () => {
    if (!compressedBlob || !originalFile) return;
    const a = document.createElement('a');
    a.href = compressedUrl;
    a.download = `compressed-${originalFile.name}`;
    a.click();
    toast.success('Diunduh', 'Gambar terkompresi berhasil diunduh.');
  };

  const originalSize = originalFile ? originalFile.size : 0;
  const compressedSize = compressedBlob ? compressedBlob.size : 0;
  const savedPercent =
    originalSize > 0 ? Math.round(((originalSize - compressedSize) / originalSize) * 100) : 0;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Minimize2 className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Image Compressor (JPG, PNG, WEBP)</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Penghemat Ukuran
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Perkecil ukuran file gambar hingga 80% tanpa merusak ketajaman visual langsung di browser Anda.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!originalFile ? (
        <div className="p-10 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl bg-white dark:bg-slate-900 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center">
            <Upload className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Pilih Gambar yang Ingin Dikompres
            </h3>
            <p className="text-xs text-slate-500 mt-1">Mendukung format JPG, JPEG, PNG, WEBP.</p>
          </div>
          <label className="inline-block cursor-pointer px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors">
            Pilih Berkas Foto
            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Kualitas Kompresi:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">{quality}%</span>
              </div>
              <input
                type="range"
                min={10}
                max={100}
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                Maksimal Dimensi Panjang/Lebar:
              </label>
              <select
                value={maxDimension}
                onChange={(e) => setMaxDimension(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
              >
                <option value={0}>Resolusi Asli (No Resize)</option>
                <option value={1920}>Maksimal 1920px (Full HD)</option>
                <option value={1280}>Maksimal 1280px (HD 720p)</option>
                <option value={800}>Maksimal 800px (Web Ringan)</option>
              </select>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="p-4 rounded-2xl bg-emerald-500/5 dark:bg-emerald-950/20 border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-xs font-semibold">
              <div>
                <span className="text-slate-400">Ukuran Asli:</span>{' '}
                <span className="font-bold text-slate-700 dark:text-slate-300">
                  {(originalSize / 1024).toFixed(1)} KB
                </span>
              </div>
              <span className="text-slate-400">→</span>
              <div>
                <span className="text-slate-400">Setelah Kompres:</span>{' '}
                <span className="font-bold text-emerald-600 dark:text-emerald-400">
                  {(compressedSize / 1024).toFixed(1)} KB
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold text-[11px]">
                Hemat {savedPercent}%
              </span>
            </div>

            <button
              onClick={handleDownload}
              className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Gambar Kompres</span>
            </button>
          </div>

          {/* Image Preview */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-500">Foto Asli:</div>
              <img
                src={originalUrl}
                alt="Original"
                className="w-full h-64 object-contain rounded-xl bg-slate-50 dark:bg-slate-950 p-2 border border-slate-200 dark:border-slate-800"
              />
            </div>

            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-xs font-bold text-slate-500">Hasil Kompresi:</div>
              <img
                src={compressedUrl}
                alt="Compressed"
                className="w-full h-64 object-contain rounded-xl bg-slate-50 dark:bg-slate-950 p-2 border border-slate-200 dark:border-slate-800"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
