import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import { downloadTextFile } from '../../utils/file';
import {
  FileCode,
  Upload,
  Download,
  Copy,
  Check,
  Sparkles,
  RefreshCw,
  Eye,
} from 'lucide-react';

const SAMPLE_DIRTY_SVG = `<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!-- Generator: Adobe Illustrator 27.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:cc="http://creativecommons.org/ns#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" version="1.1" id="svg2" viewBox="0 0 120 120" width="120" height="120">
  <defs id="defs4">
    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#3B82F6;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#8B5CF6;stop-opacity:1" />
    </linearGradient>
  </defs>
  <!-- Main Star Graphic -->
  <g id="layer1" transform="translate(0,0)">
    <circle id="path1" cx="60" cy="60" r="50" fill="url(#grad1)" stroke="#FFFFFF" stroke-width="4" />
    <path id="star" d="M 60,25 L 70,50 L 95,52 L 75,68 L 82,92 L 60,78 L 38,92 L 45,68 L 25,52 L 50,50 Z" fill="#FFFFFF" />
  </g>
</svg>`;

export const SvgOptimizerTool: React.FC = () => {
  const [inputSvg, setInputSvg] = useState<string>(SAMPLE_DIRTY_SVG);
  const [optimizedSvg, setOptimizedSvg] = useState<string>('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const optimizeSvgCode = (code: string) => {
    let res = code
      // Remove XML declaration
      .replace(/<\?xml[\s\S]*?\?>/gi, '')
      // Remove DOCTYPE
      .replace(/<!DOCTYPE[\s\S]*?>/gi, '')
      // Remove XML comments
      .replace(/<!--[\s\S]*?-->/g, '')
      // Remove inkscape / sodipodi / adobe metadata tags
      .replace(/<metadata[\s\S]*?<\/metadata>/gi, '')
      .replace(/xmlns:(dc|cc|rdf|svg|sodipodi|inkscape)="[^"]*"/gi, '')
      .replace(/(sodipodi|inkscape):[a-z0-9_-]+="[^"]*"/gi, '')
      // Remove unnecessary whitespace between tags
      .replace(/>\s+</g, '><')
      // Collapse multiple whitespace
      .replace(/\s+/g, ' ')
      .trim();

    return res;
  };

  const handleRunOptimization = () => {
    if (!inputSvg.trim()) return;
    const clean = optimizeSvgCode(inputSvg);
    setOptimizedSvg(clean);
    toast.success('Optimasi Selesai', 'Metadata dan tag berlebih berhasil dipangkas.');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setInputSvg(text);
      setOptimizedSvg('');
      toast.success('SVG Dimuat', `${file.name}`);
    };
    reader.readAsText(file);
  };

  const handleCopy = () => {
    const text = optimizedSvg || inputSvg;
    navigator.clipboard.writeText(text);
    setCopiedKey('copy');
    toast.success('Disalin', 'Kode SVG disalin ke clipboard.');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownload = () => {
    const text = optimizedSvg || inputSvg;
    downloadTextFile(text, 'optimized.svg', 'image/svg+xml');
    toast.success('Diunduh', 'File optimized.svg berhasil disimpan.');
  };

  const originalSize = new Blob([inputSvg]).size;
  const optimizedSize = optimizedSvg ? new Blob([optimizedSvg]).size : originalSize;
  const savedPercent =
    originalSize > 0 && optimizedSvg
      ? Math.max(0, Math.round(((originalSize - optimizedSize) / originalSize) * 100))
      : 0;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Sparkles className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>SVG Optimizer & Code Minifier</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Pembersih Metadata
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Pangkas tag berlebih, metadata Illustrator/Inkscape, dan ruang kosong pada berkas SVG tanpa merusak tampilan visual.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Editor */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Kode SVG Input:
            </span>
            <label className="cursor-pointer px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 flex items-center gap-1">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload .svg</span>
              <input type="file" accept=".svg" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          <textarea
            value={inputSvg}
            onChange={(e) => {
              setInputSvg(e.target.value);
              setOptimizedSvg('');
            }}
            rows={9}
            className="w-full font-mono text-xs p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          />

          <div className="flex gap-2">
            <button
              onClick={handleRunOptimization}
              className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>Optimasi & Bersihkan Kode</span>
            </button>
            <button
              onClick={handleCopy}
              className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
            >
              {copiedKey === 'copy' ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              <span>Salin</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Unduh .svg</span>
            </button>
          </div>

          {/* Stats Bar */}
          {optimizedSvg && (
            <div className="p-3.5 rounded-xl bg-emerald-500/5 dark:bg-emerald-950/20 border border-emerald-500/20 flex items-center justify-between text-xs font-semibold">
              <div>
                <span className="text-slate-400">Awal:</span> <b>{originalSize} B</b> →{' '}
                <span className="text-slate-400">Optimasi:</span>{' '}
                <b className="text-emerald-600 dark:text-emerald-400">{optimizedSize} B</b>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-bold">
                Pangkas {savedPercent}%
              </span>
            </div>
          )}
        </div>

        {/* Live Preview */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center shadow-xs">
          <div className="w-full flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-blue-500" />
              <span>Pratinjau Visual Vektor</span>
            </span>
          </div>

          <div
            className="w-full h-64 rounded-2xl flex items-center justify-center p-4 bg-[linear-gradient(45deg,#f1f5f9_25%,transparent_25%),linear-gradient(-45deg,#f1f5f9_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#f1f5f9_75%),linear-gradient(-45deg,transparent_75%,#f1f5f9_75%)] bg-[size:20px_20px] dark:bg-[linear-gradient(45deg,#1e293b_25%,transparent_25%),linear-gradient(-45deg,#1e293b_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#1e293b_75%),linear-gradient(-45deg,transparent_75%,#1e293b_75%)] border border-slate-200 dark:border-slate-800 overflow-hidden shadow-inner"
            dangerouslySetInnerHTML={{ __html: optimizedSvg || inputSvg }}
          />
        </div>
      </div>
    </div>
  );
};
