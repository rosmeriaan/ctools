import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import { downloadTextFile } from '../../utils/file';
import {
  Palette,
  RefreshCw,
  Lock,
  Unlock,
  Copy,
  Check,
  Download,
  Sliders,
  Sparkles,
} from 'lucide-react';

interface PaletteSlot {
  id: string;
  hex: string;
  isLocked: boolean;
}

export const ColorPaletteTool: React.FC = () => {
  const [harmony, setHarmony] = useState<'analogous' | 'complementary' | 'triadic' | 'monochromatic'>('analogous');
  const [slots, setSlots] = useState<PaletteSlot[]>([
    { id: '1', hex: '#3B82F6', isLocked: false },
    { id: '2', hex: '#60A5FA', isLocked: false },
    { id: '3', hex: '#93C5FD', isLocked: false },
    { id: '4', hex: '#2563EB', isLocked: false },
    { id: '5', hex: '#1D4ED8', isLocked: false },
  ]);

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const generateHarmoniousPalette = () => {
    const baseHue = Math.floor(Math.random() * 360);
    const hslToHex = (h: number, s: number, l: number) => {
      l /= 100;
      const a = (s * Math.min(l, 1 - l)) / 100;
      const f = (n: number) => {
        const k = (n + h / 30) % 12;
        const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
        return Math.round(255 * color)
          .toString(16)
          .padStart(2, '0');
      };
      return `#${f(0)}${f(8)}${f(4)}`.toUpperCase();
    };

    setSlots((prev) =>
      prev.map((slot, index) => {
        if (slot.isLocked) return slot;

        let h = baseHue;
        let s = 70 + Math.floor(Math.random() * 20);
        let l = 40 + index * 12;

        if (harmony === 'analogous') {
          h = (baseHue + index * 25) % 360;
        } else if (harmony === 'complementary') {
          h = index % 2 === 0 ? baseHue : (baseHue + 180) % 360;
        } else if (harmony === 'triadic') {
          h = (baseHue + (index % 3) * 120) % 360;
        } else if (harmony === 'monochromatic') {
          h = baseHue;
          l = 25 + index * 14;
        }

        return {
          ...slot,
          hex: hslToHex(h, s, l),
        };
      })
    );
  };

  const toggleLock = (id: string) => {
    setSlots((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isLocked: !s.isLocked } : s))
    );
  };

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    toast.success('Disalin', `"${text}" disalin ke clipboard.`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleExportJson = () => {
    const list = slots.map((s) => s.hex);
    downloadTextFile(
      JSON.stringify({ palette: list, harmony }, null, 2),
      `ctools-palette-${Date.now()}.json`,
      'application/json'
    );
    toast.success('Diunduh', 'File palet JSON berhasil disimpan.');
  };

  const handleExportPng = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const blockWidth = canvas.width / slots.length;

    slots.forEach((s, idx) => {
      ctx.fillStyle = s.hex;
      ctx.fillRect(idx * blockWidth, 0, blockWidth, canvas.height);

      ctx.fillStyle = '#FFFFFF';
      ctx.shadowColor = 'rgba(0,0,0,0.6)';
      ctx.shadowBlur = 8;
      ctx.font = 'bold 28px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(s.hex, idx * blockWidth + blockWidth / 2, canvas.height - 40);
    });

    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `ctools-palette-${Date.now()}.png`;
    a.click();
    toast.success('Diunduh', 'Gambar swatch palet PNG berhasil diunduh.');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Palette className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Harmonious Color Palette Generator</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Teori Warna
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Hasilkan skema warna serasi berdasarkan teori visual, kunci slot warna favorit, dan ekspor instan ke JSON atau swatch PNG.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Model Harmoni:</span>
          <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(
              [
                { id: 'analogous', label: 'Analogous' },
                { id: 'complementary', label: 'Komplementer' },
                { id: 'triadic', label: 'Triadic' },
                { id: 'monochromatic', label: 'Monokromatik' },
              ] as const
            ).map((h) => (
              <button
                key={h.id}
                onClick={() => setHarmony(h.id)}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  harmony === h.id
                    ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {h.label}
              </button>
            ))}
          </div>

          <button
            onClick={generateHarmoniousPalette}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Generate Baru</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportPng}
            className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor PNG</span>
          </button>
          <button
            onClick={handleExportJson}
            className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor JSON</span>
          </button>
        </div>
      </div>

      {/* Palette Slots Display */}
      <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 h-80 sm:h-96">
        {slots.map((slot) => (
          <div
            key={slot.id}
            className="rounded-2xl shadow-md border border-slate-200 dark:border-slate-800 flex flex-col justify-between p-4 transition-all hover:scale-[1.02]"
            style={{ backgroundColor: slot.hex }}
          >
            <div className="flex justify-end">
              <button
                onClick={() => toggleLock(slot.id)}
                className={`p-2 rounded-xl backdrop-blur-md transition-colors ${
                  slot.isLocked
                    ? 'bg-black/50 text-white'
                    : 'bg-black/20 text-white/80 hover:bg-black/40'
                }`}
                title={slot.isLocked ? 'Terkunci' : 'Kunci warna ini'}
              >
                {slot.isLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
              </button>
            </div>

            <div className="backdrop-blur-md bg-black/40 p-2.5 rounded-xl border border-white/20 text-white flex items-center justify-between">
              <span className="font-mono text-xs font-bold">{slot.hex}</span>
              <button
                onClick={() => copyText(slot.hex, slot.id)}
                className="p-1 rounded hover:bg-white/20"
                title="Salin HEX"
              >
                {copiedKey === slot.id ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
