import React, { useState, useEffect } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import { downloadTextFile } from '../../utils/file';
import {
  FileJson,
  Check,
  Copy,
  Download,
  Upload,
  Trash2,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Code,
  FileCode,
  Share2,
  Minimize2,
  Maximize2,
  RefreshCw,
} from 'lucide-react';

const SAMPLE_DATASETS: Record<string, string> = {
  keyframe: JSON.stringify(
    {
      projectName: 'Jedag Jedug Beat Sync #4',
      fps: 60,
      bpm: 128,
      layers: [
        {
          id: 'layer-1',
          name: 'Bass Shake',
          keyframes: [
            { time: 0, scale: 1.0, opacity: 1 },
            { time: 0.234, scale: 1.15, opacity: 0.9 },
            { time: 0.468, scale: 1.0, opacity: 1 },
          ],
          easing: 'cubic-bezier(0.25, 0.1, 0.25, 1)',
        },
      ],
      exportSettings: {
        resolution: '1080x1920',
        codec: 'h264',
        bitrateMbps: 18,
      },
    },
    null,
    2
  ),
  social: JSON.stringify(
    {
      platform: 'tiktok',
      aspectRatio: '9:16',
      safeZone: { top: 120, bottom: 260, right: 90 },
      captions: [
        { start: '00:01.20', text: 'Tutorial Alight Motion' },
        { start: '00:03.50', text: 'Preset Link di Bio' },
      ],
      tags: ['#jedagjedug', '#alightmotion', '#capcut', '#editor'],
    },
    null,
    2
  ),
};

export const JsonFormatterTool: React.FC = () => {
  const [inputJson, setInputJson] = useState<string>(() => {
    const params = new URLSearchParams(window.location.search);
    const fromUrl = params.get('json') || params.get('data');
    return fromUrl ? decodeURIComponent(fromUrl) : SAMPLE_DATASETS.keyframe;
  });

  const [indentSize, setIndentSize] = useState<number>(2);
  const [validationResult, setValidationResult] = useState<{
    isValid: boolean;
    errorMsg?: string;
    line?: number;
    column?: number;
    stats?: { keys: number; depth: number; sizeBytes: number };
  }>({ isValid: true });

  const [activeTab, setActiveTab] = useState<'editor' | 'tree' | 'yaml'>('editor');
  const [parsedObject, setParsedObject] = useState<any>(null);

  // Validate and parse JSON whenever input changes
  useEffect(() => {
    if (!inputJson.trim()) {
      setValidationResult({ isValid: true });
      setParsedObject(null);
      return;
    }

    try {
      const parsed = JSON.parse(inputJson);
      setParsedObject(parsed);

      // calculate stats
      const countKeys = (obj: any): number => {
        if (typeof obj !== 'object' || obj === null) return 0;
        let count = Object.keys(obj).length;
        for (const k in obj) count += countKeys(obj[k]);
        return count;
      };

      const getDepth = (obj: any): number => {
        if (typeof obj !== 'object' || obj === null) return 0;
        let max = 0;
        for (const k in obj) max = Math.max(max, getDepth(obj[k]));
        return max + 1;
      };

      setValidationResult({
        isValid: true,
        stats: {
          keys: countKeys(parsed),
          depth: getDepth(parsed),
          sizeBytes: new Blob([inputJson]).size,
        },
      });
    } catch (err: any) {
      setParsedObject(null);
      let line = 1;
      let column = 1;

      // Extract line and column from error message
      const match = err.message.match(/position\s+(\d+)/i) || err.message.match(/line\s+(\d+)\s+column\s+(\d+)/i);
      if (match && match[1]) {
        const pos = parseInt(match[1], 10);
        const linesBefore = inputJson.slice(0, pos).split('\n');
        line = linesBefore.length;
        column = linesBefore[linesBefore.length - 1].length + 1;
      }

      setValidationResult({
        isValid: false,
        errorMsg: err.message || 'JSON tidak valid',
        line,
        column,
      });
    }
  }, [inputJson]);

  const handleBeautify = () => {
    if (!parsedObject) {
      toast.error('Gagal Format', 'Format JSON mengandung sintaks yang keliru.');
      return;
    }
    const formatted = JSON.stringify(parsedObject, null, indentSize === 0 ? '\t' : indentSize);
    setInputJson(formatted);
    toast.success('Berhasil', `JSON diformat dengan ${indentSize === 0 ? 'Tab' : `${indentSize} spasi`}.`);
  };

  const handleMinify = () => {
    if (!parsedObject) {
      toast.error('Gagal Minify', 'Format JSON tidak valid.');
      return;
    }
    setInputJson(JSON.stringify(parsedObject));
    toast.success('Berhasil', 'JSON berhasil diminifikasi (1 baris).');
  };

  const handleAutoFix = () => {
    try {
      let cleaned = inputJson
        // Replace single quotes with double quotes
        .replace(/'/g, '"')
        // Remove trailing commas in objects or arrays
        .replace(/,\s*([\]}])/g, '$1')
        // Quote unquoted object keys
        .replace(/([{,]\s*)([a-zA-Z0-9_]+)\s*:/g, '$1"$2":');

      const parsed = JSON.parse(cleaned);
      setInputJson(JSON.stringify(parsed, null, 2));
      toast.success('Auto-Fix Berhasil', 'Kesalahan format petik atau trailing comma diperbaiki!');
    } catch (e: any) {
      toast.error('Auto-Fix Gagal', 'Sintaks terlalu rusak untuk diperbaiki otomatis.');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setInputJson(content);
      toast.success('File Dimuat', `Berkas ${file.name} berhasil dibaca.`);
    };
    reader.readAsText(file);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(inputJson);
    toast.success('Disalin', 'Konten JSON berhasil disalin ke clipboard.');
  };

  const handleDownload = () => {
    downloadTextFile(inputJson, 'formatted-data.json', 'application/json');
    toast.success('Diunduh', 'File formatted-data.json berhasil diunduh.');
  };

  const handleShareUrl = () => {
    const url = new URL(window.location.href);
    url.searchParams.set('tool', 'json-formatter');
    url.searchParams.set('data', encodeURIComponent(inputJson.slice(0, 1500)));
    navigator.clipboard.writeText(url.toString());
    toast.success('Tautan Disalin', 'URL parameter dengan payload JSON disalin ke clipboard.');
  };

  // Simple JSON to YAML converter
  const jsonToYaml = (obj: any, indent = 0): string => {
    if (obj === null) return 'null\n';
    if (typeof obj !== 'object') return `${JSON.stringify(obj)}\n`;

    let yaml = '';
    const spaces = ' '.repeat(indent);

    if (Array.isArray(obj)) {
      if (obj.length === 0) return '[]\n';
      for (const item of obj) {
        if (typeof item === 'object' && item !== null) {
          yaml += `${spaces}- ${jsonToYaml(item, indent + 2).trimStart()}`;
        } else {
          yaml += `${spaces}- ${JSON.stringify(item)}\n`;
        }
      }
    } else {
      if (Object.keys(obj).length === 0) return '{}\n';
      for (const key in obj) {
        const val = obj[key];
        if (typeof val === 'object' && val !== null) {
          yaml += `${spaces}${key}:\n${jsonToYaml(val, indent + 2)}`;
        } else {
          yaml += `${spaces}${key}: ${JSON.stringify(val)}\n`;
        }
      }
    }
    return yaml;
  };

  // Render tree node component
  const renderTreeNode = (data: any, name?: string): React.ReactNode => {
    if (data === null) return <span className="text-slate-400 font-mono">null</span>;
    if (typeof data === 'boolean')
      return <span className="text-amber-500 font-mono font-bold">{String(data)}</span>;
    if (typeof data === 'number')
      return <span className="text-blue-500 font-mono font-bold">{data}</span>;
    if (typeof data === 'string')
      return <span className="text-emerald-600 dark:text-emerald-400 font-mono">"{data}"</span>;

    const isArr = Array.isArray(data);
    const keys = Object.keys(data);

    return (
      <details open className="pl-4 border-l border-slate-200 dark:border-slate-800 my-1 text-xs">
        <summary className="cursor-pointer font-semibold text-slate-700 dark:text-slate-300 hover:text-blue-500 select-none">
          {name && <span className="text-indigo-600 dark:text-indigo-400 font-mono">{name}: </span>}
          <span className="text-slate-500 dark:text-slate-400">
            {isArr ? `Array [${data.length}]` : `Object {${keys.length}}`}
          </span>
        </summary>
        <div className="space-y-1 mt-1">
          {keys.map((k) => (
            <div key={k} className="flex items-start gap-1">
              <span className="font-mono text-slate-600 dark:text-slate-400 font-semibold">{k}:</span>
              {renderTreeNode(data[k])}
            </div>
          ))}
        </div>
      </details>
    );
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <FileJson className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>JSON Formatter & Validator</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Developer & Creator
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Format, validasi sintaks dengan deteksi baris error, konversi ke YAML, perbaiki kesalahan otomatis, dan ekspor instan 100% offline.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleShareUrl}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Bagikan URL</span>
          </button>
          <PrivacyBadge compact />
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 sm:p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex flex-wrap items-center gap-2">
          {/* Indent Selector */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {[
              { label: '2 Spasi', val: 2 },
              { label: '4 Spasi', val: 4 },
              { label: 'Tab', val: 0 },
            ].map((item) => (
              <button
                key={item.label}
                onClick={() => setIndentSize(item.val)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-all ${
                  indentSize === item.val
                    ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <button
            onClick={handleBeautify}
            className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Beautify</span>
          </button>

          <button
            onClick={handleMinify}
            className="px-3.5 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Minimize2 className="w-3.5 h-3.5" />
            <span>Minify</span>
          </button>

          <button
            onClick={handleAutoFix}
            className="px-3.5 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 text-xs font-bold rounded-xl flex items-center gap-1.5 border border-amber-500/30 transition-colors"
            title="Perbaiki tanda petik tunggal & trailing comma secara otomatis"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Auto-Fix</span>
          </button>
        </div>

        {/* Presets & File Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 hidden sm:block">
            Contoh:
          </div>
          <button
            onClick={() => setInputJson(SAMPLE_DATASETS.keyframe)}
            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
          >
            Keyframe JJ
          </button>
          <button
            onClick={() => setInputJson(SAMPLE_DATASETS.social)}
            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
          >
            Sosmed Info
          </button>

          <label className="cursor-pointer px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 flex items-center gap-1">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload</span>
            <input type="file" accept=".json,text/plain" onChange={handleFileUpload} className="hidden" />
          </label>

          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
            title="Salin JSON"
          >
            <Copy className="w-4 h-4" />
          </button>

          <button
            onClick={handleDownload}
            className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
            title="Download .json"
          >
            <Download className="w-4 h-4" />
          </button>

          <button
            onClick={() => setInputJson('')}
            className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 text-rose-600 dark:text-rose-400"
            title="Bersihkan editor"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Validation Status Indicator */}
      <div
        className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
          validationResult.isValid
            ? 'bg-emerald-500/5 dark:bg-emerald-950/20 border-emerald-500/30 text-emerald-800 dark:text-emerald-300'
            : 'bg-rose-500/5 dark:bg-rose-950/20 border-rose-500/30 text-rose-800 dark:text-rose-300'
        }`}
      >
        <div className="flex items-center gap-2.5">
          {validationResult.isValid ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0" />
          )}
          <span className="text-xs sm:text-sm font-semibold">
            {validationResult.isValid
              ? 'Sintaks JSON Valid & Siap Digunakan'
              : `Error Sintaks: ${validationResult.errorMsg} (Baris ${validationResult.line}, Kolom ${validationResult.column})`}
          </span>
        </div>

        {validationResult.isValid && validationResult.stats && (
          <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
            <span>Total Kunci: <b>{validationResult.stats.keys}</b></span>
            <span>Kedalaman: <b>{validationResult.stats.depth}</b></span>
            <span>Ukuran: <b>{(validationResult.stats.sizeBytes / 1024).toFixed(2)} KB</b></span>
          </div>
        )}
      </div>

      {/* Main Workspace: Editor Tabs */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        {/* Tabs Bar */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 px-4 pt-2 bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('editor')}
              className={`px-3 py-2 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === 'editor'
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Kode JSON</span>
            </button>
            <button
              onClick={() => setActiveTab('tree')}
              className={`px-3 py-2 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === 'tree'
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Pohon Hirarki (Tree Explorer)</span>
            </button>
            <button
              onClick={() => setActiveTab('yaml')}
              className={`px-3 py-2 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
                activeTab === 'yaml'
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Konversi YAML</span>
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-4 sm:p-5">
          {activeTab === 'editor' && (
            <textarea
              value={inputJson}
              onChange={(e) => setInputJson(e.target.value)}
              placeholder="Tempel atau ketik kode JSON di sini..."
              rows={18}
              className="w-full font-mono text-xs sm:text-sm p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-900 text-emerald-400 dark:bg-slate-950 dark:text-emerald-300 focus:outline-hidden focus:ring-2 focus:ring-blue-500 leading-relaxed shadow-inner"
              spellCheck={false}
            />
          )}

          {activeTab === 'tree' && (
            <div className="min-h-[350px] max-h-[500px] overflow-y-auto p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
              {parsedObject ? (
                renderTreeNode(parsedObject)
              ) : (
                <div className="text-center py-12 text-xs text-slate-400">
                  Masukkan JSON yang valid pada editor untuk melihat pohon data.
                </div>
              )}
            </div>
          )}

          {activeTab === 'yaml' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Hasil Konversi Format YAML:
                </span>
                <button
                  onClick={() => {
                    const yamlStr = parsedObject ? jsonToYaml(parsedObject) : '';
                    navigator.clipboard.writeText(yamlStr);
                    toast.success('Disalin', 'YAML berhasil disalin.');
                  }}
                  className="px-2.5 py-1 text-xs font-bold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin YAML</span>
                </button>
              </div>
              <pre className="p-4 rounded-xl font-mono text-xs sm:text-sm bg-slate-900 text-sky-300 dark:bg-slate-950 dark:text-sky-300 overflow-x-auto min-h-[300px]">
                {parsedObject ? jsonToYaml(parsedObject) : '# JSON tidak valid'}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
