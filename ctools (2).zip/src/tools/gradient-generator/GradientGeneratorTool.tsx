import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  Palette,
  Copy,
  Check,
  Download,
  Sliders,
  Sparkles,
  RefreshCw,
  Eye,
} from 'lucide-react';

const PRESET_GRADIENTS = [
  { name: 'Cyberpunk Neon', colors: ['#FF007A', '#7928CA', '#00DFD8'], angle: 135 },
  { name: 'Jedag Jedug Gold', colors: ['#F59E0B', '#EF4444', '#7C3AED'], angle: 90 },
  { name: 'Deep Midnight', colors: ['#0F172A', '#1E293B', '#3B82F6'], angle: 180 },
  { name: 'Aurora Borealis', colors: ['#00F260', '#0575E6', '#8E2DE2'], angle: 45 },
  { name: 'Sunset Glow', colors: ['#FF512F', '#DD2476', '#FF8C00'], angle: 120 },
  { name: 'Electric Purple', colors: ['#667EEA', '#764BA2', '#6B8DD6'], angle: 90 },
];

export const GradientGeneratorTool: React.FC = () => {
  const [type, setType] = useState<'linear' | 'radial'>('linear');
  const [angle, setAngle] = useState<number>(135);
  const [color1, setColor1] = useState<string>('#3B82F6');
  const [color2, setColor2] = useState<string>('#8B5CF6');
  const [color3, setColor3] = useState<string>('#EC4899');
  const [use3Colors, setUse3Colors] = useState<boolean>(true);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const getCssGradient = () => {
    if (type === 'linear') {
      return use3Colors
        ? `linear-gradient(${angle}deg, ${color1} 0%, ${color2} 50%, ${color3} 100%)`
        : `linear-gradient(${angle}deg, ${color1} 0%, ${color2} 100%)`;
    } else {
      return use3Colors
        ? `radial-gradient(circle, ${color1} 0%, ${color2} 60%, ${color3} 100%)`
        : `radial-gradient(circle, ${color1} 0%, ${color2} 100%)`;
    }
  };

  const cssStyle = getCssGradient();

  const handleCopyCss = () => {
    navigator.clipboard.writeText(`background: ${cssStyle};`);
    setCopiedKey('css');
    toast.success('Disalin', 'Kode CSS background gradient disalin ke clipboard.');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownloadPng = (width = 1080, height = 1920) => {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (type === 'linear') {
      const rad = (angle * Math.PI) / 180;
      const x1 = width / 2 - (Math.cos(rad) * width) / 2;
      const y1 = height / 2 - (Math.sin(rad) * height) / 2;
      const x2 = width / 2 + (Math.cos(rad) * width) / 2;
      const y2 = height / 2 + (Math.sin(rad) * height) / 2;
      const grad = ctx.createLinearGradient(x1, y1, x2, y2);
      grad.addColorStop(0, color1);
      if (use3Colors) grad.addColorStop(0.5, color2);
      grad.addColorStop(1, use3Colors ? color3 : color2);
      ctx.fillStyle = grad;
    } else {
      const grad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        0,
        width / 2,
        height / 2,
        Math.max(width, height) / 1.5
      );
      grad.addColorStop(0, color1);
      if (use3Colors) grad.addColorStop(0.6, color2);
      grad.addColorStop(1, use3Colors ? color3 : color2);
      ctx.fillStyle = grad;
    }

    ctx.fillRect(0, 0, width, height);

    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = `ctools-gradient-${width}x${height}-${Date.now()}.png`;
    a.click();
    toast.success('Diunduh', `Gambar background gradient ${width}x${height} berhasil disimpan.`);
  };

  const handleRandomize = () => {
    const randColor = () =>
      '#' +
      Math.floor(Math.random() * 16777215)
        .toString(16)
        .padStart(6, '0');
    setColor1(randColor());
    setColor2(randColor());
    setColor3(randColor());
    setAngle(Math.floor(Math.random() * 360));
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Palette className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Gradient Generator & Backdrop Exporter</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Linear & Radial
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Buat transisi warna gradasi mulus multi-stop, salin kode CSS, dan ekspor backdrop video HD/4K instan.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls Sidebar */}
        <div className="lg:col-span-5 space-y-5 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          {/* Type Selector */}
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Tipe Gradasi:</span>
            <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
              <button
                onClick={() => setType('linear')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  type === 'linear'
                    ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Linear
              </button>
              <button
                onClick={() => setType('radial')}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  type === 'radial'
                    ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Radial
              </button>
            </div>
          </div>

          {/* Color Stops */}
          <div className="space-y-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Color Stops</span>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={use3Colors}
                  onChange={(e) => setUse3Colors(e.target.checked)}
                  className="rounded-sm text-blue-600"
                />
                <span>3 Warna</span>
              </label>
            </div>

            <div className="space-y-2.5">
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={color1}
                  onChange={(e) => setColor1(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <input
                  type="text"
                  value={color1}
                  onChange={(e) => setColor1(e.target.value)}
                  className="flex-1 px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 uppercase"
                />
              </div>

              {use3Colors && (
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={color2}
                    onChange={(e) => setColor2(e.target.value)}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                  />
                  <input
                    type="text"
                    value={color2}
                    onChange={(e) => setColor2(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 uppercase"
                  />
                </div>
              )}

              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={use3Colors ? color3 : color2}
                  onChange={(e) => (use3Colors ? setColor3(e.target.value) : setColor2(e.target.value))}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <input
                  type="text"
                  value={use3Colors ? color3 : color2}
                  onChange={(e) => (use3Colors ? setColor3(e.target.value) : setColor2(e.target.value))}
                  className="flex-1 px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 uppercase"
                />
              </div>
            </div>
          </div>

          {/* Angle Slider (if Linear) */}
          {type === 'linear' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                <span>Sudut Derajat Putaran:</span>
                <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{angle}°</span>
              </div>
              <input
                type="range"
                min={0}
                max={360}
                value={angle}
                onChange={(e) => setAngle(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
              <div className="flex justify-between gap-1 pt-1">
                {[0, 45, 90, 135, 180, 270].map((deg) => (
                  <button
                    key={deg}
                    onClick={() => setAngle(deg)}
                    className="px-2 py-0.5 text-[10px] font-bold rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
                  >
                    {deg}°
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Randomize */}
          <button
            onClick={handleRandomize}
            className="w-full py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Acak Warna Gradasi (Randomize)</span>
          </button>

          {/* Presets */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Preset Pilihan:</span>
            <div className="grid grid-cols-3 gap-2">
              {PRESET_GRADIENTS.map((p) => (
                <button
                  key={p.name}
                  onClick={() => {
                    setColor1(p.colors[0]);
                    setColor2(p.colors[1]);
                    setColor3(p.colors[2]);
                    setAngle(p.angle);
                    setUse3Colors(true);
                  }}
                  className="h-10 rounded-xl border border-slate-200 dark:border-slate-700 shadow-xs hover:scale-105 transition-transform"
                  style={{
                    background: `linear-gradient(135deg, ${p.colors[0]}, ${p.colors[1]}, ${p.colors[2]})`,
                  }}
                  title={p.name}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Live Preview & Export */}
        <div className="lg:col-span-7 space-y-5">
          <div
            className="w-full h-80 sm:h-96 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 flex flex-col justify-end p-5 transition-all"
            style={{ background: cssStyle }}
          >
            <div className="backdrop-blur-md bg-black/40 p-3.5 rounded-xl border border-white/20 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-xs font-mono truncate">{cssStyle}</span>
              <button
                onClick={handleCopyCss}
                className="shrink-0 px-3 py-1.5 bg-white text-slate-900 hover:bg-slate-100 text-xs font-bold rounded-lg flex items-center gap-1 shadow-xs"
              >
                {copiedKey === 'css' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Salin CSS</span>
              </button>
            </div>
          </div>

          {/* Export Buttons */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Download Gambar Wallpaper / Video Backdrop HD:
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => handleDownloadPng(1080, 1920)}
                className="py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Portrait 9:16 (1080x1920)</span>
              </button>

              <button
                onClick={() => handleDownloadPng(1920, 1080)}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Unduh Landscape 16:9 (1920x1080)</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
