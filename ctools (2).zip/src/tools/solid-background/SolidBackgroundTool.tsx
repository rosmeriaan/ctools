import React, { useState, useRef } from 'react';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { ProcessingState } from '../../types';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { Palette, Download, Film, Image as ImageIcon, Sparkles } from 'lucide-react';

interface PresetColor {
  name: string;
  color: string;
  textColor: string;
}

const PRESETS: PresetColor[] = [
  { name: 'Chroma Green Screen', color: '#00ff00', textColor: '#000' },
  { name: 'Chroma Blue Screen', color: '#0000ff', textColor: '#fff' },
  { name: 'Pure Pitch Black', color: '#000000', textColor: '#fff' },
  { name: 'Pure Clean White', color: '#ffffff', textColor: '#000' },
  { name: 'Studio Dark Slate', color: '#0f172a', textColor: '#fff' },
  { name: 'Cyberpunk Neon Pink', color: '#ff007f', textColor: '#fff' },
  { name: 'Cyber Cyan Blue', color: '#00f0ff', textColor: '#000' },
  { name: 'Warm Amber Sunset', color: '#f59e0b', textColor: '#000' },
];

export const SolidBackgroundTool: React.FC = () => {
  const [color, setColor] = useState<string>('#00ff00');
  const [resolution, setResolution] = useState<{ w: number; h: number; label: string }>({
    w: 1080,
    h: 1920,
    label: '9:16 TikTok / Reels (1080x1920)',
  });
  const [videoDuration, setVideoDuration] = useState<number>(5);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap membuat background',
    step: 'idle',
  });

  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleDownloadImage = () => {
    const canvas = document.createElement('canvas');
    canvas.width = resolution.w;
    canvas.height = resolution.h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = color;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    canvas.toBlob((blob) => {
      if (blob) {
        downloadBlob(blob, `ctools-solid-bg-${color.replace('#', '')}-${resolution.w}x${resolution.h}.png`);
        toast.success('Berhasil', 'Gambar latar belakang PNG berhasil diunduh.');
      }
    }, 'image/png');
  };

  const handleGenerateVideo = async () => {
    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan generator video FFmpeg...',
      step: 'preparing',
    });

    try {
      // 1. Create a 1-frame image from canvas
      const canvas = document.createElement('canvas');
      canvas.width = resolution.w;
      canvas.height = resolution.h;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas context error');

      ctx.fillStyle = color;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const imgBlob = await new Promise<Blob>((res) => canvas.toBlob((b) => res(b!), 'image/png'));
      const inputName = 'bg.png';
      const outputName = 'solid_video.mp4';

      const args = [
        '-loop',
        '1',
        '-i',
        inputName,
        '-c:v',
        'libx264',
        '-t',
        videoDuration.toString(),
        '-pix_fmt',
        'yuv420p',
        '-preset',
        'ultrafast',
        outputName,
      ];

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: imgBlob }],
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Merender video latar (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      downloadBlob(blob, `ctools-backdrop-${color.replace('#', '')}-${videoDuration}s.mp4`);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Video backdrop berhasil diunduh!',
        step: 'completed',
      });
      toast.success('Berhasil', `Video backdrop ${videoDuration} detik berhasil diunduh.`);
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal membuat video backdrop.',
        step: 'error',
        error: err?.message,
      });
      toast.error('Gagal', 'Gagal merender video.');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Palette className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Solid Color & Green Screen Generator</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              HD / 4K / MP4 / PNG
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Buat latar belakang warna polos (Green screen, Blue screen, Pitch Black) dalam bentuk gambar HD atau video berdurasi.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Pratinjau Latar Belakang:
            </h3>

            <div
              style={{ backgroundColor: color }}
              className="w-full aspect-video rounded-2xl border border-slate-300 dark:border-slate-700 shadow-inner flex items-center justify-center transition-colors"
            >
              <span className="px-3 py-1.5 rounded-xl bg-black/60 text-white text-xs font-mono font-bold backdrop-blur-sm">
                {color.toUpperCase()} • {resolution.w}x{resolution.h}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleDownloadImage}
                className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <ImageIcon className="w-4 h-4" />
                <span>Download PNG HD</span>
              </button>

              <button
                onClick={handleGenerateVideo}
                disabled={processing.isProcessing}
                className="py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <Film className="w-4 h-4" />
                <span>{processing.isProcessing ? 'Merender...' : `Download MP4 (${videoDuration}s)`}</span>
              </button>
            </div>

            {processing.isProcessing && (
              <ProgressBar progress={processing.progress} statusText={processing.statusText} />
            )}
          </div>
        </div>

        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Pilihan Warna Cepat:
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {PRESETS.map((p) => (
                <button
                  key={p.name}
                  onClick={() => setColor(p.color)}
                  style={{ backgroundColor: p.color, color: p.textColor }}
                  className={`p-2.5 rounded-xl text-center text-xs font-bold border transition-all cursor-pointer ${
                    color.toLowerCase() === p.color.toLowerCase()
                      ? 'ring-2 ring-blue-500 scale-105 shadow-md'
                      : 'border-slate-300 dark:border-slate-700'
                  }`}
                >
                  <span className="block truncate text-[11px]">{p.name}</span>
                </button>
              ))}
            </div>

            {/* Custom Color Input */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800">
              <label className="text-xs text-slate-500">Warna Kustom (Hex / Color Picker):</label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-10 h-10 rounded-xl border cursor-pointer"
                />
                <input
                  type="text"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                />
              </div>
            </div>

            {/* Resolution Selector */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-500">Resolusi Canvas:</label>
              <select
                value={`${resolution.w}x${resolution.h}`}
                onChange={(e) => {
                  const [w, h] = e.target.value.split('x').map(Number);
                  setResolution({ w, h, label: e.target.options[e.target.selectedIndex].text });
                }}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
              >
                <option value="1080x1920">9:16 TikTok / Reels / Shorts (1080x1920)</option>
                <option value="1920x1080">16:9 YouTube Full HD (1920x1080)</option>
                <option value="3840x2160">16:9 4K Ultra HD (3840x2160)</option>
                <option value="1080x1080">1:1 Square Feed (1080x1080)</option>
                <option value="1080x1350">4:5 Instagram Portrait (1080x1350)</option>
              </select>
            </div>

            {/* Duration Selector for Video */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-500">Durasi Video MP4:</label>
              <div className="grid grid-cols-4 gap-2">
                {[3, 5, 10, 30].map((sec) => (
                  <button
                    key={sec}
                    onClick={() => setVideoDuration(sec)}
                    className={`py-2 text-xs font-bold rounded-xl border cursor-pointer ${
                      videoDuration === sec
                        ? 'border-blue-600 bg-blue-600 text-white'
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {sec} Detik
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
