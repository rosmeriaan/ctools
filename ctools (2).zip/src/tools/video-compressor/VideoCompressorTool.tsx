import React, { useState, useRef } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatFileSize, formatDuration } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { FFmpegCommands } from '../../core/ffmpeg/commands';
import { Minimize2, Film, Download, CheckCircle, Sliders, Play, Pause } from 'lucide-react';

export const VideoCompressorTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');

  const [resolution, setResolution] = useState<string>('1280:-2'); // 720p default
  const [crf, setCrf] = useState<number>(28); // 28 = balanced
  const [fps, setFps] = useState<number>(30);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap mengompres video',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const videoRef = useRef<HTMLVideoElement>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setVideoUrl(url);
    setOutputBlob(null);
    setOutputUrl('');

    const meta: FileMetadata = {
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    };
    setFileMetadata(meta);
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current && fileMetadata) {
      setFileMetadata({
        ...fileMetadata,
        duration: videoRef.current.duration,
        dimensions: {
          width: videoRef.current.videoWidth,
          height: videoRef.current.videoHeight,
        },
      });
    }
  };

  const handleCompress = async () => {
    if (!file) return;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan encoder WebAssembly...',
      step: 'preparing',
    });

    try {
      const inputExt = file.name.split('.').pop() || 'mp4';
      const inputName = `input.${inputExt}`;
      const outputName = 'compressed.mp4';

      const scaleArg = resolution === 'original' ? undefined : resolution;
      const fpsArg = fps === 0 ? undefined : fps;

      const args = FFmpegCommands.compressVideo(
        inputName,
        outputName,
        scaleArg,
        fpsArg,
        crf
      );

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Mengompres video (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Kompresi video selesai!',
        step: 'completed',
      });
      toast.success('Berhasil', 'Video berhasil dikompres.');
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal mengompres video.',
        step: 'error',
        error: err?.message || 'Error',
      });
      toast.error('Kompresi Gagal', err?.message || 'Gagal mengompres video.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob || !file) return;
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    downloadBlob(outputBlob, `ctools-compressed-${baseName}.mp4`);
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setVideoUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  const savedBytes = file && outputBlob ? file.size - outputBlob.size : 0;
  const savedPercent = file && outputBlob ? Math.round((savedBytes / file.size) * 100) : 0;

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Minimize2 className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Video Compressor</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Offline H.264
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Perkecil ukuran video dengan resolusi dan bitrate fleksibel tanpa batas kuota server.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['video/mp4', 'video/webm', 'video/quicktime']}
          maxSizeMB={300}
          title="Pilih Video yang Ingin Dikompres"
          description="Mendukung MP4, WebM, MOV hingga 300 MB"
          icon={<Film className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                <video
                  ref={videoRef}
                  src={videoUrl}
                  onLoadedMetadata={handleLoadedMetadata}
                  controls
                  className="w-full h-full object-contain"
                />
              </div>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-600" />
                <span>Pengaturan Kompresi</span>
              </h3>

              {/* Resolution selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Target Resolusi:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Original', val: 'original' },
                    { label: '1080p (HD)', val: '1920:-2' },
                    { label: '720p (Hemat)', val: '1280:-2' },
                    { label: '480p (Ringan)', val: '854:-2' },
                    { label: '360p (Sangat Kecil)', val: '640:-2' },
                  ].map((item) => (
                    <button
                      key={item.val}
                      onClick={() => setResolution(item.val)}
                      className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
                        resolution === item.val
                          ? 'border-blue-600 bg-blue-600/10 text-blue-600 dark:text-blue-400 font-bold'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Compression Rate (CRF) */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span>Tingkat Kompresi (CRF):</span>
                  <span className="font-mono text-blue-600">CRF {crf}</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Kualitas Tinggi (CRF 22)', val: 22 },
                    { label: 'Seimbang (CRF 28)', val: 28 },
                    { label: 'Ukuran Terkecil (CRF 34)', val: 34 },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setCrf(opt.val)}
                      className={`px-2.5 py-2 text-[11px] font-semibold rounded-xl border transition-all cursor-pointer text-center ${
                        crf === opt.val
                          ? 'border-blue-600 bg-blue-600/10 text-blue-600 dark:text-blue-400 font-bold'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* FPS Selector */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Frame Rate (FPS):
                </label>
                <div className="flex gap-2">
                  {[
                    { label: 'Original', val: 0 },
                    { label: '30 FPS', val: 30 },
                    { label: '24 FPS (Cinematic)', val: 24 },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setFps(opt.val)}
                      className={`flex-1 py-1.5 px-2 text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
                        fps === opt.val
                          ? 'border-blue-600 bg-blue-600/10 text-blue-600 dark:text-blue-400 font-bold'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputBlob && (
                <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300 font-bold text-xs">
                    <CheckCircle className="w-4 h-4" />
                    <span>Kompresi Berhasil!</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 rounded-lg bg-white/60 dark:bg-slate-900/60">
                      <span className="text-slate-400 block text-[10px]">Ukuran Awal</span>
                      <span className="font-bold text-slate-700 dark:text-slate-300">{formatFileSize(file.size)}</span>
                    </div>
                    <div className="p-2 rounded-lg bg-white/60 dark:bg-slate-900/60">
                      <span className="text-slate-400 block text-[10px]">Ukuran Hasil</span>
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{formatFileSize(outputBlob.size)}</span>
                    </div>
                  </div>
                  {savedPercent > 0 && (
                    <div className="text-center text-xs font-bold text-emerald-600 dark:text-emerald-400">
                      Hemat {savedPercent}% ({formatFileSize(savedBytes)})
                    </div>
                  )}
                </div>
              )}

              {outputUrl ? (
                <div className="space-y-2">
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Video Terkompres</span>
                  </button>
                  <button
                    onClick={handleCompress}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-semibold cursor-pointer"
                  >
                    Kompres Lagi dengan Preset Lain
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleCompress}
                  disabled={processing.isProcessing}
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                >
                  <Minimize2 className="w-4 h-4" />
                  <span>{processing.isProcessing ? 'Mengompres Video...' : 'Mulai Kompres Video'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
