import React, { useState } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { FFmpegCommands } from '../../core/ffmpeg/commands';
import { Film, Download } from 'lucide-react';

export const GifToVideoTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [gifUrl, setGifUrl] = useState<string>('');
  const [fps, setFps] = useState<number>(30);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap mengonversi GIF ke Video',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const handleFileSelect = (selectedFile: File) => {
    if (gifUrl) URL.revokeObjectURL(gifUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setGifUrl(url);
    setOutputBlob(null);
    setOutputUrl('');

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleConvert = async () => {
    if (!file) return;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan engine FFmpeg...',
      step: 'preparing',
    });

    try {
      const inputName = 'input.gif';
      const outputName = 'output.mp4';

      const args = FFmpegCommands.gifToVideo(inputName, outputName, fps);

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Mengonversi ke MP4 (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Konversi ke MP4 berhasil!',
        step: 'completed',
      });
      toast.success('Berhasil', 'GIF berhasil diubah menjadi video MP4.');
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal mengonversi GIF ke Video.',
        step: 'error',
        error: err?.message || 'Error',
      });
      toast.error('Gagal', err?.message || 'Gagal mengonversi GIF.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob || !file) return;
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    downloadBlob(outputBlob, `ctools-${baseName}.mp4`);
  };

  const handleReset = () => {
    if (gifUrl) URL.revokeObjectURL(gifUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setGifUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Film className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>GIF to Video Converter</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              MP4 H.264
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ubah animasi GIF menjadi format video MP4 berukuran jauh lebih kecil.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['image/gif']}
          maxSizeMB={50}
          title="Pilih Berkas GIF untuk Diubah ke Video"
          description="Mendukung GIF hingga 50 MB"
          icon={<Film className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-center min-h-64">
              <img src={gifUrl} alt="GIF Input" className="max-h-72 object-contain rounded-xl" />
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Pengaturan Output Video:
              </h3>

              <div className="space-y-2">
                <label className="text-xs text-slate-500">Frame Rate Target (FPS):</label>
                <div className="flex gap-2">
                  {[24, 30, 60].map((f) => (
                    <button
                      key={f}
                      onClick={() => setFps(f)}
                      className={`flex-1 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                        fps === f
                          ? 'border-blue-600 bg-blue-600 text-white shadow-xs'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {f} FPS
                    </button>
                  ))}
                </div>
              </div>

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputUrl ? (
                <div className="space-y-3">
                  <div className="rounded-xl overflow-hidden bg-black aspect-video">
                    <video src={outputUrl} controls loop autoPlay muted className="w-full h-full object-contain" />
                  </div>
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download MP4 ({formatFileSize(outputBlob?.size || 0)})</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleConvert}
                  disabled={processing.isProcessing}
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                >
                  <Film className="w-4 h-4" />
                  <span>{processing.isProcessing ? 'Mengonversi...' : 'Konversi ke Video MP4'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
