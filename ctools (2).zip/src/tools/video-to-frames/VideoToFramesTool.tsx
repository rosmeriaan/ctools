import React, { useState, useRef } from 'react';
import JSZip from 'jszip';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatFileSize, formatDuration } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { Images, Download, Film, Eye, FileArchive, Check } from 'lucide-react';

interface ExtractedFrame {
  id: number;
  timeSec: number;
  dataUrl: string;
  blob: Blob;
}

export const VideoToFramesTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [duration, setDuration] = useState<number>(0);

  const [intervalSec, setIntervalSec] = useState<number>(1.0); // every 1 sec
  const [format, setFormat] = useState<'image/png' | 'image/jpeg'>('image/png');
  const [maxFrames, setMaxFrames] = useState<number>(60);

  const [frames, setFrames] = useState<ExtractedFrame[]>([]);
  const [selectedFrame, setSelectedFrame] = useState<ExtractedFrame | null>(null);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap mengekstrak frame',
    step: 'idle',
  });

  const videoRef = useRef<HTMLVideoElement>(null);

  const handleFileSelect = (selectedFile: File) => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setVideoUrl(url);
    setFrames([]);
    setSelectedFrame(null);

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration || 0);
    }
  };

  const handleExtractFrames = async () => {
    if (!file || !videoUrl) return;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Mempersiapkan pemutaran video frame demi frame...',
      step: 'processing',
    });
    setFrames([]);

    const offscreenVideo = document.createElement('video');
    offscreenVideo.src = videoUrl;
    offscreenVideo.muted = true;
    offscreenVideo.playsInline = true;

    await new Promise<void>((resolve, reject) => {
      offscreenVideo.onloadedmetadata = () => resolve();
      offscreenVideo.onerror = () => reject(new Error('Gagal membaca video'));
    });

    const totalDur = offscreenVideo.duration || 1;
    const canvas = document.createElement('canvas');
    canvas.width = offscreenVideo.videoWidth || 1280;
    canvas.height = offscreenVideo.videoHeight || 720;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      toast.error('Error', 'Browser Canvas tidak didukung.');
      return;
    }

    const timestamps: number[] = [];
    for (let t = 0; t < totalDur && timestamps.length < maxFrames; t += intervalSec) {
      timestamps.push(t);
    }

    const extractedList: ExtractedFrame[] = [];

    const seekPromise = (time: number) => {
      return new Promise<void>((resolve) => {
        const onSeeked = () => {
          offscreenVideo.removeEventListener('seeked', onSeeked);
          resolve();
        };
        offscreenVideo.addEventListener('seeked', onSeeked);
        offscreenVideo.currentTime = time;
      });
    };

    try {
      for (let i = 0; i < timestamps.length; i++) {
        const time = timestamps[i];
        await seekPromise(time);

        ctx.drawImage(offscreenVideo, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL(format, 0.95);

        const blob = await new Promise<Blob>((res) =>
          canvas.toBlob((b) => res(b!), format, 0.95)
        );

        extractedList.push({
          id: i + 1,
          timeSec: time,
          dataUrl,
          blob,
        });

        const progressPercent = Math.round(((i + 1) / timestamps.length) * 100);
        setProcessing({
          isProcessing: true,
          progress: progressPercent,
          statusText: `Mengekstrak frame ${i + 1} dari ${timestamps.length}...`,
          step: 'processing',
        });
      }

      setFrames(extractedList);
      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: `Selesai mengekstrak ${extractedList.length} frame!`,
        step: 'completed',
      });
      toast.success('Berhasil', `${extractedList.length} frame berhasil diekstrak.`);
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal mengekstrak frame.',
        step: 'error',
        error: err?.message,
      });
      toast.error('Gagal', 'Terjadi kesalahan saat ekstraksi frame.');
    }
  };

  const handleDownloadZip = async () => {
    if (frames.length === 0) return;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Mengompresi frame ke dalam arsip ZIP...',
      step: 'finalizing',
    });

    try {
      const zip = new JSZip();
      const folder = zip.folder('frames') || zip;
      const ext = format === 'image/png' ? 'png' : 'jpg';

      frames.forEach((f, idx) => {
        const num = String(idx + 1).padStart(4, '0');
        const filename = `frame_${num}_${f.timeSec.toFixed(2)}s.${ext}`;
        folder.file(filename, f.blob);
      });

      const zipBlob = await zip.generateAsync({ type: 'blob' }, (metadata) => {
        setProcessing((p) => ({
          ...p,
          progress: Math.round(metadata.percent),
          statusText: `Membuat ZIP (${Math.round(metadata.percent)}%)...`,
        }));
      });

      const baseName = file?.name.replace(/\.[^/.]+$/, '') || 'video';
      downloadBlob(zipBlob, `ctools-${baseName}-frames.zip`);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'ZIP berhasil diunduh!',
        step: 'completed',
      });
      toast.success('Berhasil', 'Paket ZIP frame berhasil diunduh.');
    } catch (err: any) {
      console.error(err);
      toast.error('Gagal', 'Gagal membuat file ZIP.');
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal membuat ZIP',
        step: 'error',
      });
    }
  };

  const handleDownloadSingle = (f: ExtractedFrame) => {
    const ext = format === 'image/png' ? 'png' : 'jpg';
    downloadBlob(f.blob, `frame_${String(f.id).padStart(4, '0')}.${ext}`);
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    setFile(null);
    setFileMetadata(null);
    setVideoUrl('');
    setFrames([]);
    setSelectedFrame(null);
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Images className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Video to Frames Extractor</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              PNG / JPG + ZIP Export
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ekstrak urutan gambar dari video berdasarkan interval waktu dan unduh sekaligus dalam file ZIP.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['video/mp4', 'video/webm', 'video/quicktime']}
          maxSizeMB={100}
          title="Pilih Video untuk Diekstrak Framenya"
          description="Mendukung MP4, WebM, MOV hingga 100 MB"
          icon={<Film className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 space-y-4">
              <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
                <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                  <video
                    ref={videoRef}
                    src={videoUrl}
                    onLoadedMetadata={handleLoadedMetadata}
                    controls
                    className="w-full h-full object-contain"
                  />
                </div>
              </div>

              {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
            </div>

            <div className="lg:col-span-6 space-y-4">
              <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Pengaturan Interval Ekstraksi:
                </h3>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-500">Interval Waktu:</label>
                    <select
                      value={intervalSec}
                      onChange={(e) => setIntervalSec(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    >
                      <option value="0.2">Setiap 0.2 detik (5 fps)</option>
                      <option value="0.5">Setiap 0.5 detik (2 fps)</option>
                      <option value="1">Setiap 1 detik</option>
                      <option value="2">Setiap 2 detik</option>
                      <option value="5">Setiap 5 detik</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-500">Format Gambar:</label>
                    <select
                      value={format}
                      onChange={(e) => setFormat(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                    >
                      <option value="image/png">PNG (Lossless)</option>
                      <option value="image/jpeg">JPEG (Ukuran Ringan)</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-500">Batas Maksimal Frame:</label>
                  <select
                    value={maxFrames}
                    onChange={(e) => setMaxFrames(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                  >
                    <option value="30">30 Frame</option>
                    <option value="60">60 Frame</option>
                    <option value="120">120 Frame</option>
                    <option value="200">200 Frame</option>
                  </select>
                </div>

                {processing.isProcessing && (
                  <ProgressBar
                    progress={processing.progress}
                    statusText={processing.statusText}
                  />
                )}

                <div className="flex gap-2">
                  <button
                    onClick={handleExtractFrames}
                    disabled={processing.isProcessing}
                    className="flex-1 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                  >
                    <Images className="w-4 h-4" />
                    <span>{processing.isProcessing ? 'Mengekstrak...' : 'Mulai Ekstrak Frame'}</span>
                  </button>

                  {frames.length > 0 && (
                    <button
                      onClick={handleDownloadZip}
                      disabled={processing.isProcessing}
                      className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                    >
                      <FileArchive className="w-4 h-4" />
                      <span>Download ZIP ({frames.length})</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Extracted Frames Gallery */}
          {frames.length > 0 && (
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                  <span>Hasil Galeri ({frames.length} Frame)</span>
                </h3>
                <button
                  onClick={handleDownloadZip}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Semua (ZIP)</span>
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3 max-h-96 overflow-y-auto p-1">
                {frames.map((f) => (
                  <div
                    key={f.id}
                    className="group relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 aspect-video flex items-center justify-center"
                  >
                    <img src={f.dataUrl} alt={`Frame ${f.id}`} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-1.5 text-[10px] text-white">
                      <span className="font-mono">{formatDuration(f.timeSec)}</span>
                      <button
                        onClick={() => handleDownloadSingle(f)}
                        className="p-1 rounded-md bg-blue-600 hover:bg-blue-700 self-end text-white cursor-pointer"
                        title="Download Frame"
                      >
                        <Download className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
