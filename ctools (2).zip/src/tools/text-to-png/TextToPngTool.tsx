import React, { useState, useRef, useEffect } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  Type,
  Download,
  Sliders,
  Sparkles,
  Layers,
  Palette,
  Eye,
  RefreshCw,
} from 'lucide-react';

export const TextToPngTool: React.FC = () => {
  const [text, setText] = useState<string>('JEDAG JEDUG\nMOTION PRESET');
  const [fontFamily, setFontFamily] = useState<string>('Impact');
  const [fontSize, setFontSize] = useState<number>(72);
  const [textColor, setTextColor] = useState<string>('#FFFFFF');
  const [isGradient, setIsGradient] = useState<boolean>(true);
  const [gradientColor2, setGradientColor2] = useState<string>('#38BDF8');
  const [gradientAngle, setGradientAngle] = useState<number>(90);

  // Stroke / Outline
  const [enableStroke, setEnableStroke] = useState<boolean>(true);
  const [strokeColor, setStrokeColor] = useState<string>('#000000');
  const [strokeWidth, setStrokeWidth] = useState<number>(10);

  // Shadow / Glow
  const [enableShadow, setEnableShadow] = useState<boolean>(true);
  const [shadowColor, setShadowColor] = useState<string>('#0284C7');
  const [shadowBlur, setShadowBlur] = useState<number>(25);
  const [shadowOffsetY, setShadowOffsetY] = useState<number>(8);

  // Layout & Canvas
  const [canvasPreset, setCanvasPreset] = useState<'9:16' | '16:9' | '1:1' | 'fit'>('9:16');
  const [bgType, setBgType] = useState<'transparent' | 'green' | 'black'>('transparent');
  const [letterSpacing, setLetterSpacing] = useState<number>(4);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Render on canvas
  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = 1080;
    let height = 1920;
    if (canvasPreset === '16:9') {
      width = 1920;
      height = 1080;
    } else if (canvasPreset === '1:1') {
      width = 1080;
      height = 1080;
    } else if (canvasPreset === 'fit') {
      width = 1080;
      height = 600;
    }

    canvas.width = width;
    canvas.height = height;

    // Background
    ctx.clearRect(0, 0, width, height);
    if (bgType === 'green') {
      ctx.fillStyle = '#00FF00';
      ctx.fillRect(0, 0, width, height);
    } else if (bgType === 'black') {
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, width, height);
    }

    const lines = text.split('\n');
    const lineHeight = fontSize * 1.25;
    const startY = height / 2 - ((lines.length - 1) * lineHeight) / 2;

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `900 ${fontSize}px ${fontFamily}, system-ui, sans-serif`;

    lines.forEach((line, index) => {
      const y = startY + index * lineHeight;
      const x = width / 2;

      // Shadow / Glow
      if (enableShadow) {
        ctx.shadowColor = shadowColor;
        ctx.shadowBlur = shadowBlur;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = shadowOffsetY;
      } else {
        ctx.shadowColor = 'transparent';
        ctx.shadowBlur = 0;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 0;
      }

      // Stroke
      if (enableStroke && strokeWidth > 0) {
        ctx.strokeStyle = strokeColor;
        ctx.lineWidth = strokeWidth;
        ctx.lineJoin = 'round';
        ctx.miterLimit = 2;
        ctx.strokeText(line, x, y);
      }

      // Reset shadow for text fill so stroke gets the shadow
      ctx.shadowColor = 'transparent';

      // Text Fill
      if (isGradient) {
        const rad = (gradientAngle * Math.PI) / 180;
        const x1 = x - Math.cos(rad) * 200;
        const y1 = y - Math.sin(rad) * 100;
        const x2 = x + Math.cos(rad) * 200;
        const y2 = y + Math.sin(rad) * 100;
        const grad = ctx.createLinearGradient(x1, y1, x2, y2);
        grad.addColorStop(0, textColor);
        grad.addColorStop(1, gradientColor2);
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = textColor;
      }

      ctx.fillText(line, x, y);
    });
  };

  useEffect(() => {
    renderCanvas();
  }, [
    text,
    fontFamily,
    fontSize,
    textColor,
    isGradient,
    gradientColor2,
    gradientAngle,
    enableStroke,
    strokeColor,
    strokeWidth,
    enableShadow,
    shadowColor,
    shadowBlur,
    shadowOffsetY,
    canvasPreset,
    bgType,
    letterSpacing,
  ]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `ctools-text-${fontFamily.toLowerCase()}-${Date.now()}.png`;
    a.click();
    toast.success('Diunduh', 'Teks PNG transparan HD berhasil disimpan.');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Type className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Text to PNG Generator (Overlay & Motion Asset)</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Motion Graphic
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Buat stiker tipografi transparan resolusi tinggi dengan efek stroke tebal, shadow glow, dan gradasi warna untuk bahan overlay CapCut/Alight Motion.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls Sidebar */}
        <div className="lg:col-span-5 space-y-5 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          {/* Text Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Isi Teks (Mendukung Enter baris baru):
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              rows={3}
              className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-black text-sm uppercase focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Typography Controls */}
          <div className="space-y-3 pt-1">
            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">Font:</label>
                <select
                  value={fontFamily}
                  onChange={(e) => setFontFamily(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
                >
                  <option value="Impact">Impact (Viral JJ)</option>
                  <option value="Anton">Anton (Bold Clean)</option>
                  <option value="Arial Black">Arial Black</option>
                  <option value="Trebuchet MS">Trebuchet MS</option>
                  <option value="Courier New">Courier Monospace</option>
                  <option value="Georgia">Georgia Serif</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  Ukuran ({fontSize}px):
                </label>
                <input
                  type="range"
                  min={32}
                  max={140}
                  value={fontSize}
                  onChange={(e) => setFontSize(Number(e.target.value))}
                  className="w-full accent-blue-600"
                />
              </div>
            </div>

            {/* Colors & Gradient */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Warna Teks Fill</span>
                <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isGradient}
                    onChange={(e) => setIsGradient(e.target.checked)}
                    className="rounded-sm text-blue-600"
                  />
                  <span>Gradasi</span>
                </label>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={textColor}
                    onChange={(e) => setTextColor(e.target.value)}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                  />
                  <span className="text-xs font-mono">{textColor}</span>
                </div>

                {isGradient && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">→</span>
                    <input
                      type="color"
                      value={gradientColor2}
                      onChange={(e) => setGradientColor2(e.target.value)}
                      className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                    />
                    <span className="text-xs font-mono">{gradientColor2}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Stroke / Outline */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableStroke}
                    onChange={(e) => setEnableStroke(e.target.checked)}
                    className="rounded-sm text-blue-600"
                  />
                  <span>Outline / Stroke Tebal</span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={strokeColor}
                    onChange={(e) => setStrokeColor(e.target.value)}
                    className="w-6 h-6 rounded-md cursor-pointer border-0 bg-transparent"
                  />
                </div>
              </div>
              {enableStroke && (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-500">Ketebalan ({strokeWidth}px):</span>
                  <input
                    type="range"
                    min={2}
                    max={30}
                    value={strokeWidth}
                    onChange={(e) => setStrokeWidth(Number(e.target.value))}
                    className="flex-1 accent-blue-600"
                  />
                </div>
              )}
            </div>

            {/* Shadow & Glow */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2">
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableShadow}
                    onChange={(e) => setEnableShadow(e.target.checked)}
                    className="rounded-sm text-blue-600"
                  />
                  <span>Drop Shadow / Glow</span>
                </label>
                <input
                  type="color"
                  value={shadowColor}
                  onChange={(e) => setShadowColor(e.target.value)}
                  className="w-6 h-6 rounded-md cursor-pointer border-0 bg-transparent"
                />
              </div>
              {enableShadow && (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-slate-500">Glow Blur ({shadowBlur}px):</span>
                  <input
                    type="range"
                    min={0}
                    max={60}
                    value={shadowBlur}
                    onChange={(e) => setShadowBlur(Number(e.target.value))}
                    className="flex-1 accent-blue-600"
                  />
                </div>
              )}
            </div>

            {/* Canvas Preset & Background */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-500">Rasio Kanvas:</label>
                <select
                  value={canvasPreset}
                  onChange={(e: any) => setCanvasPreset(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
                >
                  <option value="9:16">9:16 (TikTok/Reels 1080x1920)</option>
                  <option value="16:9">16:9 (YouTube 1920x1080)</option>
                  <option value="1:1">1:1 (Square 1080x1080)</option>
                  <option value="fit">Compact Banner (1080x600)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-500">Latar Belakang:</label>
                <select
                  value={bgType}
                  onChange={(e: any) => setBgType(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
                >
                  <option value="transparent">Transparan (PNG Alpha)</option>
                  <option value="green">Green Screen (#00FF00)</option>
                  <option value="black">Hitam Pekat (#000000)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Download Button */}
          <button
            onClick={handleDownload}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download PNG HD Transparan</span>
          </button>
        </div>

        {/* Live Canvas Preview */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center shadow-xs">
          <div className="w-full flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-blue-500" />
              <span>Pratinjau Kanvas Real-Time</span>
            </span>
            <span className="text-[11px] font-mono text-slate-400">
              {canvasPreset === '9:16'
                ? '1080 x 1920 px'
                : canvasPreset === '16:9'
                ? '1920 x 1080 px'
                : '1080 x 1080 px'}
            </span>
          </div>

          <div
            className={`w-full max-h-[520px] rounded-xl overflow-hidden flex items-center justify-center p-4 ${
              bgType === 'transparent'
                ? 'bg-[linear-gradient(45deg,#f1f5f9_25%,transparent_25%),linear-gradient(-45deg,#f1f5f9_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#f1f5f9_75%),linear-gradient(-45deg,transparent_75%,#f1f5f9_75%)] bg-[size:20px_20px] dark:bg-[linear-gradient(45deg,#1e293b_25%,transparent_25%),linear-gradient(-45deg,#1e293b_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#1e293b_75%),linear-gradient(-45deg,transparent_75%,#1e293b_75%)]'
                : bgType === 'green'
                ? 'bg-[#00FF00]'
                : 'bg-black'
            } border border-slate-200 dark:border-slate-800 shadow-inner`}
          >
            <canvas
              ref={canvasRef}
              className="max-h-[480px] max-w-full object-contain rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
