export interface BPMDetectionResult {
  bpm: number;
  confidence: number;
  tempoType: 'Slow' | 'Moderate' | 'Fast' | 'JJ / High Energy';
  beatIntervalMs: number;
  sixteenthIntervalMs: number;
  peakCount: number;
}

export async function detectBPMFromAudioFile(file: File): Promise<BPMDetectionResult> {
  const arrayBuffer = await file.arrayBuffer();
  const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  
  try {
    const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
    const channelData = audioBuffer.getChannelData(0);
    const sampleRate = audioBuffer.sampleRate;

    // Filter low-frequencies (kick & bass beats between 40Hz and 160Hz)
    // Downsample for fast local computation
    const step = Math.floor(sampleRate / 22050) || 1;
    const downsampled: number[] = [];
    for (let i = 0; i < channelData.length; i += step) {
      downsampled.push(Math.abs(channelData[i]));
    }

    // Energy envelope calculation with moving window
    const windowSize = 1024;
    const energy: number[] = [];
    let currentEnergy = 0;

    for (let i = 0; i < downsampled.length; i++) {
      currentEnergy += downsampled[i];
      if (i >= windowSize) {
        currentEnergy -= downsampled[i - windowSize];
        energy.push(currentEnergy / windowSize);
      }
    }

    // Find local peaks
    let threshold = 0;
    for (let i = 0; i < energy.length; i++) {
      threshold += energy[i];
    }
    threshold = (threshold / energy.length) * 1.35;

    const peaks: number[] = [];
    const minDistance = Math.floor(22050 * 0.25); // min 250ms between peaks (max 240 BPM)

    for (let i = 1; i < energy.length - 1; i++) {
      if (
        energy[i] > threshold &&
        energy[i] > energy[i - 1] &&
        energy[i] > energy[i + 1]
      ) {
        if (peaks.length === 0 || i - peaks[peaks.length - 1] > minDistance) {
          peaks.push(i);
        }
      }
    }

    // Calculate intervals between peaks
    const intervals: { [key: number]: number } = {};
    for (let i = 1; i < peaks.length; i++) {
      const diff = peaks[i] - peaks[i - 1];
      // Convert diff to BPM (22050 effective sample rate)
      const rawBpm = Math.round((60 * 22050) / diff);

      // Normalize into realistic musical range (60 - 190 BPM)
      let normalizedBpm = rawBpm;
      while (normalizedBpm < 70) normalizedBpm *= 2;
      while (normalizedBpm > 185) normalizedBpm /= 2;
      normalizedBpm = Math.round(normalizedBpm);

      if (normalizedBpm >= 60 && normalizedBpm <= 200) {
        intervals[normalizedBpm] = (intervals[normalizedBpm] || 0) + 1;
      }
    }

    // Find most common BPM
    let bestBpm = 120;
    let maxVotes = 0;
    for (const [bpmStr, votes] of Object.entries(intervals)) {
      if (votes > maxVotes) {
        maxVotes = votes;
        bestBpm = Number(bpmStr);
      }
    }

    const confidence = Math.min(100, Math.max(30, Math.round((maxVotes / (peaks.length || 1)) * 140)));
    const beatIntervalMs = Math.round((60 / bestBpm) * 1000);
    const sixteenthIntervalMs = Math.round(beatIntervalMs / 4);

    let tempoType: 'Slow' | 'Moderate' | 'Fast' | 'JJ / High Energy' = 'Moderate';
    if (bestBpm < 90) tempoType = 'Slow';
    else if (bestBpm <= 125) tempoType = 'Moderate';
    else if (bestBpm <= 145) tempoType = 'Fast';
    else tempoType = 'JJ / High Energy';

    return {
      bpm: bestBpm,
      confidence,
      tempoType,
      beatIntervalMs,
      sixteenthIntervalMs,
      peakCount: peaks.length,
    };
  } finally {
    audioCtx.close();
  }
}
