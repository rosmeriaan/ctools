import React, { useState, useEffect, useRef } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { detectBPMFromAudioFile, BPMDetectionResult } from './bpmEngine';
import { toast } from '../../utils/toast';
import { Activity, Music2, Copy, Check, Sparkles, Play, Pause, Zap } from 'lucide-react';

export const BpmDetectorTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [result, setResult] = useState<BPMDetectionResult | null>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [beatPulse, setBeatPulse] = useState<boolean>(false);

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap mendeteksi BPM',
    step: 'idle',
  });

  const audioRef = useRef<HTMLAudioElement>(null);

  const handleFileSelect = async (selectedFile: File) => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setAudioUrl(url);
    setResult(null);

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });

    // Auto-detect BPM locally
    setProcessing({
      isProcessing: true,
      progress: 30,
      statusText: 'Menganalisis gelombang frekuensi audio Web Audio API...',
      step: 'processing',
    });

    try {
      const res = await detectBPMFromAudioFile(selectedFile);
      setResult(res);
      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: `BPM Terdeteksi: ${res.bpm} BPM!`,
        step: 'completed',
      });
      toast.success('BPM Ditemukan', `Musik berkecepatan ${res.bpm} BPM (${res.tempoType}).`);
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal menganalisis BPM',
        step: 'error',
        error: err?.message,
      });
      toast.error('Gagal', 'Tidak dapat menganalisis file audio.');
    }
  };

  // Beat visualizer pulse
  useEffect(() => {
    if (!result || !isPlaying) return;

    const interval = setInterval(() => {
      setBeatPulse(true);
      setTimeout(() => setBeatPulse(false), 120);
    }, result.beatIntervalMs);

    return () => clearInterval(interval);
  }, [result, isPlaying]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const copyKeyframeData = () => {
    if (!result) return;
    const data = JSON.stringify(
      {
        bpm: result.bpm,
        tempo: result.tempoType,
        beat_interval_ms: result.beatIntervalMs,
        sixteenth_interval_ms: result.sixteenthIntervalMs,
        fps_keyframe_at_60fps: Number((60 / (result.bpm / 60)).toFixed(2)),
        fps_keyframe_at_30fps: Number((30 / (result.bpm / 60)).toFixed(2)),
      },
      null,
      2
    );
    navigator.clipboard.writeText(data);
    setCopied(true);
    toast.success('Disalin', 'Data keyframe BPM berhasil disalin ke clipboard.');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    setFile(null);
    setFileMetadata(null);
    setAudioUrl('');
    setResult(null);
    setIsPlaying(false);
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Activity className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>BPM Detector (Tempo Finder)</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Web Audio DSP
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Deteksi ketukan lagu (Beats Per Minute) dan interval milidetik secara lokal untuk JJ Alight Motion & CapCut.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['audio/mpeg', 'audio/wav', 'audio/ogg', 'video/mp4', 'audio/mp4']}
          maxSizeMB={50}
          title="Pilih Lagu / Audio untuk Dideteksi BPM-nya"
          description="Mendukung MP3, WAV, OGG, M4A, MP4 (100% diproses di browser)"
          icon={<Activity className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <audio
                ref={audioRef}
                src={audioUrl}
                onEnded={() => setIsPlaying(false)}
                className="w-full"
                controls
              />

              <div className="flex justify-center py-4">
                <button
                  onClick={togglePlay}
                  className={`w-28 h-28 rounded-full border-4 flex flex-col items-center justify-center gap-1 transition-all cursor-pointer shadow-lg ${
                    beatPulse
                      ? 'scale-110 border-blue-400 bg-blue-600 text-white shadow-blue-500/40'
                      : 'border-blue-500/30 bg-blue-500/10 text-blue-600 hover:scale-105'
                  }`}
                >
                  {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                  <span className="text-[11px] font-extrabold uppercase tracking-wider">
                    {isPlaying ? 'Playing' : 'Sync Beat'}
                  </span>
                </button>
              </div>
              <p className="text-[11px] text-center text-slate-400">
                *Tombol akan berkedip (pulsing) otomatis mengikuti ritme BPM
              </p>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              {processing.isProcessing && (
                <ProgressBar progress={processing.progress} statusText={processing.statusText} />
              )}

              {result && (
                <div className="space-y-5">
                  {/* Hero BPM Display */}
                  <div className="p-6 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-between shadow-xl shadow-blue-600/20">
                    <div>
                      <span className="text-xs uppercase tracking-wider font-bold opacity-80">
                        Tempo Musik Terdeteksi
                      </span>
                      <div className="text-5xl font-black font-mono tracking-tight mt-1">
                        {result.bpm} <span className="text-xl font-normal opacity-90">BPM</span>
                      </div>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-xs font-bold backdrop-blur-xs">
                          {result.tempoType}
                        </span>
                        <span className="text-xs opacity-80">Akurasi ~{result.confidence}%</span>
                      </div>
                    </div>
                    <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center">
                      <Zap className={`w-8 h-8 ${beatPulse ? 'text-amber-300 scale-125' : 'text-white'} transition-all`} />
                    </div>
                  </div>

                  {/* JJ & Keyframe Intervals breakdown */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                      <span className="text-[11px] text-slate-500 block">1 Beat Interval</span>
                      <span className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200">
                        {result.beatIntervalMs} ms
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                      <span className="text-[11px] text-slate-500 block">1/4 Beat (1/16th)</span>
                      <span className="text-sm font-mono font-bold text-slate-800 dark:text-slate-200">
                        {result.sixteenthIntervalMs} ms
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60">
                      <span className="text-[11px] text-slate-500 block">Frame @ 60 FPS</span>
                      <span className="text-sm font-mono font-bold text-blue-600 dark:text-blue-400">
                        {(60 / (result.bpm / 60)).toFixed(1)} Frames
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={copyKeyframeData}
                    className="w-full py-3 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copied ? 'Berhasil Disalin ke Clipboard!' : 'Salin Data Keyframe JSON'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
