import React, { useState } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  FileCode,
  Upload,
  Download,
  Sliders,
  Sparkles,
  Eye,
  RefreshCw,
} from 'lucide-react';

const DEFAULT_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38BDF8" />
      <stop offset="100%" stop-color="#818CF8" />
    </linearGradient>
  </defs>
  <circle cx="50" cy="50" r="45" fill="url(#grad)" />
  <polygon points="40,30 70,50 40,70" fill="#FFFFFF" />
</svg>`;

export const SvgToPngTool: React.FC = () => {
  const [svgContent, setSvgContent] = useState<string>(DEFAULT_SVG);
  const [scale, setScale] = useState<number>(4);
  const [bgType, setBgType] = useState<'transparent' | 'white' | 'black' | 'green'>('transparent');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setSvgContent(text);
      toast.success('SVG Dimuat', `${file.name}`);
    };
    reader.readAsText(file);
  };

  const handleDownloadPng = () => {
    setIsProcessing(true);
    try {
      const svgBlob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
      const blobURL = URL.createObjectURL(svgBlob);

      const image = new Image();
      image.onload = () => {
        const width = (image.width || 500) * scale;
        const height = (image.height || 500) * scale;

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setIsProcessing(false);
          return;
        }

        if (bgType === 'white') {
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, width, height);
        } else if (bgType === 'black') {
          ctx.fillStyle = '#000000';
          ctx.fillRect(0, 0, width, height);
        } else if (bgType === 'green') {
          ctx.fillStyle = '#00FF00';
          ctx.fillRect(0, 0, width, height);
        }

        ctx.drawImage(image, 0, 0, width, height);
        URL.revokeObjectURL(blobURL);

        const a = document.createElement('a');
        a.href = canvas.toDataURL('image/png');
        a.download = `ctools-svg-render-${width}x${height}-${Date.now()}.png`;
        a.click();
        setIsProcessing(false);
        toast.success('Diunduh', `PNG beresolusi ${width}x${height}px berhasil diekspor.`);
      };

      image.onerror = () => {
        setIsProcessing(false);
        toast.error('Error Render', 'Kode SVG tidak valid atau mengandung tag eksternal yang diblokir.');
      };

      image.src = blobURL;
    } catch {
      setIsProcessing(false);
      toast.error('Gagal', 'Terjadi kesalahan saat memproses SVG.');
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <FileCode className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>SVG to PNG High-Res Rasterizer</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Vektor ke 4K
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Render vektor SVG menjadi gambar PNG beresolusi tinggi hingga 4096px (8x scale) dengan latar transparan.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Editor & Upload */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Kode Vektor SVG:
            </label>
            <label className="cursor-pointer px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 flex items-center gap-1">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Berkas .svg</span>
              <input type="file" accept=".svg,image/svg+xml" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          <textarea
            value={svgContent}
            onChange={(e) => setSvgContent(e.target.value)}
            rows={10}
            className="w-full font-mono text-xs p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            placeholder="<svg>...</svg>"
          />

          {/* Scale & Bg Options */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-500">Skala Perbesaran:</label>
              <select
                value={scale}
                onChange={(e) => setScale(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
              >
                <option value={1}>1x (Original Size)</option>
                <option value={2}>2x (Retina HD)</option>
                <option value={4}>4x (Ultra HD 1080p+)</option>
                <option value={8}>8x (Ultra 4K Raster)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-500">Latar Belakang:</label>
              <select
                value={bgType}
                onChange={(e: any) => setBgType(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-semibold"
              >
                <option value="transparent">Transparan (Alpha)</option>
                <option value="white">Putih Bersih (#FFF)</option>
                <option value="black">Hitam Pekat (#000)</option>
                <option value="green">Green Screen (#0F0)</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleDownloadPng}
            disabled={isProcessing}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-colors disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isProcessing ? 'Merender...' : `Download PNG (${scale}x Resolusi)`}</span>
          </button>
        </div>

        {/* Live SVG Preview Box */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center shadow-xs">
          <div className="w-full flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-blue-500" />
              <span>Pratinjau Vektor Langsung</span>
            </span>
          </div>

          <div
            className={`w-full h-80 rounded-2xl flex items-center justify-center p-6 ${
              bgType === 'transparent'
                ? 'bg-[linear-gradient(45deg,#f1f5f9_25%,transparent_25%),linear-gradient(-45deg,#f1f5f9_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#f1f5f9_75%),linear-gradient(-45deg,transparent_75%,#f1f5f9_75%)] bg-[size:20px_20px] dark:bg-[linear-gradient(45deg,#1e293b_25%,transparent_25%),linear-gradient(-45deg,#1e293b_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#1e293b_75%),linear-gradient(-45deg,transparent_75%,#1e293b_75%)]'
                : bgType === 'white'
                ? 'bg-white'
                : bgType === 'black'
                ? 'bg-black'
                : 'bg-[#00FF00]'
            } border border-slate-200 dark:border-slate-800 overflow-hidden shadow-inner`}
            dangerouslySetInnerHTML={{ __html: svgContent }}
          />
        </div>
      </div>
    </div>
  );
};
