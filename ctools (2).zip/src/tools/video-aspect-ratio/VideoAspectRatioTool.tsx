import React, { useState } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { Crop, Film, Download, Smartphone, Monitor, Square, Layers } from 'lucide-react';

interface RatioOption {
  id: string;
  name: string;
  w: number;
  h: number;
  label: string;
  icon: any;
}

const RATIOS: RatioOption[] = [
  { id: '9:16', name: '9:16 (TikTok / Reels / Shorts)', w: 1080, h: 1920, label: 'Vertical Story', icon: Smartphone },
  { id: '16:9', name: '16:9 (YouTube Landscape)', w: 1920, h: 1080, label: 'Landscape HD', icon: Monitor },
  { id: '1:1', name: '1:1 (Square Feed)', w: 1080, h: 1080, label: 'Kotak Persegi', icon: Square },
  { id: '4:5', name: '4:5 (Instagram Portrait)', w: 1080, h: 1350, label: 'Feed Portrait', icon: Smartphone },
  { id: '4:3', name: '4:3 (Classic TV)', w: 1440, h: 1080, label: 'Standard', icon: Monitor },
];

export const VideoAspectRatioTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [selectedRatio, setSelectedRatio] = useState<string>('9:16');
  const [fitMode, setFitMode] = useState<'fit' | 'crop'>('fit');
  const [bgColor, setBgColor] = useState<string>('black');

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap mengubah rasio video',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const handleFileSelect = (selectedFile: File) => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setVideoUrl(url);
    setOutputBlob(null);
    setOutputUrl('');

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleConvertRatio = async () => {
    if (!file) return;

    const ratioDef = RATIOS.find((r) => r.id === selectedRatio) || RATIOS[0];
    const { w, h } = ratioDef;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan engine FFmpeg...',
      step: 'preparing',
    });

    try {
      const inputExt = file.name.split('.').pop() || 'mp4';
      const inputName = `input.${inputExt}`;
      const outputName = 'aspect_converted.mp4';

      let vf = '';
      if (fitMode === 'fit') {
        // scale to fit inside w:h with padding
        vf = `scale=${w}:${h}:force_original_aspect_ratio=decrease,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=${bgColor}`;
      } else {
        // crop to fill
        vf = `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h}`;
      }

      const args = [
        '-i',
        inputName,
        '-vf',
        vf,
        '-c:v',
        'libx264',
        '-preset',
        'ultrafast',
        '-c:a',
        'copy',
        outputName,
      ];

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'video/mp4',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Mengubah rasio (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Rasio video berhasil diubah!',
        step: 'completed',
      });
      toast.success('Berhasil', `Rasio video berhasil diubah ke ${selectedRatio}.`);
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal mengubah rasio video.',
        step: 'error',
        error: err?.message || 'Error',
      });
      toast.error('Gagal', err?.message || 'Gagal mengubah rasio.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob || !file) return;
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    const cleanRatio = selectedRatio.replace(':', 'x');
    downloadBlob(outputBlob, `ctools-ratio-${cleanRatio}-${baseName}.mp4`);
  };

  const handleReset = () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setVideoUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Crop className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Aspect Ratio Converter</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              9:16 / 16:9 / 1:1 / 4:5
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Sesuaikan rasio aspek video untuk TikTok, Reels, YouTube, dan Instagram Feed.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['video/mp4', 'video/webm', 'video/quicktime']}
          maxSizeMB={150}
          title="Pilih Video untuk Diubah Rasionya"
          description="Mendukung MP4, WebM, MOV hingga 150 MB"
          icon={<Film className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center">
                <video src={videoUrl} controls className="w-full h-full object-contain" />
              </div>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Pilih Rasio Target:
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {RATIOS.map((r) => {
                  const Icon = r.icon;
                  const isSel = selectedRatio === r.id;
                  return (
                    <button
                      key={r.id}
                      onClick={() => setSelectedRatio(r.id)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center gap-3 ${
                        isSel
                          ? 'border-blue-600 bg-blue-600/10 text-blue-600 dark:text-blue-400 font-bold'
                          : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <Icon className="w-5 h-5 shrink-0" />
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold truncate">{r.id}</div>
                        <div className="text-[10px] text-slate-400 truncate">{r.label} ({r.w}x{r.h})</div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Mode: Fit (Padding) vs Crop */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Metode Penyesuaian:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setFitMode('fit')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold cursor-pointer ${
                      fitMode === 'fit'
                        ? 'border-blue-600 bg-blue-600/10 text-blue-600 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    Fit with Padding (Tanpa Crop)
                  </button>
                  <button
                    onClick={() => setFitMode('crop')}
                    className={`p-2.5 rounded-xl border text-xs font-semibold cursor-pointer ${
                      fitMode === 'crop'
                        ? 'border-blue-600 bg-blue-600/10 text-blue-600 font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    Crop to Fill (Penuh Layar)
                  </button>
                </div>
              </div>

              {fitMode === 'fit' && (
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Warna Background Padding:
                  </label>
                  <div className="flex gap-2">
                    {['black', 'white', '#1e293b', '#0f172a'].map((col) => (
                      <button
                        key={col}
                        onClick={() => setBgColor(col)}
                        style={{ backgroundColor: col }}
                        className={`w-7 h-7 rounded-lg border cursor-pointer ${
                          bgColor === col ? 'ring-2 ring-blue-500 scale-110' : 'border-slate-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputUrl ? (
                <div className="space-y-3">
                  <div className="rounded-xl overflow-hidden bg-black aspect-video">
                    <video src={outputUrl} controls className="w-full h-full object-contain" />
                  </div>
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Video ({formatFileSize(outputBlob?.size || 0)})</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleConvertRatio}
                  disabled={processing.isProcessing}
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                >
                  <Crop className="w-4 h-4" />
                  <span>{processing.isProcessing ? 'Memproses Video...' : `Ubah ke Rasio ${selectedRatio}`}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
