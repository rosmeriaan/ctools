import React, { useState, useRef } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { FileMetadata, ProcessingState } from '../../types';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';
import { FFmpegCommands } from '../../core/ffmpeg/commands';
import { Volume2, Volume1, VolumeX, Download, Music2 } from 'lucide-react';

export const AudioVolumeTool: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [fileMetadata, setFileMetadata] = useState<FileMetadata | null>(null);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [volume, setVolume] = useState<number>(1.5); // 150% boost by default

  const [processing, setProcessing] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: 'Siap mengatur volume',
    step: 'idle',
  });

  const [outputBlob, setOutputBlob] = useState<Blob | null>(null);
  const [outputUrl, setOutputUrl] = useState<string>('');

  const handleFileSelect = (selectedFile: File) => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);

    const url = URL.createObjectURL(selectedFile);
    setFile(selectedFile);
    setAudioUrl(url);
    setOutputBlob(null);
    setOutputUrl('');

    setFileMetadata({
      name: selectedFile.name,
      size: selectedFile.size,
      type: selectedFile.type,
      lastModified: selectedFile.lastModified,
    });
  };

  const handleProcessVolume = async () => {
    if (!file) return;

    setProcessing({
      isProcessing: true,
      progress: 0,
      statusText: 'Menyiapkan filter volume FFmpeg...',
      step: 'preparing',
    });

    try {
      const inputExt = file.name.split('.').pop() || 'mp3';
      const inputName = `input.${inputExt}`;
      const outputName = 'volume_adjusted.mp3';

      const args = FFmpegCommands.changeAudioVolume(inputName, outputName, volume);

      const blob = await runFFmpegProcess({
        inputs: [{ name: inputName, data: file }],
        outputName,
        outputMime: 'audio/mpeg',
        args,
        onProgress: (p) => {
          setProcessing((prev) => ({
            ...prev,
            progress: p,
            statusText: `Menyesuaikan volume ${Math.round(volume * 100)}% (${p}%)...`,
            step: 'processing',
          }));
        },
        onStatus: (st) => {
          setProcessing((prev) => ({ ...prev, statusText: st }));
        },
      });

      if (outputUrl) URL.revokeObjectURL(outputUrl);
      const resUrl = URL.createObjectURL(blob);
      setOutputBlob(blob);
      setOutputUrl(resUrl);

      setProcessing({
        isProcessing: false,
        progress: 100,
        statusText: 'Pengaturan volume selesai!',
        step: 'completed',
      });
      toast.success('Berhasil', `Volume berhasil diatur ke ${Math.round(volume * 100)}%.`);
    } catch (err: any) {
      console.error(err);
      setProcessing({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal mengatur volume.',
        step: 'error',
        error: err?.message,
      });
      toast.error('Gagal', err?.message || 'Gagal mengatur volume.');
    }
  };

  const handleDownload = () => {
    if (!outputBlob || !file) return;
    const baseName = file.name.replace(/\.[^/.]+$/, '');
    downloadBlob(outputBlob, `ctools-vol-${Math.round(volume * 100)}pct-${baseName}.mp3`);
  };

  const handleReset = () => {
    if (audioUrl) URL.revokeObjectURL(audioUrl);
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    setFile(null);
    setFileMetadata(null);
    setAudioUrl('');
    setOutputBlob(null);
    setOutputUrl('');
    setProcessing({
      isProcessing: false,
      progress: 0,
      statusText: 'Siap',
      step: 'idle',
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Volume2 className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>Audio Volume Booster & Changer</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              25% - 200% Gain
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Tingkatkan suara lagu yang terlalu kecil atau kurangi volume audio secara offline.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!file ? (
        <UploadBox
          onFileSelect={handleFileSelect}
          allowedTypes={['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/mp4']}
          maxSizeMB={80}
          title="Pilih File Audio untuk Diubah Volumenya"
          description="Mendukung MP3, WAV, OGG, M4A hingga 80 MB"
          icon={<Music2 className="w-10 h-10 text-blue-500" />}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <div className="p-5 rounded-xl bg-slate-50 dark:bg-slate-800/40">
                <p className="text-xs font-semibold text-slate-500 mb-2">Audio Asli:</p>
                <audio src={audioUrl} controls className="w-full" />
              </div>
            </div>

            {fileMetadata && <FileInfo metadata={fileMetadata} onClear={handleReset} />}
          </div>

          <div className="lg:col-span-6 space-y-4">
            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                <span>Pengaturan Gain Volume</span>
                <span className="font-mono text-blue-600 font-bold">{Math.round(volume * 100)}%</span>
              </h3>

              {/* Presets */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: '25% (Sangat Kecil)', val: 0.25 },
                  { label: '50% (Separuh)', val: 0.5 },
                  { label: '75%', val: 0.75 },
                  { label: '125% (Boost Sedikit)', val: 1.25 },
                  { label: '150% (Boost 1.5x)', val: 1.5 },
                  { label: '200% (Boost 2x)', val: 2.0 },
                ].map((item) => (
                  <button
                    key={item.val}
                    onClick={() => setVolume(item.val)}
                    className={`py-2 px-2 text-center text-xs font-semibold rounded-xl border transition-all cursor-pointer ${
                      volume === item.val
                        ? 'border-blue-600 bg-blue-600 text-white font-bold'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Slider */}
              <div className="space-y-1.5 pt-2">
                <input
                  type="range"
                  min="0.1"
                  max="2.5"
                  step="0.05"
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>10% (Pelan)</span>
                  <span>100% (Normal)</span>
                  <span>250% (Maksimal)</span>
                </div>
              </div>

              {processing.isProcessing && (
                <ProgressBar
                  progress={processing.progress}
                  statusText={processing.statusText}
                  isIndeterminate={processing.step === 'preparing'}
                />
              )}

              {outputUrl ? (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700">
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                      Hasil Audio ({Math.round(volume * 100)}%):
                    </p>
                    <audio src={outputUrl} controls className="w-full" />
                  </div>
                  <button
                    onClick={handleDownload}
                    className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download MP3 ({formatFileSize(outputBlob?.size || 0)})</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleProcessVolume}
                  disabled={processing.isProcessing}
                  className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{processing.isProcessing ? 'Memproses...' : `Ubah Volume ke ${Math.round(volume * 100)}%`}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
