import React, { useState, useRef, useEffect, useCallback } from 'react';
import { UploadBox } from '../../components/common/UploadBox';
import { FileInfo } from '../../components/common/FileInfo';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { defaultBgRemovalEngine } from './bgRemovalEngine';
import { FileMetadata, ProcessingState } from '../../types';
import { downloadBlob, revokeObjectURL } from '../../utils/file';
import { toast } from '../../utils/toast';
import {
  Download,
  RotateCcw,
  Sparkles,
  Pipette,
  Paintbrush,
  Sliders,
  Eye,
  Columns,
  Check,
  Undo2,
  ZoomIn,
  ZoomOut,
  Palette,
} from 'lucide-react';

export const BgEraserTool: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileMeta, setFileMeta] = useState<FileMetadata | null>(null);
  const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
  const [processedBlob, setProcessedBlob] = useState<Blob | null>(null);
  const [processedImageUrl, setProcessedImageUrl] = useState<string | null>(null);

  // Settings
  const [mode, setMode] = useState<'auto' | 'color-key' | 'manual'>('auto');
  const [tolerance, setTolerance] = useState<number>(32);
  const [feather, setFeather] = useState<number>(3);
  const [keyColor, setKeyColor] = useState<{ r: number; g: number; b: number }>({
    r: 255,
    g: 255,
    b: 255,
  });
  const [bgColorOption, setBgColorOption] = useState<string>('transparent'); // 'transparent', '#ffffff', '#000000', '#3b82f6', '#10b981'
  const [viewMode, setViewMode] = useState<'split' | 'side' | 'result'>('split');
  const [splitPos, setSplitPos] = useState<number>(50);

  // Manual brush tool state
  const [brushMode, setBrushMode] = useState<'erase' | 'restore'>('erase');
  const [brushSize, setBrushSize] = useState<number>(24);

  // Processing state
  const [procState, setProcState] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    statusText: '',
  });

  const originalImgRef = useRef<HTMLImageElement | null>(null);
  const manualCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawingRef = useRef<boolean>(false);

  // Cleanup on unmount or new file
  useEffect(() => {
    return () => {
      revokeObjectURL(originalImageUrl);
      revokeObjectURL(processedImageUrl);
    };
  }, [originalImageUrl, processedImageUrl]);

  const handleFileSelect = (file: File) => {
    revokeObjectURL(originalImageUrl);
    revokeObjectURL(processedImageUrl);
    setProcessedBlob(null);
    setProcessedImageUrl(null);

    const url = URL.createObjectURL(file);
    setOriginalImageUrl(url);
    setSelectedFile(file);

    // Read image dimensions
    const img = new Image();
    img.onload = () => {
      originalImgRef.current = img;
      setFileMeta({
        name: file.name,
        size: file.size,
        type: file.type,
        dimensions: { width: img.naturalWidth, height: img.naturalHeight },
      });
      // Auto run first pass
      runBackgroundRemoval(img, 'auto', tolerance, feather, keyColor);
    };
    img.src = url;
  };

  const runBackgroundRemoval = async (
    img: HTMLImageElement,
    currentMode = mode,
    currentTol = tolerance,
    currentFeather = feather,
    currentKeyColor = keyColor
  ) => {
    setProcState({
      isProcessing: true,
      progress: 5,
      statusText: 'Menganalisis gambar...',
    });

    try {
      const blob = await defaultBgRemovalEngine.process(
        img,
        {
          mode: currentMode,
          tolerance: currentTol,
          feather: currentFeather,
          keyColor: currentKeyColor,
        },
        (progress, step) => {
          setProcState({
            isProcessing: true,
            progress,
            statusText: step,
          });
        }
      );

      revokeObjectURL(processedImageUrl);
      const resUrl = URL.createObjectURL(blob);
      setProcessedBlob(blob);
      setProcessedImageUrl(resUrl);

      setProcState({
        isProcessing: false,
        progress: 100,
        statusText: 'Selesai!',
      });

      toast.success('Background Berhasil Dihapus', 'Hasil transparan siap diunduh');
    } catch (err: any) {
      console.error(err);
      setProcState({
        isProcessing: false,
        progress: 0,
        statusText: 'Gagal memproses gambar',
        error: err.message,
      });
      toast.error('Gagal Memproses', err.message || 'Terjadi kesalahan saat menghapus background');
    }
  };

  const handleApplyChanges = () => {
    if (originalImgRef.current) {
      runBackgroundRemoval(originalImgRef.current, mode, tolerance, feather, keyColor);
    }
  };

  // Color picker from canvas click
  const handleEyedropClick = (e: React.MouseEvent<HTMLImageElement>) => {
    if (mode !== 'color-key' || !originalImgRef.current) return;
    const target = e.currentTarget;
    const rect = target.getBoundingClientRect();
    const x = Math.floor(((e.clientX - rect.left) / rect.width) * originalImgRef.current.naturalWidth);
    const y = Math.floor(((e.clientY - rect.top) / rect.height) * originalImgRef.current.naturalHeight);

    const canvas = document.createElement('canvas');
    canvas.width = originalImgRef.current.naturalWidth;
    canvas.height = originalImgRef.current.naturalHeight;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(originalImgRef.current, 0, 0);
      const pixel = ctx.getImageData(x, y, 1, 1).data;
      const sampled = { r: pixel[0], g: pixel[1], b: pixel[2] };
      setKeyColor(sampled);
      toast.info('Warna Terpilih', `RGB(${sampled.r}, ${sampled.g}, ${sampled.b})`);
      runBackgroundRemoval(originalImgRef.current, 'color-key', tolerance, feather, sampled);
    }
  };

  const handleDownload = () => {
    if (!processedBlob && !processedImageUrl) return;

    if (bgColorOption === 'transparent' && processedBlob) {
      downloadBlob(processedBlob, 'ctools-bg-removed.png');
      return;
    }

    // If custom background color was selected, compose onto solid canvas
    if (processedImageUrl && originalImgRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = originalImgRef.current.naturalWidth;
      canvas.height = originalImgRef.current.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = bgColorOption;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        const img = new Image();
        img.onload = () => {
          ctx.drawImage(img, 0, 0);
          canvas.toBlob((blob) => {
            if (blob) downloadBlob(blob, 'ctools-bg-custom.png');
          }, 'image/png');
        };
        img.src = processedImageUrl;
      }
    }
  };

  const handleReset = () => {
    revokeObjectURL(originalImageUrl);
    revokeObjectURL(processedImageUrl);
    setSelectedFile(null);
    setFileMeta(null);
    setOriginalImageUrl(null);
    setProcessedBlob(null);
    setProcessedImageUrl(null);
    setProcState({ isProcessing: false, progress: 0, statusText: '' });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Top Banner / Privacy */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <span>Background Eraser</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
              Color Key & Auto Sampling
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Hapus background foto solid/green screen menjadi transparan PNG beresolusi penuh secara instan di browser.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {!selectedFile ? (
        <div className="space-y-4">
          <UploadBox
            onFileSelect={handleFileSelect}
            allowedTypes={['image/png', 'image/jpeg', 'image/jpg', 'image/webp']}
            maxSizeMB={25}
            title="Pilih atau Tarik Foto ke Sini"
            subtitle="Mendukung format PNG, JPG, JPEG, WEBP hingga 25 MB"
          />

          <div className="p-4 rounded-xl bg-slate-100/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <p>
              <strong>Tips:</strong> Anda juga dapat menempel gambar langsung dari clipboard dengan menekan <kbd className="px-1.5 py-0.5 rounded bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 font-mono text-[11px]">Ctrl+V</kbd>.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* File Meta & Action Buttons */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            {fileMeta && <FileInfo metadata={fileMeta} onClear={handleReset} className="flex-1" />}

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleReset}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Ganti Gambar</span>
              </button>

              <button
                onClick={handleDownload}
                disabled={!processedImageUrl || procState.isProcessing}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-md shadow-blue-600/20 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download PNG</span>
              </button>
            </div>
          </div>

          {/* Progress Bar when processing */}
          {procState.isProcessing && (
            <div className="p-4 rounded-xl bg-blue-500/5 dark:bg-blue-950/20 border border-blue-500/20">
              <ProgressBar
                progress={procState.progress}
                statusText={procState.statusText}
                subText="Memproses secara lokal di browser..."
              />
            </div>
          )}

          {/* Main Workspace Grid: Controls on Left, Preview Canvas on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Control Panel */}
            <div className="lg:col-span-1 space-y-4 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                <Sliders className="w-4 h-4 text-blue-500" />
                <span>Mode & Pengaturan</span>
              </h3>

              {/* Mode Selection Tabs */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Metode Penghapusan
                </label>
                <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
                  <button
                    onClick={() => {
                      setMode('auto');
                      if (originalImgRef.current) {
                        runBackgroundRemoval(originalImgRef.current, 'auto', tolerance, feather, keyColor);
                      }
                    }}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      mode === 'auto'
                        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Auto Magic</span>
                  </button>

                  <button
                    onClick={() => {
                      setMode('color-key');
                      if (originalImgRef.current) {
                        runBackgroundRemoval(originalImgRef.current, 'color-key', tolerance, feather, keyColor);
                      }
                    }}
                    className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      mode === 'color-key'
                        ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                    }`}
                  >
                    <Pipette className="w-3.5 h-3.5" />
                    <span>Color Key</span>
                  </button>
                </div>
              </div>

              {/* Color Key Eyedropper specific */}
              {mode === 'color-key' && (
                <div className="p-3 rounded-xl bg-blue-500/5 dark:bg-blue-950/20 border border-blue-500/20 space-y-2">
                  <span className="text-xs font-medium text-slate-700 dark:text-slate-300 block">
                    Warna Latar Target:
                  </span>
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-lg border border-slate-300 dark:border-slate-600 shadow-xs shrink-0"
                      style={{
                        backgroundColor: `rgb(${keyColor.r}, ${keyColor.g}, ${keyColor.b})`,
                      }}
                    />
                    <div className="flex-1 text-xs text-slate-500 dark:text-slate-400">
                      Klik pada gambar pratinjau asli untuk memilih warna latar.
                    </div>
                  </div>
                </div>
              )}

              {/* Tolerance Slider */}
              <div className="space-y-2 pt-2">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-700 dark:text-slate-300">Sensitivitas / Toleransi</span>
                  <span className="text-blue-600 dark:text-blue-400 tabular-nums">{tolerance}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="80"
                  value={tolerance}
                  onChange={(e) => setTolerance(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
                <p className="text-[11px] text-slate-400">
                  Naikkan nilai jika masih ada sisa background, turunkan jika objek utama ikut terhapus.
                </p>
              </div>

              {/* Edge Feathering Slider */}
              <div className="space-y-2 pt-1">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-slate-700 dark:text-slate-300">Kehalusan Tepi (Feather)</span>
                  <span className="text-blue-600 dark:text-blue-400 tabular-nums">{feather} px</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={feather}
                  onChange={(e) => setFeather(Number(e.target.value))}
                  className="w-full accent-blue-600 cursor-pointer"
                />
              </div>

              {/* Background Color Replacer */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <label className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5" />
                  <span>Ganti Warna Latar Belakang</span>
                </label>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setBgColorOption('transparent')}
                    className={`w-8 h-8 rounded-lg checkerboard-pattern border transition-all cursor-pointer ${
                      bgColorOption === 'transparent' ? 'ring-2 ring-blue-500 scale-110 border-blue-500' : 'border-slate-300 dark:border-slate-700'
                    }`}
                    title="Transparan"
                  />
                  <button
                    onClick={() => setBgColorOption('#ffffff')}
                    className={`w-8 h-8 rounded-lg bg-white border transition-all cursor-pointer ${
                      bgColorOption === '#ffffff' ? 'ring-2 ring-blue-500 scale-110 border-blue-500' : 'border-slate-300 dark:border-slate-700'
                    }`}
                    title="Putih Bersih"
                  />
                  <button
                    onClick={() => setBgColorOption('#0f172a')}
                    className={`w-8 h-8 rounded-lg bg-[#0f172a] border transition-all cursor-pointer ${
                      bgColorOption === '#0f172a' ? 'ring-2 ring-blue-500 scale-110 border-blue-500' : 'border-slate-300 dark:border-slate-700'
                    }`}
                    title="Hitam Elegan"
                  />
                  <button
                    onClick={() => setBgColorOption('#3b82f6')}
                    className={`w-8 h-8 rounded-lg bg-blue-500 border transition-all cursor-pointer ${
                      bgColorOption === '#3b82f6' ? 'ring-2 ring-blue-500 scale-110 border-blue-500' : 'border-slate-300 dark:border-slate-700'
                    }`}
                    title="Biru Studio"
                  />
                  <button
                    onClick={() => setBgColorOption('#10b981')}
                    className={`w-8 h-8 rounded-lg bg-emerald-500 border transition-all cursor-pointer ${
                      bgColorOption === '#10b981' ? 'ring-2 ring-blue-500 scale-110 border-blue-500' : 'border-slate-300 dark:border-slate-700'
                    }`}
                    title="Hijau Soft"
                  />
                </div>
              </div>

              {/* Apply Button */}
              <button
                onClick={handleApplyChanges}
                disabled={procState.isProcessing}
                className="w-full py-2.5 rounded-xl bg-slate-900 dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-700 text-white font-semibold text-xs sm:text-sm transition-colors cursor-pointer mt-3"
              >
                Terapkan Ulang
              </button>
            </div>

            {/* Preview Stage */}
            <div className="lg:col-span-2 space-y-3 flex flex-col">
              {/* View Toggle Bar */}
              <div className="flex items-center justify-between gap-2 p-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 text-xs">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setViewMode('split')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                      viewMode === 'split'
                        ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Columns className="w-3.5 h-3.5" />
                    <span>Split Slider</span>
                  </button>

                  <button
                    onClick={() => setViewMode('side')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
                      viewMode === 'side'
                        ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 font-bold'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Side-by-Side</span>
                  </button>
                </div>

                <div className="text-[11px] text-slate-400 hidden sm:block">
                  {bgColorOption === 'transparent' ? 'Transparan (PNG)' : `Warna: ${bgColorOption}`}
                </div>
              </div>

              {/* Visual Canvas View */}
              <div className="relative min-h-[380px] sm:min-h-[460px] flex-1 bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex items-center justify-center p-4">
                {viewMode === 'split' && originalImageUrl && processedImageUrl ? (
                  <div className="relative w-full h-full max-h-[500px] flex items-center justify-center select-none overflow-hidden rounded-xl">
                    {/* Background checkerboard or solid color container */}
                    <div
                      className={`absolute inset-0 flex items-center justify-center ${
                        bgColorOption === 'transparent' ? 'checkerboard-pattern' : ''
                      }`}
                      style={{
                        backgroundColor: bgColorOption !== 'transparent' ? bgColorOption : undefined,
                      }}
                    >
                      {/* Processed image (bottom layer) */}
                      <img
                        src={processedImageUrl}
                        alt="Hasil Background Dihapus"
                        className="max-h-[480px] w-auto max-w-full object-contain mx-auto"
                      />
                    </div>

                    {/* Original image with clip path (top layer) */}
                    <div
                      className="absolute inset-0 flex items-center justify-center pointer-events-none"
                      style={{
                        clipPath: `polygon(0 0, ${splitPos}% 0, ${splitPos}% 100%, 0 100%)`,
                      }}
                    >
                      <img
                        src={originalImageUrl}
                        alt="Gambar Asli"
                        className="max-h-[480px] w-auto max-w-full object-contain mx-auto"
                      />
                    </div>

                    {/* Split line divider */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-white shadow-xl pointer-events-none z-10"
                      style={{ left: `${splitPos}%` }}
                    >
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-white text-slate-800 shadow-lg flex items-center justify-center text-[10px] font-bold border border-slate-300">
                        ⇆
                      </div>
                    </div>

                    {/* Drag slider input */}
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={splitPos}
                      onChange={(e) => setSplitPos(Number(e.target.value))}
                      className="absolute inset-0 opacity-0 cursor-ew-resize z-20 w-full h-full"
                    />

                    {/* Badges */}
                    <div className="absolute top-3 left-3 z-10 px-2.5 py-1 rounded-md bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold uppercase tracking-wider">
                      Asli
                    </div>
                    <div className="absolute top-3 right-3 z-10 px-2.5 py-1 rounded-md bg-blue-600/80 backdrop-blur-xs text-white text-[10px] font-bold uppercase tracking-wider">
                      Hasil Bersih
                    </div>
                  </div>
                ) : (
                  /* Side-by-side mode */
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full h-full">
                    <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-center">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                        Gambar Asli {mode === 'color-key' ? '(Klik untuk Pick Warna)' : ''}
                      </span>
                      {originalImageUrl && (
                        <img
                          src={originalImageUrl}
                          alt="Asli"
                          onClick={handleEyedropClick}
                          className={`max-h-[300px] w-auto max-w-full object-contain rounded-lg ${
                            mode === 'color-key' ? 'cursor-crosshair' : ''
                          }`}
                        />
                      )}
                    </div>

                    <div
                      className={`flex flex-col items-center justify-center p-3 rounded-xl border border-slate-800 text-center ${
                        bgColorOption === 'transparent' ? 'checkerboard-pattern' : ''
                      }`}
                      style={{
                        backgroundColor: bgColorOption !== 'transparent' ? bgColorOption : undefined,
                      }}
                    >
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 bg-slate-900/80 px-2 py-0.5 rounded">
                        Hasil Transparan
                      </span>
                      {processedImageUrl && (
                        <img
                          src={processedImageUrl}
                          alt="Hasil Transparan"
                          className="max-h-[300px] w-auto max-w-full object-contain rounded-lg"
                        />
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
