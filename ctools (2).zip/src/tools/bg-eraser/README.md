# Background Eraser Tool

Hapus latar belakang foto atau gambar menjadi transparan PNG beresolusi penuh secara instan di peramban web.

## Fitur
- Auto Magic removal: Segmentasi warna dan tepian cerdas.
- Color Key: Eyedropper untuk menghapus warna tertentu dengan toleransi & feathering.
- Ganti warna background: Transparan (PNG), Putih, Hitam, Biru Studio, Emerald.
- Split comparison slider untuk membandingkan foto asli dengan hasil transparan.
- 100% Client-Side Canvas 2D processing.

## File Terkait
- `BgEraserTool.tsx`: Antarmuka pengguna dan state management.
- `bgRemovalEngine.ts`: Provider abstraction layer dan engine segmentasi lokal.
