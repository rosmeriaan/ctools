import React, { useState, useEffect } from 'react';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { toast } from '../../utils/toast';
import {
  Link2,
  Plus,
  Trash2,
  Copy,
  Check,
  ExternalLink,
  RefreshCw,
  Sparkles,
  Share2,
  Sliders,
  Code,
  Layers,
} from 'lucide-react';

interface ParamRow {
  id: string;
  key: string;
  value: string;
  enabled: boolean;
}

export const UrlParamsTool: React.FC = () => {
  const [rawUrl, setRawUrl] = useState<string>(() => {
    return window.location.href || 'https://ctools.app/tools/video-cutter?preset=reels&fps=60&mute=true';
  });

  const [baseUrl, setBaseUrl] = useState<string>('https://ctools.app/tools/video-cutter');
  const [paramsList, setParamsList] = useState<ParamRow[]>([
    { id: '1', key: 'preset', value: 'reels', enabled: true },
    { id: '2', key: 'fps', value: '60', enabled: true },
    { id: '3', key: 'mute', value: 'true', enabled: true },
  ]);

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [encodeInput, setEncodeInput] = useState<string>('teks dengan spasi & simbol #?/@');
  const [decodeInput, setDecodeInput] = useState<string>('teks%20dengan%20spasi%20%26%20simbol%20%23%3F%2F%40');

  // UTM builder states
  const [utmUrl, setUtmUrl] = useState<string>('https://example.com/my-video');
  const [utmSource, setUtmSource] = useState<string>('tiktok');
  const [utmMedium, setUtmMedium] = useState<string>('bio_link');
  const [utmCampaign, setUtmCampaign] = useState<string>('jj_tutorial_2026');

  // Parse raw URL when user inputs full URL
  const handleParseRawUrl = (urlToParse: string) => {
    try {
      const parsed = new URL(urlToParse);
      setBaseUrl(`${parsed.origin}${parsed.pathname}`);
      const newParams: ParamRow[] = [];
      parsed.searchParams.forEach((val, k) => {
        newParams.push({
          id: `${Date.now()}-${Math.random()}`,
          key: k,
          value: val,
          enabled: true,
        });
      });
      setParamsList(newParams.length > 0 ? newParams : [{ id: '1', key: '', value: '', enabled: true }]);
    } catch {
      // If incomplete URL, fallback
      const qIndex = urlToParse.indexOf('?');
      if (qIndex !== -1) {
        setBaseUrl(urlToParse.slice(0, qIndex));
        const qs = new URLSearchParams(urlToParse.slice(qIndex));
        const newParams: ParamRow[] = [];
        qs.forEach((val, k) => {
          newParams.push({
            id: `${Date.now()}-${Math.random()}`,
            key: k,
            value: val,
            enabled: true,
          });
        });
        setParamsList(newParams);
      } else {
        setBaseUrl(urlToParse);
      }
    }
  };

  // Reconstruct full URL from baseUrl + paramsList
  const buildCurrentUrl = (): string => {
    try {
      const url = new URL(baseUrl.startsWith('http') ? baseUrl : `https://${baseUrl}`);
      url.search = '';
      paramsList
        .filter((p) => p.enabled && p.key.trim() !== '')
        .forEach((p) => {
          url.searchParams.append(p.key.trim(), p.value);
        });
      return url.toString();
    } catch {
      const qs = paramsList
        .filter((p) => p.enabled && p.key.trim() !== '')
        .map((p) => `${encodeURIComponent(p.key.trim())}=${encodeURIComponent(p.value)}`)
        .join('&');
      return qs ? `${baseUrl}?${qs}` : baseUrl;
    }
  };

  const currentRebuiltUrl = buildCurrentUrl();

  const handleAddParam = () => {
    setParamsList((prev) => [
      ...prev,
      { id: `${Date.now()}-${Math.random()}`, key: '', value: '', enabled: true },
    ]);
  };

  const handleUpdateParam = (id: string, field: 'key' | 'value' | 'enabled', val: any) => {
    setParamsList((prev) =>
      prev.map((p) => (p.id === id ? { ...p, [field]: val } : p))
    );
  };

  const handleDeleteParam = (id: string) => {
    setParamsList((prev) => prev.filter((p) => p.id !== id));
  };

  const copyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    toast.success('Disalin', `Teks berhasil disalin ke clipboard.`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // UTM Reconstructed
  const buildUtmUrl = (): string => {
    try {
      const u = new URL(utmUrl.startsWith('http') ? utmUrl : `https://${utmUrl}`);
      if (utmSource) u.searchParams.set('utm_source', utmSource);
      if (utmMedium) u.searchParams.set('utm_medium', utmMedium);
      if (utmCampaign) u.searchParams.set('utm_campaign', utmCampaign);
      return u.toString();
    } catch {
      return `${utmUrl}?utm_source=${utmSource}&utm_medium=${utmMedium}&utm_campaign=${utmCampaign}`;
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 flex items-center gap-2.5">
            <Link2 className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            <span>URL Parameters & Query Builder</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
              Inspector & UTM
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Uraikan, edit, tambah, dan buat parameter query URL, encode/decode komponen string, dan buat tautan campaign marketing secara instan.
          </p>
        </div>
        <PrivacyBadge compact />
      </div>

      {/* URL Input & Quick Parser */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
        <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
          <span>Masukkan URL Lengkap untuk Diuraikan:</span>
          <button
            onClick={() => {
              setRawUrl(window.location.href);
              handleParseRawUrl(window.location.href);
            }}
            className="text-blue-600 dark:text-blue-400 hover:underline font-semibold flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Gunakan URL Halaman Saat Ini</span>
          </button>
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={rawUrl}
            onChange={(e) => {
              setRawUrl(e.target.value);
              handleParseRawUrl(e.target.value);
            }}
            placeholder="https://example.com/page?key1=val1&key2=val2"
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono text-xs sm:text-sm focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={() => handleParseRawUrl(rawUrl)}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
          >
            Uraikan
          </button>
        </div>
      </div>

      {/* Interactive Key-Value Query Editor */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-500" />
            <span>Daftar Parameter Query (Key - Value)</span>
          </h3>
          <button
            onClick={handleAddParam}
            className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-blue-600 dark:text-blue-400 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Parameter</span>
          </button>
        </div>

        {/* Base URL */}
        <div className="space-y-1">
          <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
            Base Endpoint / Domain & Path:
          </label>
          <input
            type="text"
            value={baseUrl}
            onChange={(e) => setBaseUrl(e.target.value)}
            className="w-full px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono text-xs focus:outline-hidden focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Table Rows */}
        <div className="space-y-2.5 pt-2">
          {paramsList.map((param, index) => (
            <div
              key={param.id}
              className={`flex items-center gap-2 p-2 rounded-xl border transition-colors ${
                param.enabled
                  ? 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'
                  : 'bg-slate-100/40 dark:bg-slate-900/40 border-dashed border-slate-200 dark:border-slate-800 opacity-60'
              }`}
            >
              <input
                type="checkbox"
                checked={param.enabled}
                onChange={(e) => handleUpdateParam(param.id, 'enabled', e.target.checked)}
                className="w-4 h-4 rounded-md text-blue-600 focus:ring-blue-500 cursor-pointer"
                title="Aktifkan / Nonaktifkan parameter ini"
              />
              <span className="text-xs font-mono font-bold text-slate-400 w-5 text-center">
                {index + 1}
              </span>
              <input
                type="text"
                value={param.key}
                onChange={(e) => handleUpdateParam(param.id, 'key', e.target.value)}
                placeholder="Key (misal: search, fps, id)"
                className="flex-1 px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
              />
              <span className="text-slate-400 font-bold">=</span>
              <input
                type="text"
                value={param.value}
                onChange={(e) => handleUpdateParam(param.id, 'value', e.target.value)}
                placeholder="Value (misal: 60, true, jakarta)"
                className="flex-1 px-3 py-1.5 text-xs font-mono rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100"
              />
              <button
                onClick={() => handleDeleteParam(param.id)}
                className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors"
                title="Hapus parameter"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* Live Rebuilt URL Output */}
        <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Hasil URL Terkini (Rebuilt URL):
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => copyText(currentRebuiltUrl, 'rebuilt')}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-xs"
              >
                {copiedKey === 'rebuilt' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Salin URL</span>
              </button>
            </div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-900 text-blue-400 font-mono text-xs break-all border border-slate-800 shadow-inner">
            {currentRebuiltUrl}
          </div>
        </div>
      </div>

      {/* UTM Campaign Link Builder */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Share2 className="w-4 h-4 text-emerald-500" />
          <span>UTM Campaign Link Builder (TikTok / IG / YT Tracker)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Target URL Website / Linktree:
            </label>
            <input
              type="text"
              value={utmUrl}
              onChange={(e) => setUtmUrl(e.target.value)}
              className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Campaign Source (utm_source):
            </label>
            <input
              type="text"
              value={utmSource}
              onChange={(e) => setUtmSource(e.target.value)}
              placeholder="tiktok, instagram, youtube"
              className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Campaign Medium (utm_medium):
            </label>
            <input
              type="text"
              value={utmMedium}
              onChange={(e) => setUtmMedium(e.target.value)}
              placeholder="bio_link, story, video_desc"
              className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Campaign Name (utm_campaign):
            </label>
            <input
              type="text"
              value={utmCampaign}
              onChange={(e) => setUtmCampaign(e.target.value)}
              placeholder="preset_jj_maret, promo_editor"
              className="w-full px-3 py-2 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
            />
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-emerald-500/5 dark:bg-emerald-950/20 border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="font-mono text-xs text-emerald-800 dark:text-emerald-300 break-all font-semibold">
            {buildUtmUrl()}
          </div>
          <button
            onClick={() => copyText(buildUtmUrl(), 'utm')}
            className="shrink-0 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg flex items-center gap-1 shadow-xs"
          >
            {copiedKey === 'utm' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>Salin UTM Link</span>
          </button>
        </div>
      </div>

      {/* URL Encode & Decode Fast Box */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Encoder */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
          <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
            <Code className="w-4 h-4 text-blue-500" />
            <span>URL Component Encoder</span>
          </h3>
          <textarea
            value={encodeInput}
            onChange={(e) => setEncodeInput(e.target.value)}
            rows={3}
            placeholder="Teks biasa..."
            className="w-full p-2.5 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
          />
          <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-mono text-xs break-all text-blue-600 dark:text-blue-400 flex items-center justify-between gap-2">
            <span>{encodeURIComponent(encodeInput)}</span>
            <button
              onClick={() => copyText(encodeURIComponent(encodeInput), 'enc')}
              className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 shrink-0"
              title="Salin hasil encode"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Decoder */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
          <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
            <Code className="w-4 h-4 text-indigo-500" />
            <span>URL Component Decoder</span>
          </h3>
          <textarea
            value={decodeInput}
            onChange={(e) => setDecodeInput(e.target.value)}
            rows={3}
            placeholder="Teks ter-encode (%20 dll)..."
            className="w-full p-2.5 text-xs font-mono rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
          />
          <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-mono text-xs break-all text-indigo-600 dark:text-indigo-400 flex items-center justify-between gap-2">
            <span>{(() => {
              try {
                return decodeURIComponent(decodeInput);
              } catch {
                return 'Format encoding tidak valid';
              }
            })()}</span>
            <button
              onClick={() => {
                try {
                  copyText(decodeURIComponent(decodeInput), 'dec');
                } catch {
                  toast.error('Gagal', 'Format decoding tidak valid');
                }
              }}
              className="p-1 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-500 shrink-0"
              title="Salin hasil decode"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
