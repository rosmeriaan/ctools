import { SpectrumConfig } from './types';
import { VisualizationEngine } from './visualizationEngine';
import { runFFmpegProcess } from '../../core/ffmpeg/processor';

export interface RenderProgress {
  progress: number; // 0 to 100
  currentFrame: number;
  totalFrames: number;
  statusText: string;
}

export class FrameByFrameVideoRenderer {
  private isAborted = false;

  abort(): void {
    this.isAborted = true;
  }

  /**
   * Renders the full audio from start to finish at 1920x1080 @ 30fps into a synchronized MP4 file
   */
  async renderToMp4(
    audioBuffer: AudioBuffer,
    audioFile: File | null,
    config: SpectrumConfig,
    bgImage: HTMLImageElement | null,
    coverImage: HTMLImageElement | null,
    onProgress: (p: RenderProgress) => void
  ): Promise<Blob> {
    this.isAborted = false;
    const fps = 30;
    const width = 1920;
    const height = 1080;
    const duration = audioBuffer.duration;
    const totalFrames = Math.max(1, Math.ceil(duration * fps));

    onProgress({
      progress: 0,
      currentFrame: 0,
      totalFrames,
      statusText: 'Mempersiapkan render frame 1080p...',
    });

    // 1. Create Offscreen Canvas for 1080p Rendering
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Gagal membuat Canvas rendering context');

    const engine = new VisualizationEngine();

    // 2. Pre-extract channel data
    const pcmData = audioBuffer.getChannelData(0);
    const sampleRate = audioBuffer.sampleRate;
    const samplesPerFrame = sampleRate / fps;
    const fftSize = 512;

    // 3. Setup MediaRecorder with Canvas Stream and Web Audio Destination
    const stream = canvas.captureStream(fps);
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const dest = audioCtx.createMediaStreamDestination();

    // Create audio source from buffer
    const bufferSource = audioCtx.createBufferSource();
    bufferSource.buffer = audioBuffer;
    bufferSource.connect(dest);

    // Combine video tracks and audio tracks
    const combinedStream = new MediaStream([
      ...stream.getVideoTracks(),
      ...dest.stream.getAudioTracks(),
    ]);

    // Check supported MIME types for recording
    let mimeType = 'video/webm;codecs=vp9,opus';
    if (MediaRecorder.isTypeSupported('video/mp4')) {
      mimeType = 'video/mp4';
    } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')) {
      mimeType = 'video/webm;codecs=vp8,opus';
    } else if (MediaRecorder.isTypeSupported('video/webm')) {
      mimeType = 'video/webm';
    }

    const recordedChunks: Blob[] = [];
    const mediaRecorder = new MediaRecorder(combinedStream, {
      mimeType,
      videoBitsPerSecond: 8_000_000, // 8 Mbps High Quality Full HD
      audioBitsPerSecond: 192_000, // 192 kbps audio
    });

    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    // 4. Start recording and render frame by frame
    mediaRecorder.start(100);
    bufferSource.start(0);

    const startTime = Date.now();

    for (let frame = 0; frame < totalFrames; frame++) {
      if (this.isAborted) {
        bufferSource.stop();
        mediaRecorder.stop();
        audioCtx.close();
        throw new Error('Proses render dibatalkan oleh pengguna.');
      }

      const currentTime = frame / fps;
      const centerSample = Math.floor(frame * samplesPerFrame);

      // Extract windowed audio slice and compute FFT
      const { freqData, timeData } = this.computeFftForWindow(
        pcmData,
        centerSample,
        fftSize
      );

      // Render frame onto 1920x1080 canvas
      engine.renderFrame(
        ctx,
        width,
        height,
        freqData,
        timeData,
        config,
        currentTime,
        duration,
        bgImage,
        coverImage
      );

      // Report progress
      if (frame % 15 === 0 || frame === totalFrames - 1) {
        const pct = Math.min(85, Math.round((frame / totalFrames) * 85));
        const elapsedSec = (Date.now() - startTime) / 1000;
        const fpsRate = frame > 0 ? (frame / elapsedSec).toFixed(1) : '30';
        onProgress({
          progress: pct,
          currentFrame: frame + 1,
          totalFrames,
          statusText: `Merender frame ${frame + 1}/${totalFrames} (${fpsRate} FPS)...`,
        });
      }

      // Small pause to yield control and keep stream smooth
      if (frame % 30 === 0) {
        await new Promise((r) => setTimeout(r, 4));
      }
    }

    // Wait a brief moment for recorder to capture last frame
    await new Promise((r) => setTimeout(r, 100));

    // Finish recording
    bufferSource.stop();
    mediaRecorder.stop();
    await audioCtx.close();

    // Wait for recorded blob
    const recordedBlob = await new Promise<Blob>((resolve) => {
      mediaRecorder.onstop = () => {
        resolve(new Blob(recordedChunks, { type: mimeType }));
      };
    });

    // 5. Final Step: If output is not standard MP4 or needs remuxing, use FFmpeg WASM
    onProgress({
      progress: 90,
      currentFrame: totalFrames,
      totalFrames,
      statusText: 'Memvalidasi & memaketkan video MP4 H.264/AAC...',
    });

    try {
      // Use FFmpeg to ensure 100% compliant .mp4 container
      const mp4Blob = await runFFmpegProcess({
        inputs: [{ name: 'input_video.webm', data: recordedBlob }],
        outputName: 'spectrum_output.mp4',
        outputMime: 'video/mp4',
        args: [
          '-i',
          'input_video.webm',
          '-c:v',
          'copy',
          '-c:a',
          'aac',
          '-b:a',
          '192k',
          '-movflags',
          '+faststart',
          'spectrum_output.mp4',
        ],
        onProgress: (p) => {
          onProgress({
            progress: 90 + Math.round(p * 0.1),
            currentFrame: totalFrames,
            totalFrames,
            statusText: `Muxing MP4 (${p}%)...`,
          });
        },
      });

      onProgress({
        progress: 100,
        currentFrame: totalFrames,
        totalFrames,
        statusText: 'Selesai! Video MP4 siap diunduh.',
      });

      return mp4Blob;
    } catch (ffmpegErr) {
      console.warn('FFmpeg remux fallback, returning direct recorded video:', ffmpegErr);
      // Fallback: If FFmpeg fails, return the high quality recorded blob directly
      onProgress({
        progress: 100,
        currentFrame: totalFrames,
        totalFrames,
        statusText: 'Selesai! Video siap diunduh.',
      });
      return recordedBlob;
    }
  }

  /**
   * Fast In-Place FFT + Hanning Windowing for frame-by-frame analysis
   */
  private computeFftForWindow(
    pcm: Float32Array,
    centerSample: number,
    fftSize: number
  ): { freqData: Uint8Array; timeData: Uint8Array } {
    const halfFft = fftSize / 2;
    const real = new Float32Array(fftSize);
    const imag = new Float32Array(fftSize);
    const timeData = new Uint8Array(fftSize);

    const startIdx = centerSample - halfFft;

    // Apply Hanning Window and extract samples
    for (let i = 0; i < fftSize; i++) {
      const pcmIdx = startIdx + i;
      const sample = pcmIdx >= 0 && pcmIdx < pcm.length ? pcm[pcmIdx] : 0;

      // Hanning window function: 0.5 * (1 - cos(2*pi*n/(N-1)))
      const hanning = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (fftSize - 1)));
      real[i] = sample * hanning;
      imag[i] = 0;

      // Time domain mapped to 0..255
      timeData[i] = Math.max(0, Math.min(255, Math.floor((sample + 1) * 127.5)));
    }

    // Perform Cooley-Tukey Radix-2 FFT
    this.fft(real, imag);

    // Compute magnitude and map to byte frequencies (0..255)
    const freqData = new Uint8Array(halfFft);
    for (let i = 0; i < halfFft; i++) {
      const mag = Math.sqrt(real[i] * real[i] + imag[i] * imag[i]) * 4;
      // Convert to dB scale / logarithmic brightness
      const val = Math.min(255, Math.max(0, Math.floor(mag * 255)));
      freqData[i] = val;
    }

    return { freqData, timeData };
  }

  /**
   * Cooley-Tukey in-place Fast Fourier Transform
   */
  private fft(real: Float32Array, imag: Float32Array): void {
    const n = real.length;
    let j = 0;

    // Bit-reversal permutation
    for (let i = 0; i < n - 1; i++) {
      if (i < j) {
        const tempR = real[i];
        real[i] = real[j];
        real[j] = tempR;

        const tempI = imag[i];
        imag[i] = imag[j];
        imag[j] = tempI;
      }
      let k = n >> 1;
      while (k <= j) {
        j -= k;
        k >>= 1;
      }
      j += k;
    }

    // Danielson-Lanczos section
    for (let len = 2; len <= n; len <<= 1) {
      const halfLen = len >> 1;
      const angle = (-2 * Math.PI) / len;
      const wStepR = Math.cos(angle);
      const wStepI = Math.sin(angle);

      for (let i = 0; i < n; i += len) {
        let wR = 1;
        let wI = 0;

        for (let k = 0; k < halfLen; k++) {
          const pos = i + k;
          const match = pos + halfLen;

          const tr = wR * real[match] - wI * imag[match];
          const ti = wR * imag[match] + wI * real[match];

          real[match] = real[pos] - tr;
          imag[match] = imag[pos] - ti;
          real[pos] += tr;
          imag[pos] += ti;

          const nextWR = wR * wStepR - wI * wStepI;
          wI = wR * wStepI + wI * wStepR;
          wR = nextWR;
        }
      }
    }
  }
}
