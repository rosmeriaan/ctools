import { SpectrumConfig } from './types';

export class VisualizationEngine {
  private peakValues: number[] = [];
  private rotationAngle = 0;
  private particles: Array<{
    x: number;
    y: number;
    vx: number;
    vy: number;
    size: number;
    color: string;
    alpha: number;
    life: number;
  }> = [];

  /**
   * Main rendering method that draws a single frame onto a canvas context
   */
  renderFrame(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    freqData: Uint8Array,
    timeData: Uint8Array,
    config: SpectrumConfig,
    currentTime: number,
    duration: number,
    bgImage: HTMLImageElement | null,
    coverImage: HTMLImageElement | null
  ): void {
    // 1. Clear canvas
    ctx.clearRect(0, 0, width, height);

    // 2. Render Background
    this.renderBackground(ctx, width, height, config, bgImage, freqData);

    // 3. Compute Bass Energy for Pulsing & Visual Dynamics
    const bassEnergy = this.computeBassEnergy(freqData);

    // 4. Render Spectrum according to Selected Style
    switch (config.style) {
      case 'bars':
        this.renderBars(ctx, width, height, freqData, config, bassEnergy);
        break;
      case 'circular':
        this.renderCircular(
          ctx,
          width,
          height,
          freqData,
          config,
          bassEnergy,
          coverImage,
          currentTime,
          duration
        );
        break;
      case 'neon':
        this.renderNeon(ctx, width, height, freqData, config, bassEnergy);
        break;
      case 'waveform':
        this.renderWaveform(ctx, width, height, timeData, config, bassEnergy);
        break;
    }

    // 5. Render Track Info Overlay (Title, Artist, Duration)
    if (config.showTrackInfo) {
      this.renderTrackInfo(ctx, width, height, config, currentTime, duration);
    }
  }

  /**
   * Background renderer
   */
  private renderBackground(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    config: SpectrumConfig,
    bgImage: HTMLImageElement | null,
    freqData: Uint8Array
  ): void {
    ctx.save();

    if (bgImage && bgImage.complete && bgImage.naturalWidth > 0) {
      // Draw Cover / Custom Image with Cover Aspect Ratio
      const imgAspect = bgImage.naturalWidth / bgImage.naturalHeight;
      const canvasAspect = width / height;
      let drawW = width;
      let drawH = height;
      let drawX = 0;
      let drawY = 0;

      if (imgAspect > canvasAspect) {
        drawW = height * imgAspect;
        drawX = (width - drawW) / 2;
      } else {
        drawH = width / imgAspect;
        drawY = (height - drawH) / 2;
      }

      if (config.backgroundBlur > 0) {
        ctx.filter = `blur(${config.backgroundBlur * (width / 960)}px)`;
      }

      ctx.drawImage(bgImage, drawX, drawY, drawW, drawH);
      ctx.filter = 'none';
    } else {
      // Draw Gradient Background
      const grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#090d16');
      grad.addColorStop(0.5, '#111827');
      grad.addColorStop(1, '#05070c');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    }

    // Darken Overlay
    if (config.backgroundOverlayDarkness > 0) {
      ctx.fillStyle = `rgba(0, 0, 0, ${config.backgroundOverlayDarkness / 100})`;
      ctx.fillRect(0, 0, width, height);
    }

    // Ambient Center Glow based on Bass
    const bass = this.computeBassEnergy(freqData);
    if (bass > 0.1) {
      const glowGrad = ctx.createRadialGradient(
        width / 2,
        height / 2,
        50,
        width / 2,
        height / 2,
        width * 0.6
      );
      glowGrad.addColorStop(0, `${config.glowColor}${Math.round(bass * 45).toString(16).padStart(2, '0')}`);
      glowGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = glowGrad;
      ctx.fillRect(0, 0, width, height);
    }

    ctx.restore();
  }

  /**
   * Mode 1: Classic & Modern Frequency Bars
   */
  private renderBars(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    freqData: Uint8Array,
    config: SpectrumConfig,
    bassEnergy: number
  ): void {
    const barCount = config.barCount;
    const spacing = config.barSpacing * (width / 960);
    const totalSpacing = spacing * (barCount - 1);
    const availableWidth = width * 0.88;
    const barWidth = Math.max(2, (availableWidth - totalSpacing) / barCount);
    const startX = (width - (barCount * barWidth + totalSpacing)) / 2;

    let baseY = height * 0.82;
    if (config.position === 'center') baseY = height * 0.55;
    if (config.position === 'top') baseY = height * 0.25;

    const maxBarHeight = height * 0.45 * config.sensitivity;

    // Resample frequency bins logarithmically to give rich bass, mid, and treble
    const samples = this.resampleFrequencies(freqData, barCount);

    // Update Peaks
    if (this.peakValues.length !== barCount) {
      this.peakValues = new Array(barCount).fill(0);
    }

    ctx.save();

    for (let i = 0; i < barCount; i++) {
      const x = startX + i * (barWidth + spacing);
      const val = (samples[i] / 255) * config.sensitivity;
      const barH = Math.max(3, Math.min(maxBarHeight, val * maxBarHeight));

      // Peak decay
      if (barH > this.peakValues[i]) {
        this.peakValues[i] = barH;
      } else {
        this.peakValues[i] *= config.peakDecay || 0.96;
      }

      // Bar Gradient
      const grad = ctx.createLinearGradient(x, baseY, x, baseY - barH);
      grad.addColorStop(0, config.primaryColor);
      grad.addColorStop(1, config.secondaryColor);
      ctx.fillStyle = grad;

      // Draw Main Bar (with rounded cap)
      this.drawRoundedRect(
        ctx,
        x,
        baseY - barH,
        barWidth,
        barH,
        config.barRadius * (width / 960)
      );

      // Draw Symmetrical Mirror Reflection if enabled
      if (config.mirror) {
        const mirrorGrad = ctx.createLinearGradient(x, baseY, x, baseY + barH * 0.4);
        mirrorGrad.addColorStop(0, `${config.primaryColor}55`);
        mirrorGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = mirrorGrad;
        this.drawRoundedRect(
          ctx,
          x,
          baseY,
          barWidth,
          barH * 0.4,
          config.barRadius * (width / 960)
        );
      }

      // Draw Peak Hold Dot
      if (config.showPeaks && this.peakValues[i] > 4) {
        ctx.fillStyle = config.secondaryColor;
        ctx.shadowColor = config.glowColor;
        ctx.shadowBlur = 6;
        ctx.fillRect(x, baseY - this.peakValues[i] - 4, barWidth, 2.5);
        ctx.shadowBlur = 0;
      }
    }

    ctx.restore();
  }

  /**
   * Mode 2: 360-Degree Circular Spectrum
   */
  private renderCircular(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    freqData: Uint8Array,
    config: SpectrumConfig,
    bassEnergy: number,
    coverImage: HTMLImageElement | null,
    currentTime: number,
    duration: number
  ): void {
    const centerX = width / 2;
    const centerY = height * 0.48;
    const baseRadius = config.circularRadius * (height / 1080);
    const pulse = config.pulseCover ? 1 + bassEnergy * 0.12 : 1;
    const currentRadius = baseRadius * pulse;

    this.rotationAngle += 0.003 * (config.circularRotateSpeed || 1);

    const barCount = config.barCount;
    const samples = this.resampleFrequencies(freqData, barCount);
    const maxBarLength = height * 0.22 * config.sensitivity;

    ctx.save();

    // 1. Draw Center Album Disc / Cover
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, currentRadius - 8, 0, Math.PI * 2);
    ctx.clip();

    if (coverImage && coverImage.complete && coverImage.naturalWidth > 0) {
      const imgSize = (currentRadius - 8) * 2;
      ctx.drawImage(
        coverImage,
        centerX - currentRadius + 8,
        centerY - currentRadius + 8,
        imgSize,
        imgSize
      );
    } else {
      // Default vinyl disc
      const discGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        10,
        centerX,
        centerY,
        currentRadius
      );
      discGrad.addColorStop(0, '#1e293b');
      discGrad.addColorStop(0.8, '#0f172a');
      discGrad.addColorStop(1, '#020617');
      ctx.fillStyle = discGrad;
      ctx.fill();

      // Disc grooves
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.lineWidth = 1.5;
      for (let r = 25; r < currentRadius - 15; r += 12) {
        ctx.beginPath();
        ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
    ctx.restore();

    // 2. Draw Progress Ring around Center
    if (config.showProgressRing && duration > 0) {
      const progress = Math.min(1, Math.max(0, currentTime / duration));
      ctx.beginPath();
      ctx.arc(
        centerX,
        centerY,
        currentRadius - 4,
        -Math.PI / 2,
        -Math.PI / 2 + Math.PI * 2 * progress
      );
      ctx.strokeStyle = config.secondaryColor;
      ctx.lineWidth = 3;
      ctx.shadowColor = config.secondaryColor;
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    // 3. Draw Radial Frequency Bars
    const angleStep = (Math.PI * 2) / barCount;

    for (let i = 0; i < barCount; i++) {
      const angle = i * angleStep + this.rotationAngle;
      const val = (samples[i] / 255) * config.sensitivity;
      const barLen = Math.max(4, Math.min(maxBarLength, val * maxBarLength));

      const x1 = centerX + Math.cos(angle) * currentRadius;
      const y1 = centerY + Math.sin(angle) * currentRadius;
      const x2 = centerX + Math.cos(angle) * (currentRadius + barLen);
      const y2 = centerY + Math.sin(angle) * (currentRadius + barLen);

      const grad = ctx.createLinearGradient(x1, y1, x2, y2);
      grad.addColorStop(0, config.primaryColor);
      grad.addColorStop(1, config.secondaryColor);

      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.strokeStyle = grad;
      ctx.lineWidth = Math.max(2, (2 * Math.PI * currentRadius) / (barCount * 1.8));
      ctx.lineCap = 'round';
      ctx.shadowColor = config.glowColor;
      ctx.shadowBlur = val > 0.4 ? 10 : 2;
      ctx.stroke();
    }

    ctx.restore();
  }

  /**
   * Mode 3: Neon Glowing Bloom Spectrum + Sparkle Particles
   */
  private renderNeon(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    freqData: Uint8Array,
    config: SpectrumConfig,
    bassEnergy: number
  ): void {
    const barCount = config.barCount;
    const spacing = config.barSpacing * (width / 960);
    const availableWidth = width * 0.88;
    const barWidth = Math.max(2, (availableWidth - spacing * (barCount - 1)) / barCount);
    const startX = (width - (barCount * barWidth + spacing * (barCount - 1))) / 2;

    const baseY = height * 0.78;
    const maxBarHeight = height * 0.48 * config.sensitivity;
    const samples = this.resampleFrequencies(freqData, barCount);

    ctx.save();

    // Emit neon particles on high frequency peaks
    if (bassEnergy > 0.4 && Math.random() < 0.7) {
      for (let p = 0; p < 4; p++) {
        const rndIdx = Math.floor(Math.random() * barCount);
        const px = startX + rndIdx * (barWidth + spacing);
        const py = baseY - (samples[rndIdx] / 255) * maxBarHeight;
        this.particles.push({
          x: px,
          y: py,
          vx: (Math.random() - 0.5) * 4,
          vy: -Math.random() * 5 - 2,
          size: Math.random() * 3 + 1,
          color: Math.random() > 0.5 ? config.primaryColor : config.secondaryColor,
          alpha: 1.0,
          life: 1.0,
        });
      }
    }

    // Pass 1: Multi-layer Glowing Bars
    for (let i = 0; i < barCount; i++) {
      const x = startX + i * (barWidth + spacing);
      const val = (samples[i] / 255) * config.sensitivity;
      const barH = Math.max(3, Math.min(maxBarHeight, val * maxBarHeight));

      // Neon Bloom Shadow
      ctx.shadowColor = config.glowColor;
      ctx.shadowBlur = 16 * (val + 0.2);

      const grad = ctx.createLinearGradient(x, baseY, x, baseY - barH);
      grad.addColorStop(0, config.primaryColor);
      grad.addColorStop(1, config.secondaryColor);
      ctx.fillStyle = grad;

      this.drawRoundedRect(ctx, x, baseY - barH, barWidth, barH, barWidth / 2);

      // Highlight core inside neon bar
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#ffffff';
      this.drawRoundedRect(ctx, x + barWidth * 0.25, baseY - barH + 2, barWidth * 0.5, barH * 0.8, 1);
    }

    // Render & Update Particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.life -= 0.03;
      p.alpha = Math.max(0, p.life);

      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    ctx.restore();
  }

  /**
   * Mode 4: Smooth Oscilloscope Waveform Ribbon
   */
  private renderWaveform(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    timeData: Uint8Array,
    config: SpectrumConfig,
    bassEnergy: number
  ): void {
    const centerY = height * 0.55;
    const sliceWidth = (width * 0.88) / timeData.length;
    const startX = width * 0.06;
    const amplitude = height * 0.3 * config.sensitivity;

    ctx.save();

    // 1. Draw Translucent Glow Wave Ribbon
    ctx.beginPath();
    ctx.moveTo(startX, centerY);

    for (let i = 0; i < timeData.length; i++) {
      const v = (timeData[i] - 128) / 128;
      const y = centerY + v * amplitude;
      const x = startX + i * sliceWidth;

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        const prevX = startX + (i - 1) * sliceWidth;
        const prevY = centerY + ((timeData[i - 1] - 128) / 128) * amplitude;
        const xc = (prevX + x) / 2;
        const yc = (prevY + y) / 2;
        ctx.quadraticCurveTo(prevX, prevY, xc, yc);
      }
    }

    const waveGrad = ctx.createLinearGradient(startX, 0, startX + width * 0.88, 0);
    waveGrad.addColorStop(0, config.primaryColor);
    waveGrad.addColorStop(0.5, config.secondaryColor);
    waveGrad.addColorStop(1, config.glowColor);

    ctx.strokeStyle = waveGrad;
    ctx.lineWidth = (config.waveformThickness || 4) * (width / 960);
    ctx.lineCap = 'round';
    ctx.shadowColor = config.glowColor;
    ctx.shadowBlur = 14;
    ctx.stroke();

    // 2. Draw Mirrored Wave Underneath
    if (config.mirror) {
      ctx.beginPath();
      for (let i = 0; i < timeData.length; i++) {
        const v = (timeData[i] - 128) / 128;
        const y = centerY - v * amplitude * 0.5;
        const x = startX + i * sliceWidth;

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          const prevX = startX + (i - 1) * sliceWidth;
          const prevY = centerY - ((timeData[i - 1] - 128) / 128) * amplitude * 0.5;
          const xc = (prevX + x) / 2;
          const yc = (prevY + y) / 2;
          ctx.quadraticCurveTo(prevX, prevY, xc, yc);
        }
      }
      ctx.strokeStyle = `${config.primaryColor}44`;
      ctx.lineWidth = 2;
      ctx.shadowBlur = 0;
      ctx.stroke();
    }

    ctx.restore();
  }

  /**
   * Renders Track Title, Artist, and Duration overlay
   */
  private renderTrackInfo(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    config: SpectrumConfig,
    currentTime: number,
    duration: number
  ): void {
    ctx.save();
    ctx.textAlign = 'center';

    const titleY = config.style === 'circular' ? height * 0.82 : height * 0.22;
    const scale = width / 1920;

    // Track Title
    ctx.font = `bold ${Math.round(44 * scale)}px sans-serif`;
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
    ctx.shadowBlur = 10;
    ctx.fillText(config.trackTitle || 'Audio Track', width / 2, titleY);

    // Artist Name
    ctx.font = `500 ${Math.round(26 * scale)}px sans-serif`;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.fillText(config.artistName || 'Artist Name', width / 2, titleY + 36 * scale);

    // Time Indicator
    if (duration > 0) {
      const curStr = this.formatTime(currentTime);
      const durStr = this.formatTime(duration);
      ctx.font = `600 ${Math.round(20 * scale)}px monospace`;
      ctx.fillStyle = config.secondaryColor;
      ctx.fillText(`${curStr} / ${durStr}`, width / 2, titleY + 68 * scale);
    }

    ctx.restore();
  }

  /**
   * Helper: logarithmic frequency resampling
   */
  private resampleFrequencies(freqData: Uint8Array, targetCount: number): number[] {
    const result: number[] = new Array(targetCount).fill(0);
    const totalBins = Math.min(freqData.length, 384);

    for (let i = 0; i < targetCount; i++) {
      // Logarithmic distribution to capture music warmth & bass
      const logMin = Math.log10(1);
      const logMax = Math.log10(totalBins);
      const startBin = Math.floor(
        Math.pow(10, logMin + (i / targetCount) * (logMax - logMin))
      );
      const endBin = Math.max(
        startBin + 1,
        Math.floor(Math.pow(10, logMin + ((i + 1) / targetCount) * (logMax - logMin)))
      );

      let sum = 0;
      let count = 0;
      for (let b = startBin; b < endBin && b < freqData.length; b++) {
        sum += freqData[b];
        count++;
      }
      result[i] = count > 0 ? sum / count : 0;
    }

    return result;
  }

  /**
   * Helper: computes bass band average (sub 200Hz)
   */
  private computeBassEnergy(freqData: Uint8Array): number {
    let sum = 0;
    const bassBins = Math.min(16, freqData.length);
    for (let i = 0; i < bassBins; i++) {
      sum += freqData[i];
    }
    return sum / (bassBins * 255);
  }

  /**
   * Helper: draws rounded rectangle path
   */
  private drawRoundedRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    radius: number
  ): void {
    const r = Math.min(radius, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h);
    ctx.lineTo(x, y + h);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.fill();
  }

  private formatTime(sec: number): string {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  }
}
