export type SpectrumStyle = 'bars' | 'circular' | 'waveform' | 'neon';

export type ColorSchemePreset =
  | 'cyberpunk'
  | 'fire'
  | 'ocean'
  | 'neon-green'
  | 'sunset'
  | 'purple-haze'
  | 'monochrome'
  | 'rainbow'
  | 'custom';

export type SpectrumPosition = 'bottom' | 'center' | 'top' | 'circular-center';

export type BackgroundType = 'custom' | 'gradient' | 'solid';

export interface SpectrumConfig {
  style: SpectrumStyle;
  colorScheme: ColorSchemePreset;
  primaryColor: string;
  secondaryColor: string;
  glowColor: string;
  barCount: number; // 32, 64, 128, 256
  barWidth: number; // auto or manual
  barSpacing: number;
  barRadius: number;
  sensitivity: number; // 0.5 to 3.0
  smoothingTimeConstant: number; // 0.5 to 0.95
  position: SpectrumPosition;
  mirror: boolean;
  showPeaks: boolean;
  peakDecay: number; // decay speed
  circularRadius: number;
  circularRotateSpeed: number;
  waveformThickness: number;
  backgroundType: BackgroundType;
  backgroundImageUrl: string | null;
  backgroundBlur: number; // 0 - 20px
  backgroundOverlayDarkness: number; // 0 - 90%
  gradientPreset: string;
  trackTitle: string;
  artistName: string;
  showTrackInfo: boolean;
  pulseCover: boolean;
  coverImageUrl: string | null;
  showProgressRing: boolean;
}

export const DEFAULT_SPECTRUM_CONFIG: SpectrumConfig = {
  style: 'bars',
  colorScheme: 'cyberpunk',
  primaryColor: '#06b6d4', // cyan-500
  secondaryColor: '#ec4899', // pink-500
  glowColor: '#3b82f6', // blue-500
  barCount: 64,
  barWidth: 6,
  barSpacing: 4,
  barRadius: 4,
  sensitivity: 1.3,
  smoothingTimeConstant: 0.8,
  position: 'bottom',
  mirror: true,
  showPeaks: true,
  peakDecay: 0.96,
  circularRadius: 180,
  circularRotateSpeed: 0.5,
  waveformThickness: 4,
  backgroundType: 'gradient',
  backgroundImageUrl: null,
  backgroundBlur: 6,
  backgroundOverlayDarkness: 50,
  gradientPreset: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #311042 100%)',
  trackTitle: 'Audio Spectrum Track',
  artistName: 'CTools Music',
  showTrackInfo: true,
  pulseCover: true,
  coverImageUrl: null,
  showProgressRing: true,
};

export const COLOR_SCHEME_PALETTES: Record<
  ColorSchemePreset,
  { name: string; primary: string; secondary: string; glow: string }
> = {
  cyberpunk: {
    name: 'Cyberpunk Neon',
    primary: '#06b6d4',
    secondary: '#f43f5e',
    glow: '#8b5cf6',
  },
  fire: {
    name: 'Inferno Fire',
    primary: '#f59e0b',
    secondary: '#ef4444',
    glow: '#dc2626',
  },
  ocean: {
    name: 'Deep Ocean',
    primary: '#38bdf8',
    secondary: '#3b82f6',
    glow: '#1d4ed8',
  },
  'neon-green': {
    name: 'Matrix Toxic',
    primary: '#22c55e',
    secondary: '#10b981',
    glow: '#16a34a',
  },
  sunset: {
    name: 'Golden Sunset',
    primary: '#f97316',
    secondary: '#ec4899',
    glow: '#e11d48',
  },
  'purple-haze': {
    name: 'Purple Aurora',
    primary: '#a855f7',
    secondary: '#6366f1',
    glow: '#9333ea',
  },
  monochrome: {
    name: 'Monochrome Silver',
    primary: '#f8fafc',
    secondary: '#94a3b8',
    glow: '#e2e8f0',
  },
  rainbow: {
    name: 'Vibrant Rainbow',
    primary: '#ec4899',
    secondary: '#3b82f6',
    glow: '#10b981',
  },
  custom: {
    name: 'Kustom Warna',
    primary: '#06b6d4',
    secondary: '#f43f5e',
    glow: '#8b5cf6',
  },
};

export interface AudioMetadata {
  name: string;
  duration: number; // in seconds
  sampleRate: number;
  numberOfChannels: number;
  size: number;
}
