import { SpectrumConfig, BG_PRESETS } from './types';

export interface RenderContext {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  frequencyData: Uint8Array | number[];
  timeDomainData?: Uint8Array | number[];
  config: SpectrumConfig;
  currentTime?: number;
  peakData?: number[];
  particles?: Array<{ x: number; y: number; vx: number; vy: number; size: number; alpha: number; color: string }>;
}

export class SpectrumRenderer {
  /**
   * Main master draw frame function
   */
  static drawFrame(rc: RenderContext): void {
    const { ctx, canvas, frequencyData, config } = rc;
    const width = canvas.width;
    const height = canvas.height;

    // 1. Draw Background
    this.drawBackground(ctx, width, height, config);

    // Calculate audio bass/energy for dynamic pulses
    const bassEnergy = this.calculateBassEnergy(frequencyData);

    // 2. Draw Style-specific Spectrum
    switch (config.style) {
      case 'bars':
        this.drawBars(rc, width, height, bassEnergy);
        break;
      case 'circular':
        this.drawCircular(rc, width, height, bassEnergy);
        break;
      case 'waveform':
        this.drawWaveform(rc, width, height, bassEnergy);
        break;
      case 'neon':
        this.drawNeon(rc, width, height, bassEnergy);
        break;
    }

    // 3. Draw Text Overlay (if enabled)
    if (config.showText && (config.title || config.artist)) {
      this.drawTextOverlay(ctx, width, height, config);
    }
  }

  /**
   * Calculates overall bass energy (low frequency bins) [0.0 - 1.0]
   */
  private static calculateBassEnergy(freqData: Uint8Array | number[]): number {
    if (!freqData || freqData.length === 0) return 0;
    const bassCount = Math.min(8, freqData.length);
    let sum = 0;
    for (let i = 0; i < bassCount; i++) {
      sum += freqData[i];
    }
    return Math.min(1, (sum / (bassCount * 255)) * 1.3);
  }

  /**
   * Draws canvas background with presets or uploaded cover image
   */
  private static drawBackground(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    config: SpectrumConfig
  ): void {
    ctx.save();

    if (config.bgType === 'custom' && config.coverImage) {
      // Draw uploaded custom background image with aspect fill
      const img = config.coverImage;
      const imgRatio = img.width / img.height;
      const canvasRatio = width / height;
      let drawW = width;
      let drawH = height;
      let drawX = 0;
      let drawY = 0;

      if (imgRatio > canvasRatio) {
        drawW = height * imgRatio;
        drawX = (width - drawW) / 2;
      } else {
        drawH = width / imgRatio;
        drawY = (height - drawH) / 2;
      }

      if (config.bgBlur > 0) {
        ctx.filter = `blur(${config.bgBlur}px)`;
      }

      ctx.drawImage(img, drawX - 10, drawY - 10, drawW + 20, drawH + 20);
      ctx.filter = 'none';
    } else {
      // Draw Gradient Preset
      const preset = BG_PRESETS.find((p) => p.id === config.bgPresetId) || BG_PRESETS[0];
      const grad = ctx.createLinearGradient(0, 0, width, height);

      if (preset.id === 'dark-cyber') {
        grad.addColorStop(0, '#0a0d14');
        grad.addColorStop(0.5, '#161f2e');
        grad.addColorStop(1, '#0a0d14');
      } else if (preset.id === 'deep-purple') {
        grad.addColorStop(0, '#10051d');
        grad.addColorStop(0.5, '#280f43');
        grad.addColorStop(1, '#0d0417');
      } else if (preset.id === 'midnight-blue') {
        grad.addColorStop(0, '#060914');
        grad.addColorStop(0.5, '#101a38');
        grad.addColorStop(1, '#060914');
      } else if (preset.id === 'dark-emerald') {
        grad.addColorStop(0, '#05120f');
        grad.addColorStop(0.5, '#0e2922');
        grad.addColorStop(1, '#05120f');
      } else {
        grad.addColorStop(0, '#050508');
        grad.addColorStop(1, '#090910');
      }

      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    }

    // Darkness Overlay
    if (config.bgDarkness > 0) {
      ctx.fillStyle = `rgba(0, 0, 0, ${config.bgDarkness})`;
      ctx.fillRect(0, 0, width, height);
    }

    // Subtle ambient vignette
    const vignette = ctx.createRadialGradient(
      width / 2,
      height / 2,
      Math.min(width, height) * 0.3,
      width / 2,
      height / 2,
      Math.max(width, height) * 0.8
    );
    vignette.addColorStop(0, 'rgba(0,0,0,0)');
    vignette.addColorStop(1, 'rgba(0,0,0,0.65)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, width, height);

    ctx.restore();
  }

  /**
   * 1. BARS SPECTRUM (Classic Equalizer Bars)
   */
  private static drawBars(
    rc: RenderContext,
    width: number,
    height: number,
    bassEnergy: number
  ): void {
    const { ctx, frequencyData, config, peakData } = rc;
    const count = Math.min(config.barCount, frequencyData.length);
    const step = Math.floor(frequencyData.length / count) || 1;

    let baselineY = height * 0.82;
    if (config.position === 'center') baselineY = height * 0.5;
    if (config.position === 'top') baselineY = height * 0.25;

    const maxHeight = height * 0.52 * config.sensitivity;
    const totalWidth = width * 0.88;
    const startX = (width - totalWidth) / 2;
    const barWidth = Math.max(2, (totalWidth / count) * 0.72);
    const barGap = (totalWidth - barWidth * count) / (count - 1);

    ctx.save();

    for (let i = 0; i < count; i++) {
      const freqIdx = Math.min(frequencyData.length - 1, i * step);
      const rawVal = frequencyData[freqIdx] / 255;
      const barH = Math.max(4, rawVal * maxHeight);

      const x = startX + i * (barWidth + barGap);

      // Create vertical gradient
      const grad = ctx.createLinearGradient(0, baselineY, 0, baselineY - barH);
      grad.addColorStop(0, config.secondaryColor);
      grad.addColorStop(1, config.primaryColor);

      ctx.fillStyle = grad;

      if (config.position === 'center' || config.mirrored) {
        // Mirrored up and down from center
        const halfH = barH / 2;
        if (config.roundedBars && barWidth > 3) {
          this.roundRect(ctx, x, baselineY - halfH, barWidth, halfH * 2, barWidth / 2);
        } else {
          ctx.fillRect(x, baselineY - halfH, barWidth, halfH * 2);
        }
      } else if (config.position === 'top') {
        // Drop down from top
        if (config.roundedBars && barWidth > 3) {
          this.roundRect(ctx, x, baselineY, barWidth, barH, barWidth / 2);
        } else {
          ctx.fillRect(x, baselineY, barWidth, barH);
        }
      } else {
        // Standard bottom-up bars
        if (config.roundedBars && barWidth > 3) {
          this.roundRect(ctx, x, baselineY - barH, barWidth, barH, barWidth / 2);
        } else {
          ctx.fillRect(x, baselineY - barH, barWidth, barH);
        }
      }

      // Draw peak fall-off caps
      if (config.showPeaks && peakData) {
        if (!peakData[i] || barH > peakData[i]) {
          peakData[i] = barH;
        } else {
          peakData[i] = Math.max(4, peakData[i] - 1.8);
        }

        const peakY = config.position === 'center'
          ? baselineY - peakData[i] / 2 - 4
          : baselineY - peakData[i] - 4;

        ctx.fillStyle = config.accentColor;
        ctx.fillRect(x, peakY, barWidth, 3);
      }
    }

    ctx.restore();
  }

  /**
   * 2. CIRCULAR SPECTRUM (Radial 360-Degree Ring)
   */
  private static drawCircular(
    rc: RenderContext,
    width: number,
    height: number,
    bassEnergy: number
  ): void {
    const { ctx, frequencyData, config } = rc;
    const centerX = width / 2;
    let centerY = height / 2;
    if (config.position === 'bottom') centerY = height * 0.6;
    if (config.position === 'top') centerY = height * 0.4;

    const baseRadius = Math.min(width, height) * 0.18 * (1 + bassEnergy * 0.12);
    const maxBarLength = Math.min(width, height) * 0.22 * config.sensitivity;
    const count = Math.min(config.barCount, 128);
    const angleStep = (Math.PI * 2) / count;

    ctx.save();

    // 1. Draw Pulsing Center Outer Glow Ring
    ctx.beginPath();
    ctx.arc(centerX, centerY, baseRadius + 4, 0, Math.PI * 2);
    ctx.strokeStyle = config.primaryColor;
    ctx.lineWidth = 3 + bassEnergy * 5;
    ctx.shadowColor = config.primaryColor;
    ctx.shadowBlur = 15 + bassEnergy * 25;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // 2. Draw Center Album Art (if available) or Dark Gradient Core
    ctx.save();
    ctx.beginPath();
    ctx.arc(centerX, centerY, baseRadius - 2, 0, Math.PI * 2);
    ctx.clip();

    if (config.coverImage) {
      const img = config.coverImage;
      const size = (baseRadius - 2) * 2;
      ctx.drawImage(img, centerX - baseRadius, centerY - baseRadius, size, size);
    } else {
      const coreGrad = ctx.createRadialGradient(
        centerX,
        centerY,
        0,
        centerX,
        centerY,
        baseRadius
      );
      coreGrad.addColorStop(0, '#1a233a');
      coreGrad.addColorStop(1, '#0a0d18');
      ctx.fillStyle = coreGrad;
      ctx.fill();
    }
    ctx.restore();

    // 3. Draw Radial Frequency Bars
    for (let i = 0; i < count; i++) {
      const freqIdx = Math.floor((i / count) * (frequencyData.length * 0.75));
      const val = (frequencyData[freqIdx] || 0) / 255;
      const barLen = Math.max(4, val * maxBarLength);

      const angle = i * angleStep - Math.PI / 2;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);

      const startX = centerX + cos * (baseRadius + 6);
      const startY = centerY + sin * (baseRadius + 6);
      const endX = centerX + cos * (baseRadius + 6 + barLen);
      const endY = centerY + sin * (baseRadius + 6 + barLen);

      // Radial bar line
      ctx.beginPath();
      ctx.moveTo(startX, startY);
      ctx.lineTo(endX, endY);
      ctx.lineWidth = Math.max(2, ((Math.PI * 2 * baseRadius) / count) * 0.65);
      ctx.strokeStyle = val > 0.6 ? config.accentColor : config.primaryColor;
      ctx.lineCap = config.roundedBars ? 'round' : 'butt';
      ctx.stroke();
    }

    ctx.restore();
  }

  /**
   * 3. WAVEFORM (Smooth Glowing Oscilloscope & Ribbon)
   */
  private static drawWaveform(
    rc: RenderContext,
    width: number,
    height: number,
    bassEnergy: number
  ): void {
    const { ctx, frequencyData, timeDomainData, config } = rc;
    const data = timeDomainData || frequencyData;
    const count = Math.min(128, data.length);
    const step = Math.floor(data.length / count) || 1;

    let baselineY = height * 0.7;
    if (config.position === 'center') baselineY = height * 0.5;
    if (config.position === 'top') baselineY = height * 0.3;

    const maxAmp = height * 0.28 * config.sensitivity;
    const sliceWidth = width / (count - 1);

    ctx.save();

    // Generate smoothed points
    const points: Array<{ x: number; y: number }> = [];
    for (let i = 0; i < count; i++) {
      const raw = data[i * step] / 128.0 - 1.0; // -1.0 to 1.0
      const x = i * sliceWidth;
      const y = baselineY + raw * maxAmp;
      points.push({ x, y });
    }

    // 1. Draw Translucent Gradient Fill Under Wave
    ctx.beginPath();
    ctx.moveTo(0, height);
    ctx.lineTo(points[0].x, points[0].y);
    for (let i = 0; i < points.length - 1; i++) {
      const xc = (points[i].x + points[i + 1].x) / 2;
      const yc = (points[i].y + points[i + 1].y) / 2;
      ctx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
    }
    ctx.lineTo(width, height);
    ctx.closePath();

    const fillGrad = ctx.createLinearGradient(0, baselineY - maxAmp, 0, height);
    fillGrad.addColorStop(0, `${config.primaryColor}55`); // 33% alpha
    fillGrad.addColorStop(1, `${config.secondaryColor}00`); // transparent
    ctx.fillStyle = fillGrad;
    ctx.fill();

    // 2. Draw Main Glowing Wave Stroke
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 0; i < points.length - 1; i++) {
      const xc = (points[i].x + points[i + 1].x) / 2;
      const yc = (points[i].y + points[i + 1].y) / 2;
      ctx.quadraticCurveTo(points[i].x, points[i].y, xc, yc);
    }

    ctx.shadowColor = config.primaryColor;
    ctx.shadowBlur = 20;
    ctx.strokeStyle = config.primaryColor;
    ctx.lineWidth = 4 + bassEnergy * 2;
    ctx.stroke();

    // 3. Inner Bright Core Stroke
    ctx.shadowBlur = 0;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.restore();
  }

  /**
   * 4. NEON SPECTRUM (High-Energy Cyber Bloom & Floating Particles)
   */
  private static drawNeon(
    rc: RenderContext,
    width: number,
    height: number,
    bassEnergy: number
  ): void {
    const { ctx, frequencyData, config } = rc;
    const count = Math.min(config.barCount, 64);
    const step = Math.floor(frequencyData.length / count) || 1;

    let baselineY = height * 0.85;
    if (config.position === 'center') baselineY = height * 0.52;
    if (config.position === 'top') baselineY = height * 0.28;

    const maxHeight = height * 0.55 * config.sensitivity;
    const totalWidth = width * 0.9;
    const startX = (width - totalWidth) / 2;
    const barWidth = Math.max(3, (totalWidth / count) * 0.65);
    const barGap = (totalWidth - barWidth * count) / (count - 1);

    ctx.save();

    for (let i = 0; i < count; i++) {
      const rawVal = frequencyData[i * step] / 255;
      const barH = Math.max(6, rawVal * maxHeight);
      const x = startX + i * (barWidth + barGap);

      // Neon Outer Glow
      ctx.shadowColor = config.primaryColor;
      ctx.shadowBlur = 18 + rawVal * 25;

      const grad = ctx.createLinearGradient(0, baselineY, 0, baselineY - barH);
      grad.addColorStop(0, config.secondaryColor);
      grad.addColorStop(0.6, config.primaryColor);
      grad.addColorStop(1, '#ffffff');

      ctx.fillStyle = grad;

      if (config.roundedBars) {
        this.roundRect(ctx, x, baselineY - barH, barWidth, barH, barWidth / 2);
      } else {
        ctx.fillRect(x, baselineY - barH, barWidth, barH);
      }

      // Bright Neon Cap Dot
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, baselineY - barH - 3, barWidth, 3);
    }

    ctx.restore();
  }

  /**
   * Draws Track Title and Artist overlay with crisp typography
   */
  private static drawTextOverlay(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    config: SpectrumConfig
  ): void {
    ctx.save();
    ctx.textAlign = 'center';

    const textY = height * 0.18;
    const titleSize = Math.max(20, Math.round(height * 0.045));
    const artistSize = Math.max(14, Math.round(height * 0.026));

    // Drop Shadow for high readability
    ctx.shadowColor = 'rgba(0,0,0,0.85)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 3;

    // Track Title
    if (config.title) {
      ctx.font = `bold ${titleSize}px 'Plus Jakarta Sans', sans-serif`;
      ctx.fillStyle = config.textColor || '#ffffff';
      ctx.fillText(config.title, width / 2, textY);
    }

    // Artist / Subtitle
    if (config.artist) {
      ctx.font = `500 ${artistSize}px 'Plus Jakarta Sans', sans-serif`;
      ctx.fillStyle = `${config.textColor || '#ffffff'}bb`;
      ctx.fillText(config.artist, width / 2, textY + titleSize * 0.95);
    }

    ctx.restore();
  }

  /**
   * Utility helper to draw rounded rectangle
   */
  private static roundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number
  ): void {
    if (h < 2) return;
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
    ctx.fill();
  }
}
