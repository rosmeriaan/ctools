import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  AudioInputHandler,
} from './audioHandler';
import {
  VisualizationEngine,
} from './visualizationEngine';
import {
  FrameByFrameVideoRenderer,
  RenderProgress,
} from './videoRenderer';
import {
  SpectrumConfig,
  SpectrumStyle,
  ColorSchemePreset,
  DEFAULT_SPECTRUM_CONFIG,
  COLOR_SCHEME_PALETTES,
  AudioMetadata,
} from './types';
import { ProgressBar } from '../../components/common/ProgressBar';
import { PrivacyBadge } from '../../components/common/PrivacyBadge';
import { formatFileSize } from '../../utils/formatters';
import { downloadBlob } from '../../utils/file';
import { toast } from '../../utils/toast';
import {
  Play,
  Pause,
  Upload,
  Music,
  Image as ImageIcon,
  Sliders,
  Sparkles,
  Download,
  RotateCcw,
  Volume2,
  VolumeX,
  Radio,
  Disc,
  Activity,
  Layers,
  CheckCircle2,
  AlertCircle,
  Eye,
  Settings,
  X,
  Maximize2,
  Minimize2,
} from 'lucide-react';

export const AudioSpectrumTool: React.FC = () => {
  // Config & Audio State
  const [config, setConfig] = useState<SpectrumConfig>(DEFAULT_SPECTRUM_CONFIG);
  const [audioMetadata, setAudioMetadata] = useState<AudioMetadata | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'style' | 'colors' | 'visuals' | 'track'>('style');

  // Background & Cover Images
  const [bgImageEl, setBgImageEl] = useState<HTMLImageElement | null>(null);
  const [coverImageEl, setCoverImageEl] = useState<HTMLImageElement | null>(null);
  const [bgFilename, setBgFilename] = useState<string>('');
  const [coverFilename, setCoverFilename] = useState<string>('');

  // Export State
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [renderProgress, setRenderProgress] = useState<RenderProgress>({
    progress: 0,
    currentFrame: 0,
    totalFrames: 0,
    statusText: '',
  });
  const [exportedBlob, setExportedBlob] = useState<Blob | null>(null);
  const [exportedUrl, setExportedUrl] = useState<string>('');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // References
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const audioHandlerRef = useRef<AudioInputHandler | null>(null);
  const engineRef = useRef<VisualizationEngine | null>(null);
  const rendererRef = useRef<FrameByFrameVideoRenderer | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  // Initialize Handlers
  useEffect(() => {
    const handler = new AudioInputHandler();
    const engine = new VisualizationEngine();
    const renderer = new FrameByFrameVideoRenderer();

    audioHandlerRef.current = handler;
    engineRef.current = engine;
    rendererRef.current = renderer;

    handler.onTimeUpdate((cur, dur) => {
      setCurrentTime(cur);
      setDuration(dur);
    });

    handler.onEnded(() => {
      setIsPlaying(false);
    });

    // Auto-load demo synth beat for instant gratification
    handler
      .loadSampleAudio()
      .then((meta) => {
        setAudioMetadata(meta);
        setDuration(meta.duration);
        setConfig((prev) => ({
          ...prev,
          trackTitle: 'Cyberpunk Synthwave Beat',
          artistName: 'CTools Demo Beat',
        }));
      })
      .catch((err) => console.warn('Could not auto-load demo audio:', err));

    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      handler.destroy();
    };
  }, []);

  // Main Canvas Render Loop (60 FPS preview)
  const renderLoop = useCallback(() => {
    const canvas = canvasRef.current;
    const handler = audioHandlerRef.current;
    const engine = engineRef.current;

    if (canvas && handler && engine) {
      const ctx = canvas.getContext('2d', { alpha: false });
      if (ctx) {
        const fftSize = Math.max(256, config.barCount * 4);
        const freqData = handler.getFrequencyData(fftSize, config.smoothingTimeConstant);
        const timeData = handler.getTimeDomainData(512);
        const curTime = handler.getCurrentTime();
        const dur = handler.getDuration();

        engine.renderFrame(
          ctx,
          canvas.width,
          canvas.height,
          freqData,
          timeData,
          config,
          curTime,
          dur,
          bgImageEl,
          coverImageEl
        );
      }
    }

    animFrameIdRef.current = requestAnimationFrame(renderLoop);
  }, [config, bgImageEl, coverImageEl]);

  useEffect(() => {
    if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    animFrameIdRef.current = requestAnimationFrame(renderLoop);
    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    };
  }, [renderLoop]);

  // Audio Upload
  const handleAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      if (isPlaying) {
        audioHandlerRef.current?.pause();
        setIsPlaying(false);
      }

      toast.info('Memuat Audio', 'Mendekode audio untuk visualisasi...');
      const meta = await audioHandlerRef.current?.loadAudioFile(file);
      if (meta) {
        setAudioMetadata(meta);
        setDuration(meta.duration);
        setCurrentTime(0);
        setConfig((prev) => ({
          ...prev,
          trackTitle: meta.name,
        }));
        toast.success('Audio Siap', `Berhasil memuat "${meta.name}" (${Math.round(meta.duration)}s)`);
      }
    } catch (err: any) {
      toast.error('Gagal Memuat Audio', err?.message || 'Format audio tidak didukung');
    }
  };

  // Background Image Upload
  const handleBackgroundUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setBgImageEl(img);
      setBgFilename(file.name);
      setConfig((prev) => ({ ...prev, backgroundType: 'custom', backgroundImageUrl: url }));
      toast.success('Background Terpasang', file.name);
    };
    img.src = url;
  };

  // Center Cover Image Upload
  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const url = URL.createObjectURL(file);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      setCoverImageEl(img);
      setCoverFilename(file.name);
      setConfig((prev) => ({ ...prev, coverImageUrl: url }));
      toast.success('Cover Art Terpasang', file.name);
    };
    img.src = url;
  };

  // Play / Pause Toggle
  const togglePlay = async () => {
    if (!audioHandlerRef.current) return;
    if (isPlaying) {
      audioHandlerRef.current.pause();
      setIsPlaying(false);
    } else {
      try {
        await audioHandlerRef.current.play();
        setIsPlaying(true);
      } catch (err) {
        console.error('Play error:', err);
      }
    }
  };

  // Seek
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    audioHandlerRef.current?.seek(newTime);
  };

  // Volume
  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    setIsMuted(newVol === 0);
    audioHandlerRef.current?.setVolume(newVol);
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      audioHandlerRef.current?.setVolume(volume || 0.85);
    } else {
      setIsMuted(true);
      audioHandlerRef.current?.setVolume(0);
    }
  };

  // Color Palette Change
  const handlePaletteSelect = (presetKey: ColorSchemePreset) => {
    const pal = COLOR_SCHEME_PALETTES[presetKey];
    setConfig((prev) => ({
      ...prev,
      colorScheme: presetKey,
      primaryColor: pal.primary,
      secondaryColor: pal.secondary,
      glowColor: pal.glow,
    }));
  };

  // Start MP4 Export
  const handleExportMp4 = async () => {
    const handler = audioHandlerRef.current;
    const audioBuf = handler?.getAudioBuffer();
    if (!audioBuf) {
      toast.warning('Audio Belum Siap', 'Silakan upload file audio terlebih dahulu.');
      return;
    }

    // Pause live playback during export
    if (isPlaying) {
      handler.pause();
      setIsPlaying(false);
    }

    setIsExporting(true);
    setExportedBlob(null);
    if (exportedUrl) URL.revokeObjectURL(exportedUrl);
    setExportedUrl('');

    try {
      const blob = await rendererRef.current?.renderToMp4(
        audioBuf,
        handler.getAudioFile(),
        config,
        bgImageEl,
        coverImageEl,
        (p) => setRenderProgress(p)
      );

      if (blob) {
        setExportedBlob(blob);
        const url = URL.createObjectURL(blob);
        setExportedUrl(url);
        toast.success('Export Selesai!', 'Video MP4 1080p berhasil dibuat.');
      }
    } catch (err: any) {
      console.error('Export error:', err);
      toast.error('Gagal Export Video', err?.message || 'Terjadi kesalahan saat rendering');
      setIsExporting(false);
    }
  };

  const handleCancelExport = () => {
    rendererRef.current?.abort();
    setIsExporting(false);
    toast.info('Export Dibatalkan', 'Proses render video dihentikan.');
  };

  const handleDownloadVideo = () => {
    if (!exportedBlob) return;
    const safeTitle = (config.trackTitle || 'Audio_Spectrum')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 40);
    downloadBlob(exportedBlob, `${safeTitle}_1080p.mp4`);
  };

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[var(--border-primary)] pb-5">
        <div>
          <div className="flex items-center gap-3 mb-1.5">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-cyan-500 to-pink-500 text-white shadow-md shadow-cyan-500/20">
              <Radio className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[var(--text-primary)]">
                Audio Spectrum Visualizer
              </h1>
              <p className="text-sm text-[var(--text-secondary)]">
                Render gelombang audio & spektrum musik real-time dengan export video 1080p MP4 tersinkronisasi.
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <PrivacyBadge />
          <button
            onClick={handleExportMp4}
            disabled={!audioMetadata || isExporting}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-white bg-gradient-to-r from-cyan-500 via-indigo-500 to-pink-500 hover:from-cyan-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-cyan-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <Download className="w-4 h-4" />
            Export MP4 (1080p)
          </button>
        </div>
      </div>

      {/* Main Grid: Left Canvas Preview, Right Customization Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: 16:9 Canvas & Playback Controls (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Canvas Wrapper */}
          <div
            ref={containerRef}
            className={`relative rounded-2xl overflow-hidden bg-black/95 border border-[var(--border-primary)] shadow-2xl transition-all ${
              isFullscreen ? 'fixed inset-4 z-50 flex items-center justify-center bg-black' : ''
            }`}
          >
            <div className="aspect-video w-full relative">
              <canvas
                ref={canvasRef}
                width={1920}
                height={1080}
                className="w-full h-full object-contain block"
              />

              {/* Top Bar Info Badge */}
              <div className="absolute top-3 left-3 flex items-center gap-2 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-xs text-white">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                <span className="font-semibold uppercase tracking-wider">{config.style}</span>
                <span className="text-white/40">|</span>
                <span>{config.barCount} Bins</span>
                <span className="text-white/40">|</span>
                <span>1080p 30fps</span>
              </div>

              {/* Fullscreen Button */}
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="absolute top-3 right-3 p-2 bg-black/60 hover:bg-black/80 backdrop-blur-md text-white rounded-lg border border-white/10 transition-colors"
                title={isFullscreen ? 'Keluar Fullscreen' : 'Layar Penuh'}
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Audio Player Controls Bar */}
          <div className="bg-[var(--bg-secondary)] border border-[var(--border-primary)] rounded-2xl p-4 space-y-3 shadow-sm">
            {/* Timeline Slider */}
            <div className="flex items-center gap-3 text-xs font-mono text-[var(--text-secondary)]">
              <span className="w-10 text-right">{formatTime(currentTime)}</span>
              <input
                type="range"
                min={0}
                max={duration || 1}
                step={0.1}
                value={currentTime}
                onChange={handleSeek}
                className="flex-1 accent-cyan-500 cursor-pointer h-2 bg-[var(--bg-tertiary)] rounded-lg appearance-none"
              />
              <span className="w-10">{formatTime(duration)}</span>
            </div>

            {/* Play/Pause & Volume Row */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <button
                  onClick={togglePlay}
                  className="p-3 rounded-xl bg-cyan-500 hover:bg-cyan-600 text-white font-semibold shadow-md shadow-cyan-500/20 transition-transform active:scale-95"
                  title={isPlaying ? 'Pause' : 'Play'}
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                </button>

                <div className="text-left">
                  <div className="text-sm font-semibold text-[var(--text-primary)] truncate max-w-[200px] sm:max-w-xs">
                    {config.trackTitle || 'Audio Track'}
                  </div>
                  <div className="text-xs text-[var(--text-secondary)] truncate max-w-[200px] sm:max-w-xs">
                    {config.artistName || 'CTools Music'}
                  </div>
                </div>
              </div>

              {/* Volume Slider */}
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleMute}
                  className="p-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors"
                >
                  {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                  className="w-16 sm:w-24 accent-cyan-500 cursor-pointer h-1.5 bg-[var(--bg-tertiary)] rounded-lg appearance-none"
                />
              </div>
            </div>
          </div>

          {/* Quick Upload Files Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Audio Upload Card */}
            <label className="flex items-center gap-3 p-3.5 bg-[var(--bg-secondary)] hover:bg-[var(--bg-tertiary)] border border-dashed border-[var(--border-primary)] hover:border-cyan-500/50 rounded-xl cursor-pointer transition-all">
              <input
                type="file"
                accept="audio/*"
                onChange={handleAudioUpload}
                className="hidden"
              />
              <div className="p-2.5 rounded-lg bg-cyan-500/10 text-cyan-500">
                <Music className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold text-[var(--text-primary)] truncate">
                  {audioMetadata ? audioMetadata.name : 'Pilih File Audio (MP3/WAV)'}
                </div>
                <div className="text-[11px] text-[var(--text-secondary)]">
                  {audioMetadata ? `${formatFileSize(audioMetadata.size)}` : 'Klik atau drag & drop'}
                </div>
              </div>
              <Upload className="w-4 h-4 text-[var(--text-tertiary)]" />
            </label>

            {/* Background / Cover Upload Card */}
            <label className="flex items-center gap-3 p-3.5 bg-[var(--bg-secondary)] hover:bg-[var(--bg-tertiary)] border border-dashed border-[var(--border-primary)] hover:border-pink-500/50 rounded-xl cursor-pointer transition-all">
              <input
                type="file"
                accept="image/*"
                onChange={handleBackgroundUpload}
                className="hidden"
              />
              <div className="p-2.5 rounded-lg bg-pink-500/10 text-pink-500">
                <ImageIcon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold text-[var(--text-primary)] truncate">
                  {bgFilename ? bgFilename : 'Pilih Background Image'}
                </div>
                <div className="text-[11px] text-[var(--text-secondary)]">
                  {bgFilename ? 'Kustom terpasang' : 'PNG, JPG, WebP'}
                </div>
              </div>
              <Upload className="w-4 h-4 text-[var(--text-tertiary)]" />
            </label>
          </div>
        </div>

        {/* Right Column: Customization Controls (5 cols) */}
        <div className="lg:col-span-5 bg-[var(--bg-secondary)] border border-[var(--border-primary)] rounded-2xl p-5 space-y-5 shadow-sm">
          {/* Tabs Navigation */}
          <div className="grid grid-cols-4 gap-1 p-1 bg-[var(--bg-tertiary)] rounded-xl text-xs font-semibold">
            <button
              onClick={() => setActiveTab('style')}
              className={`py-2 rounded-lg transition-all ${
                activeTab === 'style'
                  ? 'bg-cyan-500 text-white shadow-sm'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              Style
            </button>
            <button
              onClick={() => setActiveTab('colors')}
              className={`py-2 rounded-lg transition-all ${
                activeTab === 'colors'
                  ? 'bg-cyan-500 text-white shadow-sm'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              Warna
            </button>
            <button
              onClick={() => setActiveTab('visuals')}
              className={`py-2 rounded-lg transition-all ${
                activeTab === 'visuals'
                  ? 'bg-cyan-500 text-white shadow-sm'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              Visual
            </button>
            <button
              onClick={() => setActiveTab('track')}
              className={`py-2 rounded-lg transition-all ${
                activeTab === 'track'
                  ? 'bg-cyan-500 text-white shadow-sm'
                  : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
              }`}
            >
              Info
            </button>
          </div>

          {/* Tab 1: Visualizer Style Selection */}
          {activeTab === 'style' && (
            <div className="space-y-4">
              <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
                Pilih Model Spectrum
              </label>

              <div className="grid grid-cols-2 gap-3">
                {/* Bars Style */}
                <button
                  onClick={() => setConfig((p) => ({ ...p, style: 'bars' }))}
                  className={`flex flex-col items-center gap-2 p-3.5 rounded-xl border text-center transition-all ${
                    config.style === 'bars'
                      ? 'border-cyan-500 bg-cyan-500/10 text-cyan-500 font-bold shadow-sm'
                      : 'border-[var(--border-primary)] bg-[var(--bg-primary)] text-[var(--text-secondary)] hover:border-cyan-500/40'
                  }`}
                >
                  <Activity className="w-6 h-6" />
                  <div>
                    <div className="text-sm">Frequency Bars</div>
                    <div className="text-[11px] opacity-75 font-normal">Batang klasik & modern</div>
                  </div>
                </button>

                {/* Circular Style */}
                <button
                  onClick={() => setConfig((p) => ({ ...p, style: 'circular' }))}
                  className={`flex flex-col items-center gap-2 p-3.5 rounded-xl border text-center transition-all ${
                    config.style === 'circular'
                      ? 'border-cyan-500 bg-cyan-500/10 text-cyan-500 font-bold shadow-sm'
                      : 'border-[var(--border-primary)] bg-[var(--bg-primary)] text-[var(--text-secondary)] hover:border-cyan-500/40'
                  }`}
                >
                  <Disc className="w-6 h-6" />
                  <div>
                    <div className="text-sm">Circular Radial</div>
                    <div className="text-[11px] opacity-75 font-normal">Melingkar 360° + cover</div>
                  </div>
                </button>

                {/* Neon Style */}
                <button
                  onClick={() => setConfig((p) => ({ ...p, style: 'neon' }))}
                  className={`flex flex-col items-center gap-2 p-3.5 rounded-xl border text-center transition-all ${
                    config.style === 'neon'
                      ? 'border-cyan-500 bg-cyan-500/10 text-cyan-500 font-bold shadow-sm'
                      : 'border-[var(--border-primary)] bg-[var(--bg-primary)] text-[var(--text-secondary)] hover:border-cyan-500/40'
                  }`}
                >
                  <Sparkles className="w-6 h-6" />
                  <div>
                    <div className="text-sm">Neon Glow</div>
                    <div className="text-[11px] opacity-75 font-normal">Efek berpijar & partikel</div>
                  </div>
                </button>

                {/* Waveform Style */}
                <button
                  onClick={() => setConfig((p) => ({ ...p, style: 'waveform' }))}
                  className={`flex flex-col items-center gap-2 p-3.5 rounded-xl border text-center transition-all ${
                    config.style === 'waveform'
                      ? 'border-cyan-500 bg-cyan-500/10 text-cyan-500 font-bold shadow-sm'
                      : 'border-[var(--border-primary)] bg-[var(--bg-primary)] text-[var(--text-secondary)] hover:border-cyan-500/40'
                  }`}
                >
                  <Radio className="w-6 h-6" />
                  <div>
                    <div className="text-sm">Waveform Ribbon</div>
                    <div className="text-[11px] opacity-75 font-normal">Oskiloskop halus</div>
                  </div>
                </button>
              </div>

              {/* Bars Count */}
              <div className="space-y-1.5 pt-2">
                <div className="flex justify-between text-xs font-semibold text-[var(--text-primary)]">
                  <span>Kerapatan Batang (Bar Count)</span>
                  <span className="text-cyan-500">{config.barCount} Bins</span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[32, 64, 128, 256].map((count) => (
                    <button
                      key={count}
                      onClick={() => setConfig((p) => ({ ...p, barCount: count }))}
                      className={`py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                        config.barCount === count
                          ? 'border-cyan-500 bg-cyan-500 text-white'
                          : 'border-[var(--border-primary)] bg-[var(--bg-primary)] text-[var(--text-secondary)]'
                      }`}
                    >
                      {count}
                    </button>
                  ))}
                </div>
              </div>

              {/* Position selector for bars/waveform */}
              {config.style !== 'circular' && (
                <div className="space-y-1.5 pt-2">
                  <label className="text-xs font-semibold text-[var(--text-primary)]">
                    Posisi Spektrum
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['bottom', 'center', 'top'] as const).map((pos) => (
                      <button
                        key={pos}
                        onClick={() => setConfig((p) => ({ ...p, position: pos }))}
                        className={`py-1.5 rounded-lg text-xs font-semibold capitalize border transition-all ${
                          config.position === pos
                            ? 'border-cyan-500 bg-cyan-500/15 text-cyan-500'
                            : 'border-[var(--border-primary)] bg-[var(--bg-primary)] text-[var(--text-secondary)]'
                        }`}
                      >
                        {pos}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Colors & Theme Palettes */}
          {activeTab === 'colors' && (
            <div className="space-y-4">
              <label className="text-xs font-bold uppercase tracking-wider text-[var(--text-tertiary)]">
                Preset Palet Warna
              </label>

              <div className="grid grid-cols-2 gap-2.5">
                {(Object.keys(COLOR_SCHEME_PALETTES) as ColorSchemePreset[]).map((key) => {
                  const pal = COLOR_SCHEME_PALETTES[key];
                  const isSelected = config.colorScheme === key;
                  return (
                    <button
                      key={key}
                      onClick={() => handlePaletteSelect(key)}
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'border-cyan-500 bg-cyan-500/10'
                          : 'border-[var(--border-primary)] bg-[var(--bg-primary)] hover:border-cyan-500/40'
                      }`}
                    >
                      <div className="flex -space-x-1.5">
                        <span
                          className="w-4 h-4 rounded-full border border-black/40"
                          style={{ backgroundColor: pal.primary }}
                        />
                        <span
                          className="w-4 h-4 rounded-full border border-black/40"
                          style={{ backgroundColor: pal.secondary }}
                        />
                        <span
                          className="w-4 h-4 rounded-full border border-black/40"
                          style={{ backgroundColor: pal.glow }}
                        />
                      </div>
                      <span className="text-xs font-semibold text-[var(--text-primary)] truncate">
                        {pal.name}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Custom Color Pickers */}
              <div className="pt-3 border-t border-[var(--border-primary)] space-y-3">
                <label className="text-xs font-semibold text-[var(--text-primary)]">
                  Kustomisasi Warna Hex
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <span className="text-[11px] text-[var(--text-secondary)]">Primary</span>
                    <input
                      type="color"
                      value={config.primaryColor}
                      onChange={(e) =>
                        setConfig((p) => ({ ...p, primaryColor: e.target.value, colorScheme: 'custom' }))
                      }
                      className="w-full h-8 rounded-lg cursor-pointer bg-transparent"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-[11px] text-[var(--text-secondary)]">Secondary</span>
                    <input
                      type="color"
                      value={config.secondaryColor}
                      onChange={(e) =>
                        setConfig((p) => ({ ...p, secondaryColor: e.target.value, colorScheme: 'custom' }))
                      }
                      className="w-full h-8 rounded-lg cursor-pointer bg-transparent"
                    />
                  </div>
                  <div className="space-y-1">
                    <span className="text-[11px] text-[var(--text-secondary)]">Glow</span>
                    <input
                      type="color"
                      value={config.glowColor}
                      onChange={(e) =>
                        setConfig((p) => ({ ...p, glowColor: e.target.value, colorScheme: 'custom' }))
                      }
                      className="w-full h-8 rounded-lg cursor-pointer bg-transparent"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Visualizer Parameters & Sliders */}
          {activeTab === 'visuals' && (
            <div className="space-y-4">
              {/* Sensitivity */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-[var(--text-primary)]">
                  <span>Sensitivitas Spektrum</span>
                  <span className="text-cyan-500">{config.sensitivity.toFixed(1)}x</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={3.0}
                  step={0.1}
                  value={config.sensitivity}
                  onChange={(e) =>
                    setConfig((p) => ({ ...p, sensitivity: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              {/* Smoothing Constant */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-[var(--text-primary)]">
                  <span>Kehalusan Gerakan (Smoothing)</span>
                  <span className="text-cyan-500">{config.smoothingTimeConstant.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={0.95}
                  step={0.02}
                  value={config.smoothingTimeConstant}
                  onChange={(e) =>
                    setConfig((p) => ({ ...p, smoothingTimeConstant: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              {/* Background Blur */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-[var(--text-primary)]">
                  <span>Background Blur</span>
                  <span className="text-cyan-500">{config.backgroundBlur}px</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={20}
                  step={1}
                  value={config.backgroundBlur}
                  onChange={(e) =>
                    setConfig((p) => ({ ...p, backgroundBlur: parseInt(e.target.value, 10) }))
                  }
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              {/* Background Overlay Darkness */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-[var(--text-primary)]">
                  <span>Darken Overlay</span>
                  <span className="text-cyan-500">{config.backgroundOverlayDarkness}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={90}
                  step={5}
                  value={config.backgroundOverlayDarkness}
                  onChange={(e) =>
                    setConfig((p) => ({
                      ...p,
                      backgroundOverlayDarkness: parseInt(e.target.value, 10),
                    }))
                  }
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              {/* Toggles */}
              <div className="pt-2 border-t border-[var(--border-primary)] space-y-2.5">
                <label className="flex items-center justify-between text-xs font-semibold text-[var(--text-primary)] cursor-pointer">
                  <span>Refleksi Cermin (Mirror)</span>
                  <input
                    type="checkbox"
                    checked={config.mirror}
                    onChange={(e) => setConfig((p) => ({ ...p, mirror: e.target.checked }))}
                    className="accent-cyan-500 w-4 h-4 rounded"
                  />
                </label>

                <label className="flex items-center justify-between text-xs font-semibold text-[var(--text-primary)] cursor-pointer">
                  <span>Peak Hold Dots</span>
                  <input
                    type="checkbox"
                    checked={config.showPeaks}
                    onChange={(e) => setConfig((p) => ({ ...p, showPeaks: e.target.checked }))}
                    className="accent-cyan-500 w-4 h-4 rounded"
                  />
                </label>

                {config.style === 'circular' && (
                  <label className="flex items-center justify-between text-xs font-semibold text-[var(--text-primary)] cursor-pointer">
                    <span>Bass Pulse Center Cover</span>
                    <input
                      type="checkbox"
                      checked={config.pulseCover}
                      onChange={(e) => setConfig((p) => ({ ...p, pulseCover: e.target.checked }))}
                      className="accent-cyan-500 w-4 h-4 rounded"
                    />
                  </label>
                )}
              </div>
            </div>
          )}

          {/* Tab 4: Track Info & Overlay */}
          {activeTab === 'track' && (
            <div className="space-y-4">
              <label className="flex items-center justify-between text-xs font-semibold text-[var(--text-primary)] cursor-pointer pb-2 border-b border-[var(--border-primary)]">
                <span>Tampilkan Info Teks di Video</span>
                <input
                  type="checkbox"
                  checked={config.showTrackInfo}
                  onChange={(e) => setConfig((p) => ({ ...p, showTrackInfo: e.target.checked }))}
                  className="accent-cyan-500 w-4 h-4 rounded"
                />
              </label>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[var(--text-primary)]">
                  Judul Lagu / Track Title
                </label>
                <input
                  type="text"
                  value={config.trackTitle}
                  onChange={(e) => setConfig((p) => ({ ...p, trackTitle: e.target.value }))}
                  placeholder="Misal: Cyberpunk Odyssey"
                  className="w-full px-3 py-2 text-xs bg-[var(--bg-primary)] border border-[var(--border-primary)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[var(--text-primary)]">
                  Nama Artis / Musisi
                </label>
                <input
                  type="text"
                  value={config.artistName}
                  onChange={(e) => setConfig((p) => ({ ...p, artistName: e.target.value }))}
                  placeholder="Misal: CTools DJ"
                  className="w-full px-3 py-2 text-xs bg-[var(--bg-primary)] border border-[var(--border-primary)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Center Cover Art File Picker */}
              <div className="pt-2">
                <label className="text-xs font-semibold text-[var(--text-primary)] block mb-1.5">
                  Gambar Cover Piringan Disc (Khusus Circular)
                </label>
                <label className="flex items-center gap-3 p-3 bg-[var(--bg-primary)] border border-[var(--border-primary)] hover:border-cyan-500 rounded-lg cursor-pointer transition-colors text-xs text-[var(--text-secondary)]">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleCoverUpload}
                    className="hidden"
                  />
                  <ImageIcon className="w-4 h-4 text-cyan-500" />
                  <span className="truncate">{coverFilename || 'Pilih Logo / Foto Album (1:1)'}</span>
                </label>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Export Progress Modal */}
      {isExporting && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg bg-[var(--bg-secondary)] border border-[var(--border-primary)] rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-cyan-500/10 text-cyan-500">
                  <Radio className="w-6 h-6 animate-spin" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[var(--text-primary)]">
                    Merender Video MP4 1080p
                  </h3>
                  <p className="text-xs text-[var(--text-secondary)]">
                    Resolusi 1920x1080 Full HD @ 30 FPS
                  </p>
                </div>
              </div>
            </div>

            <ProgressBar
              progress={renderProgress.progress}
              statusText={renderProgress.statusText}
            />

            {exportedBlob && exportedUrl ? (
              <div className="space-y-4 pt-2">
                <div className="p-4 rounded-2xl bg-green-500/10 border border-green-500/20 text-green-500 flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 flex-shrink-0" />
                  <div className="text-xs">
                    <div className="font-bold">Video Berhasil Dirender!</div>
                    <div>Ukuran berkas: {formatFileSize(exportedBlob.size)}</div>
                  </div>
                </div>

                <div className="aspect-video rounded-xl overflow-hidden bg-black border border-white/10">
                  <video
                    src={exportedUrl}
                    controls
                    autoPlay
                    className="w-full h-full object-contain"
                  />
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={handleDownloadVideo}
                    className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-white bg-gradient-to-r from-cyan-500 to-pink-500 hover:from-cyan-600 hover:to-pink-600 shadow-lg shadow-cyan-500/20 transition-all"
                  >
                    <Download className="w-5 h-5" />
                    Download MP4 Video
                  </button>
                  <button
                    onClick={() => setIsExporting(false)}
                    className="px-5 py-3 rounded-xl border border-[var(--border-primary)] font-semibold text-[var(--text-secondary)] hover:bg-[var(--bg-tertiary)] transition-colors"
                  >
                    Tutup
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex justify-end pt-2">
                <button
                  onClick={handleCancelExport}
                  className="px-4 py-2 text-xs font-semibold text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                >
                  Batalkan Render
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
