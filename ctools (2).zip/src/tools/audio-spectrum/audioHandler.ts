import { AudioMetadata } from './types';

export class AudioInputHandler {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private audioElement: HTMLAudioElement | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private audioBuffer: AudioBuffer | null = null;
  private audioFile: File | null = null;
  private isPlaying = false;
  private onTimeUpdateCallback: ((time: number, duration: number) => void) | null = null;
  private onEndedCallback: (() => void) | null = null;

  constructor() {
    this.audioElement = new Audio();
    this.audioElement.crossOrigin = 'anonymous';

    this.audioElement.addEventListener('timeupdate', () => {
      if (this.audioElement && this.onTimeUpdateCallback) {
        this.onTimeUpdateCallback(
          this.audioElement.currentTime,
          this.audioElement.duration || 0
        );
      }
    });

    this.audioElement.addEventListener('ended', () => {
      this.isPlaying = false;
      if (this.onEndedCallback) {
        this.onEndedCallback();
      }
    });
  }

  private initAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 512;
      this.analyser.smoothingTimeConstant = 0.8;

      if (this.audioElement) {
        this.sourceNode = this.audioCtx.createMediaElementSource(this.audioElement);
        this.sourceNode.connect(this.analyser);
        this.analyser.connect(this.audioCtx.destination);
      }
    }

    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }

    return this.audioCtx;
  }

  async loadAudioFile(file: File): Promise<AudioMetadata> {
    this.initAudioContext();
    this.audioFile = file;

    const arrayBuffer = await file.arrayBuffer();
    if (!this.audioCtx) throw new Error('AudioContext belum siap');

    // Decode audio data for frame-by-frame rendering
    this.audioBuffer = await this.audioCtx.decodeAudioData(arrayBuffer.slice(0));

    // Setup HTML audio element for real-time preview playback
    if (this.audioElement) {
      const objectUrl = URL.createObjectURL(file);
      this.audioElement.src = objectUrl;
      this.audioElement.load();
    }

    return {
      name: file.name.replace(/\.[^/.]+$/, ''),
      duration: this.audioBuffer.duration,
      sampleRate: this.audioBuffer.sampleRate,
      numberOfChannels: this.audioBuffer.numberOfChannels,
      size: file.size,
    };
  }

  /**
   * Generates a sample electronic melodic beat so the user can test the visualizer immediately
   */
  async loadSampleAudio(): Promise<AudioMetadata> {
    this.initAudioContext();
    if (!this.audioCtx) throw new Error('AudioContext belum siap');

    const sampleRate = 44100;
    const duration = 12; // 12 seconds
    const numSamples = sampleRate * duration;
    const buffer = this.audioCtx.createBuffer(2, numSamples, sampleRate);
    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);

    const bpm = 128;
    const beatSec = 60 / bpm;

    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      const beatPos = (t % beatSec) / beatSec;

      // Kick drum on every beat
      let kick = 0;
      if (beatPos < 0.2) {
        const kickFreq = 150 * Math.exp(-beatPos * 25) + 40;
        kick = Math.sin(2 * Math.PI * kickFreq * beatPos) * Math.exp(-beatPos * 12);
      }

      // Snare / clap on beat 2 and 4
      const beatIndex = Math.floor((t % (beatSec * 4)) / beatSec);
      let snare = 0;
      if ((beatIndex === 1 || beatIndex === 3) && beatPos < 0.25) {
        const noise = (Math.random() * 2 - 1) * Math.exp(-beatPos * 15);
        const tone = Math.sin(2 * Math.PI * 220 * beatPos) * Math.exp(-beatPos * 20);
        snare = noise * 0.7 + tone * 0.3;
      }

      // Hi-hats on off-beats
      let hihat = 0;
      const offbeatPos = (t % (beatSec / 2)) / (beatSec / 2);
      if (offbeatPos < 0.08) {
        hihat = (Math.random() * 2 - 1) * Math.exp(-offbeatPos * 40) * 0.4;
      }

      // Synth chords & melody (C minor arpeggio)
      const chordNotes = [261.63, 311.13, 392.0, 523.25, 466.16];
      const noteIdx = Math.floor((t * 4) % chordNotes.length);
      const synthFreq = chordNotes[noteIdx];
      const synth = Math.sin(2 * Math.PI * synthFreq * t) * 0.25;
      const subBass = Math.sin(2 * Math.PI * (synthFreq / 4) * t) * 0.3;

      const mixed = (kick * 0.9 + snare * 0.6 + hihat * 0.4 + synth * 0.5 + subBass * 0.4) * 0.8;
      left[i] = mixed;
      right[i] = mixed;
    }

    this.audioBuffer = buffer;

    // Convert synthesized buffer to WAV blob for preview element
    const wavBlob = this.audioBufferToWav(buffer);
    const sampleFile = new File([wavBlob], 'Synthwave_Demo_Beat.wav', { type: 'audio/wav' });
    this.audioFile = sampleFile;

    if (this.audioElement) {
      this.audioElement.src = URL.createObjectURL(wavBlob);
      this.audioElement.load();
    }

    return {
      name: 'Cyberpunk Synth Beat (Demo)',
      duration: duration,
      sampleRate: sampleRate,
      numberOfChannels: 2,
      size: wavBlob.size,
    };
  }

  async play(): Promise<void> {
    this.initAudioContext();
    if (this.audioCtx?.state === 'suspended') {
      await this.audioCtx.resume();
    }
    if (this.audioElement) {
      await this.audioElement.play();
      this.isPlaying = true;
    }
  }

  pause(): void {
    if (this.audioElement) {
      this.audioElement.pause();
      this.isPlaying = false;
    }
  }

  seek(time: number): void {
    if (this.audioElement) {
      this.audioElement.currentTime = Math.max(0, Math.min(time, this.audioElement.duration || 0));
    }
  }

  setVolume(vol: number): void {
    if (this.audioElement) {
      this.audioElement.volume = Math.max(0, Math.min(1, vol));
    }
  }

  getFrequencyData(fftSize = 512, smoothing = 0.8): Uint8Array {
    if (!this.analyser) {
      return new Uint8Array(fftSize / 2);
    }
    if (this.analyser.fftSize !== fftSize) {
      this.analyser.fftSize = fftSize;
    }
    this.analyser.smoothingTimeConstant = smoothing;

    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }

  getTimeDomainData(fftSize = 512): Uint8Array {
    if (!this.analyser) {
      return new Uint8Array(fftSize / 2);
    }
    if (this.analyser.fftSize !== fftSize) {
      this.analyser.fftSize = fftSize;
    }
    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteTimeDomainData(dataArray);
    return dataArray;
  }

  getCurrentTime(): number {
    return this.audioElement ? this.audioElement.currentTime : 0;
  }

  getDuration(): number {
    return this.audioBuffer ? this.audioBuffer.duration : this.audioElement?.duration || 0;
  }

  getIsPlaying(): boolean {
    return this.isPlaying;
  }

  getAudioBuffer(): AudioBuffer | null {
    return this.audioBuffer;
  }

  getAudioFile(): File | null {
    return this.audioFile;
  }

  getAudioElement(): HTMLAudioElement | null {
    return this.audioElement;
  }

  getAudioContext(): AudioContext | null {
    return this.audioCtx;
  }

  onTimeUpdate(callback: (time: number, duration: number) => void): void {
    this.onTimeUpdateCallback = callback;
  }

  onEnded(callback: () => void): void {
    this.onEndedCallback = callback;
  }

  destroy(): void {
    if (this.audioElement) {
      this.audioElement.pause();
      this.audioElement.src = '';
    }
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
    }
  }

  /**
   * Helper: Encodes an AudioBuffer into standard 16-bit PCM WAV Blob
   */
  private audioBufferToWav(buffer: AudioBuffer): Blob {
    const numChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const format = 1; // PCM
    const bitDepth = 16;
    const bytesPerSample = bitDepth / 8;
    const blockAlign = numChannels * bytesPerSample;

    const dataLength = buffer.length * blockAlign;
    const bufferLength = 44 + dataLength;

    const arrayBuffer = new ArrayBuffer(bufferLength);
    const view = new DataView(arrayBuffer);

    // RIFF chunk descriptor
    this.writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + dataLength, true);
    this.writeString(view, 8, 'WAVE');

    // FMT sub-chunk
    this.writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, format, true);
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * blockAlign, true);
    view.setUint16(32, blockAlign, true);
    view.setUint16(34, bitDepth, true);

    // DATA sub-chunk
    this.writeString(view, 36, 'data');
    view.setUint32(40, dataLength, true);

    // Write interleaved samples
    let offset = 44;
    for (let i = 0; i < buffer.length; i++) {
      for (let ch = 0; ch < numChannels; ch++) {
        const sample = Math.max(-1, Math.min(1, buffer.getChannelData(ch)[i]));
        const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
        view.setInt16(offset, intSample, true);
        offset += 2;
      }
    }

    return new Blob([arrayBuffer], { type: 'audio/wav' });
  }

  private writeString(view: DataView, offset: number, string: string): void {
    for (let i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }
}
