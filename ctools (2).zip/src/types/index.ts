export type ToolCategory = 'video' | 'audio' | 'image' | 'design' | 'utility';

export interface ToolDefinition {
  id: string;
  name: string;
  shortDescription: string;
  description: string;
  icon: string; // Lucide icon name
  category: ToolCategory;
  badge?: string;
  tags: string[];
  isNew?: boolean;
  requiresFFmpeg?: boolean;
  requiresAI: false;
  path?: string;
  supportedFormats?: string[];
  maxFileSizeMB?: number;
}

export type ThemeMode = 'dark' | 'light' | 'system';

export interface ToastMessage {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message?: string;
  duration?: number;
}

export interface FileMetadata {
  name: string;
  size: number;
  type: string;
  dimensions?: { width: number; height: number };
  duration?: number;
  lastModified?: number;
}

export type ProcessingStep =
  | 'idle'
  | 'preparing'
  | 'loading'
  | 'processing'
  | 'finalizing'
  | 'completed'
  | 'error';

export interface ProcessingState {
  isProcessing: boolean;
  progress: number; // 0 to 100
  statusText: string;
  step?: ProcessingStep;
  error?: string | null;
}

