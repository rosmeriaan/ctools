import React from 'react';

interface ProgressBarProps {
  progress: number; // 0 - 100
  statusText?: string;
  subText?: string;
  className?: string;
  showPercent?: boolean;
  isIndeterminate?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  statusText,
  subText,
  className = '',
  showPercent = true,
  isIndeterminate = false,
}) => {
  const clamped = isIndeterminate ? 100 : Math.min(100, Math.max(0, Math.round(progress)));

  return (
    <div className={`w-full space-y-2 ${className}`}>
      {(statusText || showPercent) && (
        <div className="flex items-center justify-between text-xs sm:text-sm font-medium">
          <span className="text-slate-700 dark:text-slate-300 truncate max-w-[70%]">
            {statusText || 'Memproses...'}
          </span>
          {showPercent && !isIndeterminate && (
            <span className="text-blue-600 dark:text-blue-400 font-bold tabular-nums">
              {clamped}%
            </span>
          )}
        </div>
      )}

      <div className="relative h-2.5 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r from-blue-600 via-indigo-500 to-cyan-400 transition-all duration-200 ease-out rounded-full ${
            isIndeterminate ? 'w-full animate-pulse' : ''
          }`}
          style={{ width: isIndeterminate ? '100%' : `${clamped}%` }}
        />
        {clamped < 100 && !isIndeterminate && (
          <div
            className="absolute inset-0 bg-white/20 dark:bg-white/10 animate-pulse pointer-events-none"
            style={{ width: `${clamped}%` }}
          />
        )}
      </div>

      {subText && (
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          {subText}
        </p>
      )}
    </div>
  );
};
