import React from 'react';
import { LayoutGrid, Film, Music, Palette, Settings } from 'lucide-react';

interface BottomNavProps {
  activeToolId?: string | null;
  onSelectTool: (id: string | null) => void;
  onOpenSettings: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeToolId,
  onSelectTool,
  onOpenSettings,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 lg:hidden bg-white/95 dark:bg-[#0b0f19]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-3 py-1.5 flex items-center justify-around shadow-lg">
      <button
        onClick={() => onSelectTool(null)}
        className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all cursor-pointer ${
          activeToolId === null
            ? 'text-blue-600 dark:text-blue-400 font-bold'
            : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1 rounded-lg transition-transform ${
            activeToolId === null ? 'bg-blue-500/10 scale-110' : ''
          }`}
        >
          <LayoutGrid className="w-5 h-5" />
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight">Beranda</span>
      </button>

      <button
        onClick={() => onSelectTool('video-cutter')}
        className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all cursor-pointer ${
          activeToolId?.startsWith('video-')
            ? 'text-blue-600 dark:text-blue-400 font-bold'
            : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1 rounded-lg transition-transform ${
            activeToolId?.startsWith('video-') ? 'bg-blue-500/10 scale-110' : ''
          }`}
        >
          <Film className="w-5 h-5" />
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight">Video</span>
      </button>

      <button
        onClick={() => onSelectTool('mp4-to-mp3')}
        className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all cursor-pointer ${
          activeToolId === 'mp4-to-mp3' || activeToolId?.startsWith('audio-') || activeToolId?.includes('bpm') || activeToolId?.includes('beat')
            ? 'text-blue-600 dark:text-blue-400 font-bold'
            : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1 rounded-lg transition-transform ${
            activeToolId === 'mp4-to-mp3' || activeToolId?.startsWith('audio-') || activeToolId?.includes('bpm') || activeToolId?.includes('beat')
              ? 'bg-blue-500/10 scale-110'
              : ''
          }`}
        >
          <Music className="w-5 h-5" />
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight">Audio</span>
      </button>

      <button
        onClick={() => onSelectTool('easing-visualizer')}
        className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all cursor-pointer ${
          activeToolId === 'easing-visualizer' || activeToolId === 'text-to-png' || activeToolId === 'safe-zone' || activeToolId === 'lut-previewer'
            ? 'text-blue-600 dark:text-blue-400 font-bold'
            : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
        }`}
      >
        <div
          className={`p-1 rounded-lg transition-transform ${
            activeToolId === 'easing-visualizer' || activeToolId === 'text-to-png' || activeToolId === 'safe-zone' || activeToolId === 'lut-previewer'
              ? 'bg-blue-500/10 scale-110'
              : ''
          }`}
        >
          <Palette className="w-5 h-5" />
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight">Motion</span>
      </button>

      <button
        onClick={onOpenSettings}
        className="flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all cursor-pointer text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
      >
        <div className="p-1 rounded-lg">
          <Settings className="w-5 h-5" />
        </div>
        <span className="text-[10px] mt-0.5 tracking-tight">Pengaturan</span>
      </button>
    </nav>
  );
};
