import React from 'react';
import { ShieldCheck, Lock } from 'lucide-react';

interface PrivacyBadgeProps {
  compact?: boolean;
  className?: string;
}

export const PrivacyBadge: React.FC<PrivacyBadgeProps> = ({
  compact = false,
  className = '',
}) => {
  if (compact) {
    return (
      <div
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 ${className}`}
        title="File diproses langsung di browser Anda. Tidak ada data yang dikirim ke server."
      >
        <ShieldCheck className="w-3.5 h-3.5" />
        <span>100% Local & Private</span>
      </div>
    );
  }

  return (
    <div
      className={`flex items-center gap-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-xs sm:text-sm ${className}`}
    >
      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center shrink-0 text-emerald-600 dark:text-emerald-400">
        <Lock className="w-4 h-4" />
      </div>
      <div>
        <p className="font-semibold text-emerald-950 dark:text-emerald-200">
          Privasi Terjamin: Pemrosesan Lokal di Browser
        </p>
        <p className="text-emerald-700 dark:text-emerald-400/90 text-xs mt-0.5">
          File Anda diproses secara mandiri di perangkat Anda tanpa diunggah ke server mana pun.
        </p>
      </div>
    </div>
  );
};
