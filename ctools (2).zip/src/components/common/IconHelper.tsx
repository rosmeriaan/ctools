import React from 'react';
import {
  Eraser,
  Rewind,
  Music2,
  QrCode,
  Wrench,
  Sparkles,
  Sliders,
  CheckCircle,
  AlertCircle,
  Info,
  Clock,
  Layers,
  FileText,
  Settings,
  HelpCircle,
  Sun,
  Moon,
  Laptop,
  ArrowLeft,
  Download,
  RotateCcw,
  RotateCw,
  Upload,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Maximize2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RefreshCw,
  Search,
  Grid,
  ChevronRight,
  Zap,
  Trash2,
  Scissors,
  Minimize2,
  Gauge,
  FlipHorizontal,
  Crop,
  Film,
  FileImage,
  Images,
  Activity,
  Bookmark,
  Type,
  Pipette,
  Palette,
  FileCode,
  FileJson,
  Star,
  Flame,
  Radio,
  FileArchive,
  Eye,
  LucideProps,
} from 'lucide-react';

interface DynamicIconProps extends LucideProps {
  name: string;
}

export const DynamicIcon: React.FC<DynamicIconProps> = ({ name, ...props }) => {
  switch (name) {
    case 'Eraser':
      return <Eraser {...props} />;
    case 'Rewind':
      return <Rewind {...props} />;
    case 'Music2':
    case 'Music':
      return <Music2 {...props} />;
    case 'QrCode':
      return <QrCode {...props} />;
    case 'Sparkles':
      return <Sparkles {...props} />;
    case 'Sliders':
      return <Sliders {...props} />;
    case 'Layers':
      return <Layers {...props} />;
    case 'FileText':
      return <FileText {...props} />;
    case 'Settings':
      return <Settings {...props} />;
    case 'Zap':
      return <Zap {...props} />;
    case 'Scissors':
      return <Scissors {...props} />;
    case 'Minimize2':
    case 'FileArchive':
      return <Minimize2 {...props} />;
    case 'Gauge':
      return <Gauge {...props} />;
    case 'FlipHorizontal':
      return <FlipHorizontal {...props} />;
    case 'RotateCw':
      return <RotateCw {...props} />;
    case 'RotateCcw':
      return <RotateCcw {...props} />;
    case 'Crop':
      return <Crop {...props} />;
    case 'Film':
      return <Film {...props} />;
    case 'FileImage':
      return <FileImage {...props} />;
    case 'Images':
      return <Images {...props} />;
    case 'VolumeX':
      return <VolumeX {...props} />;
    case 'Volume2':
      return <Volume2 {...props} />;
    case 'Activity':
      return <Activity {...props} />;
    case 'Bookmark':
      return <Bookmark {...props} />;
    case 'Type':
      return <Type {...props} />;
    case 'Pipette':
      return <Pipette {...props} />;
    case 'Palette':
      return <Palette {...props} />;
    case 'FileCode':
      return <FileCode {...props} />;
    case 'FileJson':
      return <FileJson {...props} />;
    case 'Eye':
      return <Eye {...props} />;
    case 'Star':
      return <Star {...props} />;
    default:
      return <Wrench {...props} />;
  }
};

export {
  Eraser,
  Rewind,
  Music2,
  QrCode,
  Wrench,
  Sparkles,
  Sliders,
  CheckCircle,
  AlertCircle,
  Info,
  Clock,
  Layers,
  FileText,
  Settings,
  HelpCircle,
  Sun,
  Moon,
  Laptop,
  ArrowLeft,
  Download,
  RotateCcw,
  RotateCw,
  Upload,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Maximize2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RefreshCw,
  Search,
  Grid,
  ChevronRight,
  Zap,
  Trash2,
  Scissors,
  Minimize2,
  Gauge,
  FlipHorizontal,
  Crop,
  Film,
  FileImage,
  Images,
  Activity,
  Bookmark,
  Type,
  Pipette,
  Palette,
  FileCode,
  FileJson,
  Star,
  Flame,
  Radio,
  FileArchive,
  Eye,
};
