import React from 'react';
import { ToolDefinition } from '../../types';
import { DynamicIcon } from './IconHelper';
import { ArrowRight, Sparkles, Star } from 'lucide-react';
import { isFavorite, toggleFavorite } from '../../utils/favorites';

interface ToolCardProps {
  tool: ToolDefinition;
  onOpen: (id: string) => void;
  isActive?: boolean;
  onFavoriteToggle?: () => void;
}

export const ToolCard: React.FC<ToolCardProps> = ({
  tool,
  onOpen,
  isActive = false,
  onFavoriteToggle,
}) => {
  const [favorite, setFavorite] = React.useState<boolean>(() => isFavorite(tool.id));

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = toggleFavorite(tool.id);
    setFavorite(updated.includes(tool.id));
    onFavoriteToggle?.();
  };

  return (
    <div
      onClick={() => onOpen(tool.id)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onOpen(tool.id);
        }
      }}
      className={`group relative p-5 sm:p-6 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col justify-between text-left border ${
        isActive
          ? 'border-blue-500 bg-blue-500/5 dark:bg-blue-950/30 shadow-md shadow-blue-500/10 ring-1 ring-blue-500'
          : 'border-slate-200/90 dark:border-slate-800 bg-white dark:bg-slate-900/90 hover:border-blue-500/40 dark:hover:border-slate-700 hover:shadow-xl hover:shadow-slate-200/50 dark:hover:shadow-black/50 dark:hover:bg-slate-800/50 hover:-translate-y-0.5'
      }`}
    >
      <div>
        <div className="flex items-start justify-between gap-3 mb-4">
          <div
            className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-200 ${
              isActive
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'bg-blue-500/10 text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white group-hover:shadow-md group-hover:shadow-blue-600/20'
            }`}
          >
            <DynamicIcon name={tool.icon} className="w-6 h-6" />
          </div>

          <div className="flex items-center gap-1.5">
            {tool.badge && (
              <span className="px-2 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                {tool.badge}
              </span>
            )}
            {tool.isNew && (
              <span className="px-2 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5" />
                New
              </span>
            )}
            <button
              onClick={handleFavoriteClick}
              title={favorite ? 'Hapus dari Favorit' : 'Tambah ke Favorit'}
              className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                favorite
                  ? 'border-amber-400/50 bg-amber-400/10 text-amber-500'
                  : 'border-transparent text-slate-300 dark:text-slate-600 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Star className={`w-4 h-4 ${favorite ? 'fill-amber-400 text-amber-400' : ''}`} />
            </button>
          </div>
        </div>

        <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
          {tool.name}
        </h3>

        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed line-clamp-2">
          {tool.shortDescription}
        </p>

        {tool.tags && tool.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-3.5">
            {tool.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-medium"
              >
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-blue-400">
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          Runs locally
        </span>
        <div className="flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
          <span>Buka</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </div>
      </div>
    </div>
  );
};

