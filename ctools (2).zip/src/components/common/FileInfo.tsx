import React from 'react';
import { FileMetadata } from '../../types';
import { formatFileSize, formatDuration, formatDimensions } from '../../utils/formatters';
import { FileText, Film, Image as ImageIcon, Music, X } from 'lucide-react';

interface FileInfoProps {
  metadata: FileMetadata;
  onClear?: () => void;
  className?: string;
}

export const FileInfo: React.FC<FileInfoProps> = ({
  metadata,
  onClear,
  className = '',
}) => {
  const getIcon = () => {
    if (metadata.type.startsWith('video/')) return <Film className="w-5 h-5 text-indigo-500" />;
    if (metadata.type.startsWith('image/')) return <ImageIcon className="w-5 h-5 text-emerald-500" />;
    if (metadata.type.startsWith('audio/')) return <Music className="w-5 h-5 text-amber-500" />;
    return <FileText className="w-5 h-5 text-blue-500" />;
  };

  return (
    <div
      className={`flex items-center justify-between p-3.5 bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl ${className}`}
    >
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-10 h-10 rounded-lg bg-white dark:bg-slate-900 flex items-center justify-center shrink-0 shadow-xs border border-slate-200/50 dark:border-slate-700/50">
          {getIcon()}
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-slate-800 dark:text-slate-100 text-sm truncate" title={metadata.name}>
            {metadata.name}
          </p>
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex-wrap">
            <span className="font-medium text-slate-700 dark:text-slate-300">
              {formatFileSize(metadata.size)}
            </span>
            {metadata.dimensions && (
              <>
                <span>•</span>
                <span>{formatDimensions(metadata.dimensions.width, metadata.dimensions.height)}</span>
              </>
            )}
            {metadata.duration !== undefined && metadata.duration > 0 && (
              <>
                <span>•</span>
                <span>{formatDuration(metadata.duration)}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {onClear && (
        <button
          onClick={onClear}
          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 dark:hover:bg-rose-500/20 transition-colors ml-2 shrink-0 cursor-pointer"
          title="Hapus / ganti file"
          aria-label="Hapus file"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
