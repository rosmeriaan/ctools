import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { ThemeMode } from '../../types';
import {
  X,
  Sun,
  Moon,
  Laptop,
  ShieldCheck,
  Cpu,
  Layers,
  Sparkles,
  Info,
  Check,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { theme, setTheme } = useTheme();

  if (!isOpen) return null;

  const themes: { id: ThemeMode; label: string; icon: React.ReactNode }[] = [
    { id: 'dark', label: 'Dark Mode', icon: <Moon className="w-4 h-4" /> },
    { id: 'light', label: 'Light Mode', icon: <Sun className="w-4 h-4" /> },
    { id: 'system', label: 'Sistem', icon: <Laptop className="w-4 h-4" /> },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-6 z-10 max-h-[90vh] overflow-y-auto"
        >
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 dark:text-slate-100 text-lg">
                  Pengaturan CTools
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Preferensi tampilan dan informasi sistem
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6 py-4">
            {/* Theme Selector */}
            <div className="space-y-2.5">
              <label className="text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400">
                Tema Tampilan
              </label>
              <div className="grid grid-cols-3 gap-2">
                {themes.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTheme(t.id)}
                    className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                      theme === t.id
                        ? 'border-blue-600 bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-2 ring-blue-500/20'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    {t.icon}
                    <span>{t.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Privacy Section */}
            <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-2">
              <div className="flex items-center gap-2 text-emerald-800 dark:text-emerald-300 font-semibold text-sm">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Privasi Data & Arsitektur Zero-Upload</span>
              </div>
              <p className="text-xs text-emerald-700 dark:text-emerald-400/90 leading-relaxed">
                Semua alat multimedia (Background Eraser, Video Reverse, MP4 to MP3, QR Generator) diproses <strong>100% di dalam peramban web Anda</strong> menggunakan Web Audio API, Canvas 2D, dan modul encoder lokal. Tidak ada gambar, rekaman suara, atau video yang ditransfer ke server eksternal.
              </p>
            </div>

            {/* Architecture Info */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-slate-800 dark:text-slate-200 font-semibold text-sm">
                <Layers className="w-4 h-4 text-blue-500" />
                <span>Modular Multi-File Architecture</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                CTools dibangun dengan sistem registry terisolasi. Penambahan alat baru (seperti Image Compressor, Video Trimmer, atau Audio Cutter) dapat dilakukan secara modular tanpa mengubah inti aplikasi.
              </p>
            </div>

            {/* Version */}
            <div className="flex items-center justify-between text-xs text-slate-400 dark:text-slate-500 pt-2">
              <span>CTools v1.0.0</span>
              <span>Fast • Private • Multi-Toolbox</span>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors shadow-md shadow-blue-600/20 cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
