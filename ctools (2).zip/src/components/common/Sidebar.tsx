import React, { useState } from 'react';
import { TOOLS_REGISTRY, CATEGORIES } from '../../registry/tools';
import { ToolCategory } from '../../types';
import { DynamicIcon } from './IconHelper';
import {
  LayoutGrid,
  ShieldCheck,
  X,
  Layers,
  Search,
} from 'lucide-react';

interface SidebarProps {
  activeToolId?: string | null;
  onSelectTool: (id: string | null) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeToolId,
  onSelectTool,
  isOpen,
  onClose,
}) => {
  const [filterQuery, setFilterQuery] = useState<string>('');

  const handleSelect = (id: string | null) => {
    onSelectTool(id);
    onClose();
  };

  const filteredTools = TOOLS_REGISTRY.filter(
    (t) =>
      t.name.toLowerCase().includes(filterQuery.toLowerCase()) ||
      t.category.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 w-72 bg-white dark:bg-[#0f172a] border-r border-slate-200 dark:border-slate-800 p-4 flex flex-col justify-between transition-transform duration-300 lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between pb-3.5 mb-2.5 border-b border-slate-100 dark:border-slate-800/80">
            <div
              onClick={() => handleSelect(null)}
              className="flex items-center gap-2.5 cursor-pointer"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-sm shadow-blue-500/20">
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <span className="font-extrabold text-base tracking-tight text-slate-900 dark:text-slate-100">
                  CTools
                </span>
                <span className="text-[10px] text-blue-500 font-bold ml-1.5 px-1.5 py-0.2 rounded-md bg-blue-500/10">
                  Non-AI
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Filter in Sidebar */}
          <div className="mb-2.5 relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="Cari tool..."
              className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 text-slate-900 dark:text-slate-100 focus:outline-hidden focus:border-blue-500"
            />
          </div>

          {/* Navigation Links */}
          <div className="flex-1 overflow-y-auto space-y-4 pr-1 -mr-1">
            {/* Home / Overview */}
            <div>
              <button
                onClick={() => handleSelect(null)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeToolId === null
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/25'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60'
                }`}
              >
                <LayoutGrid className="w-4 h-4" />
                <span className="flex-1 text-left">Semua Tools</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-black/10 dark:bg-white/10 text-inherit">
                  {TOOLS_REGISTRY.length}
                </span>
              </button>
            </div>

            {/* Categorized Tools List */}
            {CATEGORIES.map((cat) => {
              const catTools = filteredTools.filter((t) => t.category === cat.id);
              if (catTools.length === 0) return null;

              return (
                <div key={cat.id} className="space-y-1">
                  <div className="flex items-center justify-between px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    <span className="flex items-center gap-1.5">
                      <span>{cat.emoji}</span>
                      <span>{cat.name}</span>
                    </span>
                    <span className="text-[10px]">{catTools.length}</span>
                  </div>

                  <div className="space-y-0.5 pt-0.5">
                    {catTools.map((tool) => {
                      const isActive = activeToolId === tool.id;
                      return (
                        <button
                          key={tool.id}
                          onClick={() => handleSelect(tool.id)}
                          className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all text-left cursor-pointer group ${
                            isActive
                              ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400 font-semibold ring-1 ring-blue-500/30'
                              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                          }`}
                        >
                          <div
                            className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                              isActive
                                ? 'bg-blue-600 text-white shadow-xs'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 group-hover:text-blue-500'
                            }`}
                          >
                            <DynamicIcon name={tool.icon} className="w-3.5 h-3.5" />
                          </div>
                          <span className="flex-1 truncate">{tool.name}</span>
                          {tool.badge && (
                            <span className="text-[9px] px-1 py-0.2 rounded font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 shrink-0">
                              {tool.badge}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer inside sidebar */}
          <div className="pt-2.5 mt-2 border-t border-slate-100 dark:border-slate-800/80">
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/60 dark:border-slate-700/40 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span className="leading-tight">
                100% Client-side. File Anda tetap di perangkat.
              </span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

