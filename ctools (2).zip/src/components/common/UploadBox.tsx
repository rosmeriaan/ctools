import React, { useRef, useState, useCallback } from 'react';
import { Upload, FileUp, AlertCircle, CheckCircle2 } from 'lucide-react';
import { validateFile } from '../../utils/file';
import { toast } from '../../utils/toast';

interface UploadBoxProps {
  onFileSelect: (file: File) => void;
  accept?: string;
  allowedTypes?: string[];
  maxSizeMB?: number;
  title?: string;
  subtitle?: string;
  description?: string;
  icon?: React.ReactNode;
  allowPaste?: boolean;
  className?: string;
}

export const UploadBox: React.FC<UploadBoxProps> = ({
  onFileSelect,
  accept,
  allowedTypes,
  maxSizeMB = 50,
  title = 'Tarik & lepas file ke sini',
  subtitle,
  description,
  icon,
  allowPaste = true,
  className = '',
}) => {
  const displaySubtitle = description || subtitle || 'atau klik untuk memilih file dari perangkat';
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback(
    (file: File) => {
      const validation = validateFile(file, allowedTypes, maxSizeMB);
      if (!validation.valid) {
        toast.error('Gagal Memilih File', validation.error);
        return;
      }
      onFileSelect(file);
    },
    [allowedTypes, maxSizeMB, onFileSelect]
  );

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
      // Reset input value so re-selecting same file fires change
      e.target.value = '';
    }
  };

  const handlePaste = useCallback(
    (e: React.ClipboardEvent<HTMLDivElement>) => {
      if (!allowPaste) return;
      const items = e.clipboardData.items;
      for (let i = 0; i < items.length; i++) {
        if (items[i].kind === 'file') {
          const file = items[i].getAsFile();
          if (file) {
            processFile(file);
            toast.info('File Ditempel', `Membaca file dari clipboard: ${file.name || 'image'}`);
            break;
          }
        }
      }
    },
    [allowPaste, processFile]
  );

  const formattedFormats = allowedTypes
    ? allowedTypes
        .map((t) => t.replace('image/', '').replace('video/', '').replace('audio/', '').toUpperCase())
        .join(', ')
    : 'Semua file';

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onPaste={handlePaste}
      onClick={() => fileInputRef.current?.click()}
      tabIndex={0}
      role="button"
      aria-label="Upload File"
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          fileInputRef.current?.click();
        }
      }}
      className={`relative group cursor-pointer border-2 border-dashed rounded-2xl p-6 sm:p-10 transition-all duration-200 text-center flex flex-col items-center justify-center gap-4 outline-hidden focus-visible:ring-2 focus-visible:ring-blue-500 ${
        isDragging
          ? 'border-blue-500 bg-blue-500/10 scale-[1.01]'
          : 'border-slate-300 dark:border-slate-700 bg-white/60 dark:bg-slate-900/60 hover:border-blue-500/70 hover:bg-slate-50 dark:hover:bg-slate-800/40'
      } ${className}`}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept={accept}
        onChange={handleInputChange}
        className="hidden"
      />

      <div
        className={`w-16 h-16 sm:w-20 sm:h-20 rounded-2xl flex items-center justify-center transition-transform duration-200 group-hover:scale-105 ${
          isDragging
            ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/25'
            : 'bg-blue-500/10 text-blue-600 dark:text-blue-400 group-hover:bg-blue-500/20'
        }`}
      >
        {icon || <FileUp className="w-8 h-8 sm:w-10 sm:h-10" />}
      </div>

      <div className="space-y-1 max-w-sm">
        <p className="font-semibold text-slate-800 dark:text-slate-100 text-base sm:text-lg">
          {title}
        </p>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          {displaySubtitle}
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-[11px] text-slate-500 dark:text-slate-400">
        <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-medium">
          Format: {formattedFormats}
        </span>
        <span className="px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-medium">
          Maks: {maxSizeMB} MB
        </span>
        {allowPaste && (
          <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-400">
            Ctrl+V paste didukung
          </span>
        )}
      </div>
    </div>
  );
};
