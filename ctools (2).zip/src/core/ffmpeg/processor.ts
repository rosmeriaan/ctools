import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile } from '@ffmpeg/util';
import { getFFmpeg } from './loader';
import { cleanupFFmpegFiles } from './cleanup';

export interface FFmpegProcessOptions {
  inputs: { name: string; data: File | Blob | Uint8Array }[];
  outputName: string;
  outputMime: string;
  args: string[];
  onProgress?: (progress: number) => void;
  onStatus?: (status: string) => void;
}

export async function runFFmpegProcess(options: FFmpegProcessOptions): Promise<Blob> {
  const { inputs, outputName, outputMime, args, onProgress, onStatus } = options;

  onStatus?.('Memuat engine FFmpeg WebAssembly...');
  const ffmpeg: FFmpeg = await getFFmpeg();

  // Attach progress listener
  const progressHandler = ({ progress }: { progress: number; time: number }) => {
    // progress is 0 to 1
    const p = Math.max(0, Math.min(100, Math.round(progress * 100)));
    onProgress?.(p);
  };
  ffmpeg.on('progress', progressHandler);

  const filenamesToClean: string[] = [...inputs.map((i) => i.name), outputName];

  try {
    onStatus?.('Menyiapkan berkas input...');
    for (const input of inputs) {
      const data =
        input.data instanceof Uint8Array
          ? input.data
          : await fetchFile(input.data);
      await ffmpeg.writeFile(input.name, data);
    }

    onStatus?.('Memproses file video/audio...');
    const exitCode = await ffmpeg.exec(args);
    if (exitCode !== 0) {
      throw new Error('Gagal memproses video. Format atau codec video mungkin tidak didukung oleh memori browser.');
    }

    onStatus?.('Membaca berkas hasil...');
    const resultData = await ffmpeg.readFile(outputName);
    const blob = new Blob([resultData as Uint8Array], { type: outputMime });

    return blob;
  } finally {
    ffmpeg.off('progress', progressHandler);
    await cleanupFFmpegFiles(ffmpeg, filenamesToClean);
  }
}
