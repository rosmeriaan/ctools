import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';

let ffmpegInstance: FFmpeg | null = null;
let isLoading = false;
let loadPromise: Promise<FFmpeg> | null = null;

export async function getFFmpeg(onLog?: (msg: string) => void): Promise<FFmpeg> {
  if (ffmpegInstance && ffmpegInstance.loaded) {
    return ffmpegInstance;
  }

  if (isLoading && loadPromise) {
    return loadPromise;
  }

  isLoading = true;
  loadPromise = (async () => {
    try {
      const ffmpeg = new FFmpeg();

      if (onLog) {
        ffmpeg.on('log', ({ message }) => {
          onLog(message);
        });
      }

      // Load FFmpeg WebAssembly core from unpkg with jsdelivr fallback
      const cdnList = [
        'https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm',
        'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/esm',
      ];

      let loaded = false;
      let lastErr: any = null;

      for (const baseURL of cdnList) {
        try {
          await ffmpeg.load({
            coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
            wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
          });
          loaded = true;
          break;
        } catch (e) {
          console.warn(`Failed loading FFmpeg from ${baseURL}, trying fallback...`, e);
          lastErr = e;
        }
      }

      if (!loaded) {
        throw lastErr || new Error('Gagal memuat engine WebAssembly FFmpeg.');
      }

      ffmpegInstance = ffmpeg;
      return ffmpeg;
    } catch (err) {
      console.error('Failed to load FFmpeg WebAssembly:', err);
      ffmpegInstance = null;
      throw new Error(
        'Gagal memuat engine FFmpeg WebAssembly di browser Anda. Pastikan koneksi internet aktif untuk initial load atau gunakan fallback Web APIs.'
      );
    } finally {
      isLoading = false;
    }
  })();

  return loadPromise;
}

export function isFFmpegLoaded(): boolean {
  return !!ffmpegInstance && ffmpegInstance.loaded;
}
