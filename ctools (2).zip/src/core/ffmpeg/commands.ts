export class FFmpegCommands {
  static cutVideo(
    inputName: string,
    outputName: string,
    startSec: number,
    durationSec: number
  ): string[] {
    return [
      '-ss',
      startSec.toString(),
      '-i',
      inputName,
      '-t',
      durationSec.toString(),
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-c:a',
      'aac',
      '-strict',
      'experimental',
      outputName,
    ];
  }

  static compressVideo(
    inputName: string,
    outputName: string,
    scale?: string, // e.g. "1280:720", "-2:720", "1920:1080"
    fps?: number,
    crf: number = 28 // 18 = high quality, 28 = medium, 35 = small
  ): string[] {
    const vf: string[] = [];
    if (scale && scale !== 'original') {
      vf.push(`scale=${scale}`);
    }
    if (fps && fps > 0) {
      vf.push(`fps=${fps}`);
    }

    const args = ['-i', inputName, '-c:v', 'libx264', '-crf', crf.toString(), '-preset', 'ultrafast'];

    if (vf.length > 0) {
      args.push('-vf', vf.join(','));
    }

    args.push('-c:a', 'aac', '-b:a', '128k', outputName);
    return args;
  }

  static speedVideo(
    inputName: string,
    outputName: string,
    speed: number
  ): string[] {
    // Video filter: setpts=(1/speed)*PTS
    const setpts = (1 / speed).toFixed(4);
    
    // Audio filter: atempo (supports 0.5 to 2.0 per filter instance)
    let atempoFilter = '';
    if (speed >= 0.5 && speed <= 2.0) {
      atempoFilter = `atempo=${speed.toFixed(2)}`;
    } else if (speed < 0.5) {
      atempoFilter = `atempo=0.5,atempo=${(speed / 0.5).toFixed(2)}`;
    } else {
      atempoFilter = `atempo=2.0,atempo=${(speed / 2.0).toFixed(2)}`;
    }

    return [
      '-i',
      inputName,
      '-filter_complex',
      `[0:v]setpts=${setpts}*PTS[v];[0:a]${atempoFilter}[a]`,
      '-map',
      '[v]',
      '-map',
      '[a]',
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-c:a',
      'aac',
      outputName,
    ];
  }

  static mirrorVideo(
    inputName: string,
    outputName: string,
    mode: 'horizontal' | 'vertical' | 'both'
  ): string[] {
    let vf = 'hflip';
    if (mode === 'vertical') vf = 'vflip';
    if (mode === 'both') vf = 'hflip,vflip';

    return [
      '-i',
      inputName,
      '-vf',
      vf,
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-c:a',
      'copy',
      outputName,
    ];
  }

  static rotateVideo(
    inputName: string,
    outputName: string,
    degrees: 90 | 180 | 270
  ): string[] {
    let vf = 'transpose=1'; // 90 clockwise
    if (degrees === 180) vf = 'hflip,vflip';
    if (degrees === 270) vf = 'transpose=2'; // 90 counter-clockwise / 270

    return [
      '-i',
      inputName,
      '-vf',
      vf,
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      '-c:a',
      'copy',
      outputName,
    ];
  }

  static videoToGif(
    inputName: string,
    outputName: string,
    startSec: number,
    durationSec: number,
    fps: number = 15,
    width: number = 480
  ): string[] {
    const vf = `fps=${fps},scale=${width}:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse`;
    return [
      '-ss',
      startSec.toString(),
      '-t',
      durationSec.toString(),
      '-i',
      inputName,
      '-vf',
      vf,
      outputName,
    ];
  }

  static gifToVideo(
    inputName: string,
    outputName: string,
    fps: number = 30
  ): string[] {
    return [
      '-i',
      inputName,
      '-movflags',
      'faststart',
      '-pix_fmt',
      'yuv420p',
      '-vf',
      `scale=trunc(iw/2)*2:trunc(ih/2)*2,fps=${fps}`,
      '-c:v',
      'libx264',
      '-preset',
      'ultrafast',
      outputName,
    ];
  }

  static removeAudio(inputName: string, outputName: string): string[] {
    return ['-i', inputName, '-an', '-c:v', 'copy', outputName];
  }

  static cutAudio(
    inputName: string,
    outputName: string,
    startSec: number,
    durationSec: number
  ): string[] {
    return [
      '-ss',
      startSec.toString(),
      '-i',
      inputName,
      '-t',
      durationSec.toString(),
      '-c:a',
      'libmp3lame',
      '-q:a',
      '2',
      outputName,
    ];
  }

  static changeAudioVolume(
    inputName: string,
    outputName: string,
    volumeMultiplier: number
  ): string[] {
    return [
      '-i',
      inputName,
      '-filter:a',
      `volume=${volumeMultiplier.toFixed(2)}`,
      '-c:a',
      'libmp3lame',
      '-q:a',
      '2',
      outputName,
    ];
  }

  static muxAudioVideo(
    videoInput: string,
    audioInput: string,
    outputName: string,
    durationSec?: number
  ): string[] {
    const args = [
      '-i',
      videoInput,
      '-i',
      audioInput,
      '-c:v',
      'libx264',
      '-pix_fmt',
      'yuv420p',
      '-preset',
      'ultrafast',
      '-c:a',
      'aac',
      '-b:a',
      '192k',
      '-shortest',
    ];
    if (durationSec && durationSec > 0) {
      args.push('-t', durationSec.toString());
    }
    args.push(outputName);
    return args;
  }
}
