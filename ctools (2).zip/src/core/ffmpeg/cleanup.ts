import { FFmpeg } from '@ffmpeg/ffmpeg';

export async function cleanupFFmpegFiles(ffmpeg: FFmpeg, filenames: string[]): Promise<void> {
  for (const filename of filenames) {
    try {
      await ffmpeg.deleteFile(filename);
    } catch {
      // file might not exist, silently ignore
    }
  }
}
