/**
 * Alight Motion Built-in Effect Registry & Factory
 * Fully verified from native Alight Motion 5.0.273 exports.
 */

import { AMEffect } from './types';
import { VERIFIED_EFFECT_IDS } from './constants';

export interface EffectTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  createDefault: () => AMEffect;
}

export const EFFECT_TEMPLATES: EffectTemplate[] = [
  {
    id: VERIFIED_EFFECT_IDS.MOTION_BLUR,
    name: 'Motion Blur (Buram Gerak)',
    category: 'Blur',
    description: 'Menambahkan efek blur dinamis saat objek bergerak atau berputar',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.MOTION_BLUR,
      locallyApplied: false,
      properties: [
        { name: 'tune', type: 'float', value: '1.000000' },
        { name: 'usePos', type: 'bool', value: 'true' },
        { name: 'useScale', type: 'bool', value: 'true' },
        { name: 'useAngle', type: 'bool', value: 'true' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.EXPOSURE,
    name: 'Exposure / Gamma (Pencahayaan)',
    category: 'Color & Light',
    description: 'Mengatur intensitas exposure, gamma, dan offset',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.EXPOSURE,
      locallyApplied: false,
      properties: [
        { name: 'exposure', type: 'float', value: '0.500000' },
        { name: 'gamma', type: 'float', value: '1.000000' },
        { name: 'offset', type: 'float', value: '0.000000' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.SATURATION_VIBRANCE,
    name: 'Saturation & Vibrance (Saturasi)',
    category: 'Color & Light',
    description: 'Meningkatkan kejernihan warna atau membuat hitam putih',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.SATURATION_VIBRANCE,
      locallyApplied: false,
      properties: [
        { name: 'saturation', type: 'float', value: '0.000000' },
        { name: 'vib', type: 'float', value: '1.000000' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.NOISE,
    name: 'Noise 3 (Grain & Noise)',
    category: 'Distortion',
    description: 'Tekstur butiran film retro atau grain',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.NOISE,
      locallyApplied: false,
      properties: [
        { name: 'amount', type: 'float', value: '0.120000' },
        { name: 'mono', type: 'bool', value: 'false' },
        { name: 'freeze', type: 'bool', value: 'false' },
        { name: 'extremes', type: 'bool', value: 'false' },
        { name: 'overshoot', type: 'float', value: '2.000000' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.FLIP_3D,
    name: 'Flip 3D (Balik 3D)',
    category: '3D',
    description: 'Rotasi ruang 3D pada sumbu X/Y dengan depth & bayangan',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.FLIP_3D,
      locallyApplied: false,
      properties: [
        { name: 'angle', type: 'float', value: '0.000000' },
        { name: 'axis', type: 'float', value: '90.000000' },
        { name: 'crop', type: 'float', value: '1.000000' },
        { name: 'zdist', type: 'float', value: '0.000000' },
        { name: 'solid', type: 'bool', value: 'false' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.JITTER,
    name: 'Jitter (Getar Acak)',
    category: 'Move & Transform',
    description: 'Efek guncangan/shake dinamis berbasis frekuensi dan magnitude',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.JITTER,
      locallyApplied: false,
      properties: [
        { name: 'angle', type: 'float', value: '45.000000' },
        { name: 'freq', type: 'float', value: '30.000000' },
        { name: 'mag', type: 'float', value: '15.000000' },
        { name: 'seed', type: 'float', value: '0.000000' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.TEXT_TRANSFORM,
    name: 'Text Transform (Animasi Teks Per Karakter)',
    category: 'Text',
    description: 'Animasi kemunculan teks bertahap per huruf (reveal / typewriter / fly-in)',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.TEXT_TRANSFORM,
      locallyApplied: false,
      properties: [
        { name: 'start', type: 'float', value: '0.000000' },
        { name: 'end', type: 'float', value: '1.000000' },
        { name: 'phase', type: 'float', value: '0.000000' },
        { name: 'component', type: 'int', value: '1' },
        { name: 'anchor', type: 'int', value: '0' },
        { name: 'offset', type: 'vec2', value: '0.000000,26.000000' },
        { name: 'alpha', type: 'float', value: '-1.000000' },
        { name: 'easeIn', type: 'float', value: '1.000000' },
        { name: 'easeOut', type: 'float', value: '-1.000000' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.DRAWING_PROGRESS,
    name: 'Drawing Progress (Gambar Garis)',
    category: 'Drawing',
    description: 'Animasi goresan kuas atau penulisan garis bertahap',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.DRAWING_PROGRESS,
      locallyApplied: false,
      properties: [
        { name: 'start', type: 'float', value: '0.000000' },
        { name: 'end', type: 'float', value: '100.000000' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.GRID,
    name: 'Grid (Kisi-kisi)',
    category: 'Repeat',
    description: 'Pola grid garis latar belakang estetis',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.GRID,
      locallyApplied: false,
      properties: [
        { name: 'position', type: 'vec2', value: '0.000000,0.000000' },
        { name: 'spacing', type: 'float', value: '0.134000' },
        { name: 'width', type: 'float', value: '0.002000' },
        { name: 'color', type: 'color', value: '#ff101019' },
        { name: 'punchout', type: 'bool', value: 'false' },
      ],
    }),
  },
  {
    id: VERIFIED_EFFECT_IDS.SIMPLE_STARS,
    name: 'Simple Stars (Bintang Angkasa)',
    category: 'Repeat',
    description: 'Partikel bintang berkilau untuk latar belakang galaksi',
    createDefault: () => ({
      id: VERIFIED_EFFECT_IDS.SIMPLE_STARS,
      locallyApplied: false,
      properties: [
        { name: 'starParallax', type: 'vec3', value: '0.000000,0.000000,0.000000' },
        { name: 'scale', type: 'float', value: '1.000000' },
        { name: 'starSize', type: 'float', value: '0.100000' },
        { name: 'color', type: 'color', value: '#ffffffff' },
        { name: 'starCount', type: 'float', value: '25.000000' },
        { name: 'brightness', type: 'float', value: '1.000000' },
      ],
    }),
  },
];
