/**
 * Alight Motion Format Adapter & Android Share Bridge
 * Bridges CTools project state with Alight Motion XML and Android file export/share.
 */

import { AMScene } from './types';
import { AlightMotionSerializer } from './serializer';
import { AlightMotionValidator } from './validator';
import { ALIGHT_MOTION_DEFAULTS } from './constants';

export class FormatVersionAdapter {
  /**
   * Adapts a scene to a specific Alight Motion target version
   */
  static adaptToVersion(
    scene: AMScene,
    versionName = ALIGHT_MOTION_DEFAULTS.VERSION_NAME,
    amver = ALIGHT_MOTION_DEFAULTS.AMVER,
    ffver = ALIGHT_MOTION_DEFAULTS.FFVER
  ): AMScene {
    return {
      ...scene,
      amver,
      ffver,
      am: `com.alightcreative.motion/${versionName}`,
    };
  }
}

export class AlightMotionExportBridge {
  /**
   * Generates and triggers download of the .xml project file
   */
  static downloadXmlFile(scene: AMScene, fileName?: string): void {
    const xml = AlightMotionSerializer.serializeScene(scene);
    const blob = new Blob([xml], { type: 'application/xml;charset=utf-8' });
    const cleanTitle = (fileName || scene.title || 'Proyek_Alight_Motion')
      .replace(/[^a-zA-Z0-9_\-]/g, '_');
    const fullFileName = `${cleanTitle}.xml`;

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fullFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Shares the XML project file directly to Android apps (including Alight Motion) via Web Share API
   */
  static async shareToAlightMotion(scene: AMScene): Promise<{ success: boolean; fallback: boolean; message: string }> {
    const xml = AlightMotionSerializer.serializeScene(scene);
    const cleanTitle = (scene.title || 'Proyek_Alight_Motion').replace(/[^a-zA-Z0-9_\-]/g, '_');
    const fileName = `${cleanTitle}.xml`;

    const blob = new Blob([xml], { type: 'application/xml' });
    const file = new File([blob], fileName, { type: 'application/xml' });

    // Check if navigator.canShare supports files (Android Chrome / Edge / WebView)
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: scene.title || 'Alight Motion Project',
          text: `Buka file proyek ${fileName} di Alight Motion`,
        });
        return {
          success: true,
          fallback: false,
          message: 'Berhasil membuka dialog Share Android. Pilih Alight Motion untuk mengimpor proyek.',
        };
      } catch (err: unknown) {
        if (err instanceof Error && err.name === 'AbortError') {
          return { success: false, fallback: false, message: 'Batal membagikan file.' };
        }
      }
    }

    // Fallback: download the file directly
    this.downloadXmlFile(scene);
    return {
      success: true,
      fallback: true,
      message: 'Perangkat tidak mendukung Share API berkas langsung. Berkas .xml berhasil diunduh ke penyimpanan.',
    };
  }

  /**
   * Copies the raw XML string to clipboard
   */
  static async copyXmlToClipboard(scene: AMScene): Promise<boolean> {
    try {
      const xml = AlightMotionSerializer.serializeScene(scene);
      await navigator.clipboard.writeText(xml);
      return true;
    } catch {
      return false;
    }
  }
}
