/**
 * Alight Motion Regression & Golden Test Suite
 * Tests all 13 required test cases plus Golden Reference fidelity.
 */

import { AMScene } from './types';
import { AlightMotionSerializer } from './serializer';
import { AlightMotionValidator } from './validator';

export interface TestCaseResult {
  id: string;
  name: string;
  description: string;
  passed: boolean;
  xmlOutput: string;
  error?: string;
}

export class AlightMotionTestSuite {
  static runAllTests(): TestCaseResult[] {
    const results: TestCaseResult[] = [];

    // TEST 01: Empty Scene
    results.push(this.test01EmptyScene());

    // TEST 02: Single Shape
    results.push(this.test02SingleShape());

    // TEST 03: Shape + Transform
    results.push(this.test03ShapeTransform());

    // TEST 04: Shape + Keyframe
    results.push(this.test04ShapeKeyframe());

    // TEST 05: Text
    results.push(this.test05Text());

    // TEST 06: Effect
    results.push(this.test06Effect());

    // TEST 07: Parent / Child
    results.push(this.test07ParentChild());

    // TEST 08: Null Object
    results.push(this.test08NullObject());

    // TEST 09: Nested Scene (embedScene)
    results.push(this.test09NestedScene());

    // TEST 10: Media
    results.push(this.test10Media());

    // TEST 11: Audio
    results.push(this.test11Audio());

    // TEST 12: Custom Path
    results.push(this.test12CustomPath());

    // TEST 13: Border / Stroke
    results.push(this.test13BorderStroke());

    return results;
  }

  // --- Test 01: Empty Scene ---
  private static test01EmptyScene(): TestCaseResult {
    const scene: AMScene = {
      title: 'Empty Scene',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 5000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed = val.isValid && xml.includes('<scene ') && xml.includes('</scene>');

    return {
      id: 'TEST-01',
      name: 'Empty Scene',
      description: 'Root <scene> dengan metadata default tanpa elemen',
      passed,
      xmlOutput: xml,
      error: val.issues.find((i) => i.severity === 'error')?.message,
    };
  }

  // --- Test 02: Single Shape ---
  private static test02SingleShape(): TestCaseResult {
    const scene: AMScene = {
      title: 'Single Shape',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 30,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'shape',
          id: '101',
          label: 'Lingkaran 1',
          startTime: 0,
          endTime: 3000,
          fillType: 'color',
          mediaFillMode: 'fill',
          s: '.circle',
          fillColor: '#ffff4444',
          properties: [{ name: 'size', type: 'vec2', value: '100.000000,100.000000' }],
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed = val.isValid && xml.includes('<shape id="101"') && xml.includes('s=".circle"');

    return {
      id: 'TEST-02',
      name: 'Single Shape',
      description: 'Elemen <shape> tunggal dengan s=".circle" dan fillColor',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 03: Shape + Transform ---
  private static test03ShapeTransform(): TestCaseResult {
    const scene: AMScene = {
      title: 'Shape Transform',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'shape',
          id: '102',
          label: 'Persegi 1',
          startTime: 0,
          endTime: 3000,
          fillType: 'color',
          mediaFillMode: 'fill',
          s: '.rect',
          fillColor: '#ff2563eb',
          transform: {
            location: { value: '360.000000,360.000000,0.000000' },
            scale: { value: '1.500000,1.500000' },
            rotation: { value: '45.000000' },
            opacity: { value: '0.900000' },
          },
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed =
      val.isValid &&
      xml.includes('<transform>') &&
      xml.includes('<location value="360.000000,360.000000,0.000000" />');

    return {
      id: 'TEST-03',
      name: 'Shape + Static Transform',
      description: 'Elemen <shape> dengan tag <transform> posisi, skala, dan rotasi statis',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 04: Shape + Keyframes ---
  private static test04ShapeKeyframe(): TestCaseResult {
    const scene: AMScene = {
      title: 'Shape Keyframe',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'shape',
          id: '103',
          label: 'Animasi Skala',
          startTime: 0,
          endTime: 2000,
          fillType: 'color',
          mediaFillMode: 'fill',
          s: '.circle',
          fillColor: '#ffffffff',
          transform: {
            scale: {
              keyframes: [
                { t: 0.00397, v: '1.000000,1.000000' },
                {
                  t: 0.85,
                  v: '5.000000,5.000000',
                  e: 'cubicBezier 0.0 0.0 0.0 0.96539795',
                },
              ],
            },
          },
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed =
      val.isValid &&
      xml.includes('<kf t="0.003970"') &&
      xml.includes('e="cubicBezier 0.0 0.0 0.0 0.96539795"');

    return {
      id: 'TEST-04',
      name: 'Shape + Keyframes & Easing',
      description: 'Elemen <shape> dengan keyframe teranimasi dan formula easing cubicBezier',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 05: Text ---
  private static test05Text(): TestCaseResult {
    const scene: AMScene = {
      title: 'Text Layer',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'text',
          id: '104',
          startTime: 0,
          endTime: 3000,
          fillType: 'color',
          mediaFillMode: 'fill',
          size: '48.000000',
          font: 'googlefonts?name=Roboto&weight=700',
          wrapWidth: 512,
          align: 'center',
          content: 'CTools <Alight Motion> & Presets',
          fillColor: '#ffffffff',
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed =
      val.isValid &&
      xml.includes('<text id="104"') &&
      xml.includes('&lt;Alight Motion&gt;') &&
      xml.includes('<content>');

    return {
      id: 'TEST-05',
      name: 'Text & XML Escaping',
      description: 'Tag <text> dengan Google Fonts, align, wrapWidth, dan escaping karakter khusus',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 06: Effect ---
  private static test06Effect(): TestCaseResult {
    const scene: AMScene = {
      title: 'Effect Layer',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'shape',
          id: '105',
          startTime: 0,
          endTime: 3000,
          fillType: 'color',
          mediaFillMode: 'fill',
          s: '.rect',
          fillColor: '#ffffffff',
          effects: [
            {
              id: 'com.alightcreative.effects.motionblur4',
              locallyApplied: false,
              properties: [
                { name: 'tune', type: 'float', value: '1.000000' },
                { name: 'usePos', type: 'bool', value: 'true' },
              ],
            },
          ],
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed =
      val.isValid &&
      xml.includes('<effect id="com.alightcreative.effects.motionblur4"') &&
      xml.includes('<property name="tune" type="float" value="1.000000" />');

    return {
      id: 'TEST-06',
      name: 'Generic Effect & Properties',
      description: 'Elemen dengan effect ID terverifikasi dan daftar properti typed',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 07: Parent / Child ---
  private static test07ParentChild(): TestCaseResult {
    const scene: AMScene = {
      title: 'Parenting',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'nullobj',
          id: '200',
          label: 'Master Null',
          startTime: 0,
          endTime: 3000,
          mediaFillMode: 'fill',
          type: 'perspective',
        },
        {
          kind: 'shape',
          id: '201',
          parent: '200',
          label: 'Child Shape',
          startTime: 0,
          endTime: 3000,
          fillType: 'color',
          mediaFillMode: 'fill',
          s: '.rect',
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed = val.isValid && xml.includes('parent="200"');

    return {
      id: 'TEST-07',
      name: 'Parent / Child Hierarchy',
      description: 'Struktur relasi parent-child antar layer tervalidasi tanpa broken reference',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 08: Null Object ---
  private static test08NullObject(): TestCaseResult {
    const scene: AMScene = {
      title: 'Null Object',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'nullobj',
          id: '300',
          label: 'Nol 1',
          startTime: 0,
          endTime: 3000,
          mediaFillMode: 'fill',
          type: 'perspective',
          transform: {
            location: { value: '720.000000,540.000000,0.000000' },
            scale: { value: '1.500000,1.500000' },
          },
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed = val.isValid && xml.includes('<nullobj id="300"') && xml.includes('type="perspective"');

    return {
      id: 'TEST-08',
      name: 'Null Object 3D Perspective',
      description: 'Tag <nullobj> dengan type="perspective" dan transform',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 09: Nested Scene (embedScene) ---
  private static test09NestedScene(): TestCaseResult {
    const scene: AMScene = {
      title: 'Root with Nested Group',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'embedScene',
          id: '400',
          label: 'Group 1',
          startTime: 0,
          endTime: 3000,
          fillType: 'intrinsic',
          outTime: 3000,
          mediaFillMode: 'fill',
          fillColor: '#ff000000',
          scene: {
            title: '',
            width: 720,
            height: 720,
            exportWidth: 720,
            exportHeight: 720,
            precompose: 'dynamicResolution',
            bgcolor: '#00000000',
            totalTime: 3000,
            fps: 60,
            modifiedTime: 0,
            amver: '1028425',
            ffver: '106',
            am: 'com.alightcreative.motion/5.0.273.1028425',
            amplatform: 'android',
            retime: 'off',
            retimeAdaptFPS: false,
            elements: [
              {
                kind: 'shape',
                id: '401',
                startTime: 0,
                endTime: 3000,
                fillType: 'color',
                mediaFillMode: 'fill',
                s: '.rect',
                fillColor: '#ffff0000',
              },
            ],
          },
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed =
      val.isValid &&
      xml.includes('<embedScene id="400"') &&
      xml.includes('<scene ') &&
      xml.includes('</embedScene>');

    return {
      id: 'TEST-09',
      name: 'Nested Precompose Scene (embedScene)',
      description: 'Grup precompose rekursif dengan tag <embedScene> dan child <scene>',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 10: Media Reference ---
  private static test10Media(): TestCaseResult {
    const scene: AMScene = {
      title: 'Media Project',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 30,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      media: [
        {
          uri: 'am:59914EAAFAD69C81C81550F599AC166D8BA55168.png',
          filename: 'image.png',
          title: 'Layer Image',
          type: 'image/png',
          size: 96228,
          width: 1080,
          height: 810,
        },
      ],
      elements: [
        {
          kind: 'shape',
          id: '500',
          startTime: 0,
          endTime: 3000,
          fillType: 'media',
          fillImage: 'am:59914EAAFAD69C81C81550F599AC166D8BA55168.png',
          mediaFillMode: 'stretch',
          s: '.rect',
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed =
      val.isValid &&
      xml.includes('<media uri="am:59914EAAFAD69C81C81550F599AC166D8BA55168.png"') &&
      xml.includes('fillImage="am:59914EAAFAD69C81C81550F599AC166D8BA55168.png"');

    return {
      id: 'TEST-10',
      name: 'Media Asset Reference',
      description: 'Tag <media> header dan referensi fillImage="am:HASH.png"',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 11: Audio ---
  private static test11Audio(): TestCaseResult {
    const scene: AMScene = {
      title: 'Audio Project',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 10000,
      fps: 30,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'audio',
          id: '600',
          label: 'Backsound Music',
          startTime: 0,
          endTime: 10000,
          src: 'am:98D36D22710C4F70CA70512FC35171FE84F8D7BC.mp4',
          inTime: 0,
          outTime: 10000,
          mediaFillMode: 'fill',
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed = val.isValid && xml.includes('<audio id="600"');

    return {
      id: 'TEST-11',
      name: 'Audio Element Support',
      description: 'Validasi kompatibilitas element audio pada scene',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 12: Custom Vector Path ---
  private static test12CustomPath(): TestCaseResult {
    const scene: AMScene = {
      title: 'Vector Path',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'shape',
          id: '700',
          startTime: 0,
          endTime: 3000,
          fillType: 'color',
          mediaFillMode: 'fill',
          s: '.poly',
          path: 'M -180.0 -62.663834 C -100.0 -50.0 50.0 50.0 180.0 62.663834 Z',
          fillColor: '#ffff00ff',
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed = val.isValid && xml.includes('<path d="M -180.0 -62.663834');

    return {
      id: 'TEST-12',
      name: 'Custom Vector Path',
      description: 'Tag <path d="..."> untuk shape poligon kustom',
      passed,
      xmlOutput: xml,
    };
  }

  // --- Test 13: Border / Stroke ---
  private static test13BorderStroke(): TestCaseResult {
    const scene: AMScene = {
      title: 'Border and Stroke',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ffd8d8d8',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'shape',
          id: '800',
          startTime: 0,
          endTime: 3000,
          fillType: 'color',
          mediaFillMode: 'fill',
          s: '.arc',
          pathStroke: {
            direction: 'centered',
            endSize: '1.500000',
            color: '#ffffffff',
            size: '6.000000',
          },
          border: {
            direction: 'outside',
            id: '1',
            color: '#ff444444',
            size: '19.000000',
          },
        },
      ],
    };

    const xml = AlightMotionSerializer.serializeScene(scene);
    const val = AlightMotionValidator.validate(scene);
    const passed =
      val.isValid &&
      xml.includes('<path-stroke direction="centered" end-size="1.500000">') &&
      xml.includes('<border direction="outside" id="1">');

    return {
      id: 'TEST-13',
      name: 'Border & Path Stroke',
      description: 'Tag <path-stroke> dan <border> dengan arah dan ketebalan terverifikasi',
      passed,
      xmlOutput: xml,
    };
  }
}
