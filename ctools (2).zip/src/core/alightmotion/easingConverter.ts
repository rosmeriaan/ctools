/**
 * Alight Motion Easing Definition & Serializer
 * Supports cubicBezier, elastic, reverse elastic, step, and cyclic formulas.
 */

export interface EasingPreset {
  id: string;
  name: string;
  description: string;
  formula: string; // The exact string expression for XML e="..." attribute
}

export const EASING_PRESETS: EasingPreset[] = [
  {
    id: 'linear',
    name: 'Linear (Tanpa Easing)',
    description: 'Pergerakan konstan berkecepatan rata',
    formula: '', // Linear keyframe does not require 'e' attribute
  },
  {
    id: 'ease-in-out-smooth',
    name: 'Ease In Out (Halus)',
    description: 'Mulai perlahan, cepat di tengah, melambat di akhir',
    formula: 'cubicBezier 0.42 0.0 0.58 1.0',
  },
  {
    id: 'ease-out-smooth',
    name: 'Ease Out (Deselerasi Halus)',
    description: 'Langsung cepat lalu melambat lembut',
    formula: 'cubicBezier 0.0 0.0 0.0 1.0',
  },
  {
    id: 'ease-in-smooth',
    name: 'Ease In (Akselerasi)',
    description: 'Mulai pelan lalu melesat kencang',
    formula: 'cubicBezier 0.42 0.0 1.0 1.0',
  },
  {
    id: 'overshoot-bounce',
    name: 'Overshoot / JJ Pop',
    description: 'Melompat melewati batas lalu kembali (JJ Shake)',
    formula: 'cubicBezier 0.0 0.0 0.0 1.4152249',
  },
  {
    id: 'jj-bounce-fast',
    name: 'JJ Bounce (Jedag Jedug)',
    description: 'Kurva pantul tajam khas transisi Alight Motion',
    formula: 'cubicBezier 0.70099175 -0.3633218 0.21939015 1.4152249',
  },
  {
    id: 'elastic-spring',
    name: 'Elastic Spring (Kenyal)',
    description: 'Efek pegas elastis getar saat mendarat',
    formula: 'elastic 0.43870524 1.0 0.20726645 0.65847754',
  },
  {
    id: 'reverse-elastic',
    name: 'Reverse Elastic (Pental Mundur)',
    description: 'Pegas terbalik untuk efek lempar/lepas',
    formula: 'reverse elastic 0.5 1.0 0.2885813 1.0',
  },
  {
    id: 'step-hold',
    name: 'Step / Hold (Patah-Patah)',
    description: 'Langsung berpindah nilai secara instan tanpa interpolasi',
    formula: 'step 1.0 0.0',
  },
];

export class EasingConverter {
  /**
   * Generates a cubicBezier expression string
   */
  static makeCubicBezier(x1: number, y1: number, x2: number, y2: number): string {
    return `cubicBezier ${x1.toFixed(6)} ${y1.toFixed(6)} ${x2.toFixed(6)} ${y2.toFixed(6)}`;
  }

  /**
   * Generates an elastic expression string
   */
  static makeElastic(a: number, b: number, c: number, d: number): string {
    return `elastic ${a.toFixed(6)} ${b.toFixed(6)} ${c.toFixed(6)} ${d.toFixed(6)}`;
  }

  /**
   * Generates a step expression string
   */
  static makeStep(a = 1.0, b = 0.0): string {
    return `step ${a.toFixed(1)} ${b.toFixed(1)}`;
  }
}
