/**
 * Alight Motion Version Constants & Verified Defaults
 */

export const ALIGHT_MOTION_DEFAULTS = {
  VERSION_NAME: '5.0.273.1028425',
  AMVER: '1028425',
  FFVER: '106',
  AM_PACKAGE: 'com.alightcreative.motion/5.0.273.1028425',
  PLATFORM: 'android' as const,
  PRECOMPOSE: 'dynamicResolution' as const,
  RETIME: 'freeze' as const,
  RETIME_ADAPT_FPS: false,
  DEFAULT_BG_COLOR: '#ffd8d8d8', // Opaque light grey
  DEFAULT_WIDTH: 720,
  DEFAULT_HEIGHT: 720,
  DEFAULT_FPS: 60,
  DEFAULT_TOTAL_TIME: 5000, // 5 seconds in ms
};

export const VERIFIED_EFFECT_IDS = {
  MOTION_BLUR: 'com.alightcreative.effects.motionblur4',
  EXPOSURE: 'com.alightcreative.effects.exposure',
  SATURATION_VIBRANCE: 'com.alightcreative.effects.satvib',
  NOISE: 'com.alightcreative.effects.noise3',
  FLIP_3D: 'com.alightcreative.effects.flip3',
  JITTER: 'com.alightcreative.effects.jitter',
  TEXT_SPACING: 'com.alightcreative.effects.textspacing',
  TEXT_TRANSFORM: 'com.alightcreative.effects.texttransform',
  DRAWING_PROGRESS: 'com.alightcreative.effects.drawing.progress',
  GRID: 'com.alightcreative.effects.grid2',
  SIMPLE_STARS: 'com.alightcreative.effects.simplestars2',
  LIFT: 'com.alightcreative.effects.lift',
  INVERT: 'com.alightcreative.effects.invert',
  STRIPES: 'com.alightcreative.effects.stripes',
  VIGNETTE: 'com.alightcreative.effects.vignette',
  WIPE: 'com.alightcreative.effects.wipe2',
  BLINK: 'com.alightcreative.effects.blink2',
} as const;

export const SHAPE_TYPES = [
  { id: '.rect', label: 'Rectangle (Persegi)' },
  { id: '.circle', label: 'Circle (Lingkaran)' },
  { id: '.roundrect', label: 'Rounded Rectangle' },
  { id: '.arc', label: 'Arc (Busur)' },
  { id: '.star', label: 'Star (Bintang)' },
  { id: '.poly', label: 'Polygon' },
] as const;

export const GOOGLE_FONTS_POPULAR = [
  { name: 'Roboto', weights: [400, 500, 700, 900] },
  { name: 'Caveat', weights: [400, 700] },
  { name: 'Montserrat', weights: [400, 600, 800, 900] },
  { name: 'Poppins', weights: [400, 600, 700, 800] },
  { name: 'Bebas Neue', weights: [400] },
  { name: 'Oswald', weights: [400, 600, 700] },
  { name: 'Inter', weights: [400, 600, 700] },
] as const;
