/**
 * Alight Motion Time Conversion & Normalization Utility
 * Handles conversion between milliseconds, frames, seconds, and normalized keyframe 't'.
 */

export class TimeConverter {
  /**
   * Converts milliseconds to frame number at a given FPS
   */
  static msToFrames(ms: number, fps: number): number {
    return Math.round((ms / 1000) * fps);
  }

  /**
   * Converts frames to milliseconds
   */
  static framesToMs(frames: number, fps: number): number {
    return Math.round((frames / fps) * 1000);
  }

  /**
   * Normalizes an absolute time in ms to relative keyframe 't' (0.0 to 1.0)
   */
  static normalizeKeyframeTime(timeMs: number, startTimeMs: number, endTimeMs: number): number {
    const duration = endTimeMs - startTimeMs;
    if (duration <= 0) return 0;
    const rawT = (timeMs - startTimeMs) / duration;
    // Format to 6 decimal precision as seen in Alight Motion XML
    return parseFloat(rawT.toFixed(6));
  }

  /**
   * Denormalizes a keyframe 't' (0.0 to 1.0) back to absolute milliseconds
   */
  static denormalizeKeyframeTime(t: number, startTimeMs: number, endTimeMs: number): number {
    const duration = endTimeMs - startTimeMs;
    return Math.round(startTimeMs + t * duration);
  }

  /**
   * Formats a floating point keyframe t to exactly 6 decimals string
   */
  static formatKfT(t: number): string {
    return t.toFixed(6);
  }

  /**
   * Formats duration in ms to friendly format (e.g. "00:05.12s (308 frames)")
   */
  static formatDurationSummary(ms: number, fps: number): string {
    const seconds = (ms / 1000).toFixed(2);
    const frames = Math.round((ms / 1000) * fps);
    return `${seconds}s (${frames} frames @ ${fps}fps)`;
  }
}
