/**
 * Multi-Stage Alight Motion XML & Data Validator
 * Validates Schema, Hierarchy References, Timing, and DOM XML Round-trip.
 */

import { AMScene, AMElement, ValidationResult, ValidationIssue } from './types';
import { AlightMotionSerializer } from './serializer';

export class AlightMotionValidator {
  /**
   * Complete validation pipeline: Schema -> References -> Timing -> DOM Round-Trip
   */
  static validate(scene: AMScene): ValidationResult {
    const issues: ValidationIssue[] = [];

    // Stage 1: Scene & Schema Validation
    this.validateSceneSchema(scene, issues);

    // Stage 2: Element Hierarchy & Reference Validation
    this.validateElementReferences(scene, issues);

    // Stage 3: Timing & Keyframe Validation
    this.validateTimings(scene, issues);

    // Stage 4: XML Serialization & DOMParser Round-Trip Validation
    try {
      const xml = AlightMotionSerializer.serializeScene(scene);
      this.validateXmlSyntax(xml, issues);
    } catch (err: unknown) {
      issues.push({
        severity: 'error',
        code: 'XML_SERIALIZATION_FAILED',
        message: `Gagal melakukan serialisasi XML: ${err instanceof Error ? err.message : String(err)}`,
      });
    }

    const hasErrors = issues.some((i) => i.severity === 'error');
    return {
      isValid: !hasErrors,
      issues,
    };
  }

  /**
   * Stage 1: Validate Scene Metadata
   */
  private static validateSceneSchema(scene: AMScene, issues: ValidationIssue[]): void {
    if (!scene.title || scene.title.trim() === '') {
      issues.push({
        severity: 'warning',
        code: 'SCENE_TITLE_EMPTY',
        message: 'Judul scene masih kosong. Disarankan memberi nama yang jelas.',
      });
    }

    if (!scene.width || scene.width <= 0 || !scene.height || scene.height <= 0) {
      issues.push({
        severity: 'error',
        code: 'INVALID_DIMENSIONS',
        message: `Dimensi scene tidak valid: ${scene.width}x${scene.height}. Harus lebih dari 0.`,
      });
    }

    if (!scene.totalTime || scene.totalTime <= 0) {
      issues.push({
        severity: 'error',
        code: 'INVALID_TOTAL_TIME',
        message: `Durasi scene (${scene.totalTime}ms) tidak valid.`,
      });
    }

    if (!scene.fps || scene.fps <= 0) {
      issues.push({
        severity: 'error',
        code: 'INVALID_FPS',
        message: `FPS (${scene.fps}) tidak valid.`,
      });
    }

    if (!scene.bgcolor || !/^#[0-9a-f]{8}$/i.test(scene.bgcolor)) {
      issues.push({
        severity: 'warning',
        code: 'INVALID_BGCOLOR_FORMAT',
        message: `Warna background "${scene.bgcolor}" harus dalam format #AARRGGBB 8-digit.`,
      });
    }
  }

  /**
   * Stage 2: Validate Element ID Uniqueness & Parent References
   */
  private static validateElementReferences(scene: AMScene, issues: ValidationIssue[]): void {
    const allIds = new Set<string>();
    const parentMap = new Map<string, string>();

    const collectElements = (elems: AMElement[]) => {
      for (const elem of elems) {
        if (!elem.id) {
          issues.push({
            severity: 'error',
            code: 'ELEMENT_ID_MISSING',
            message: `Terdapat elemen ${elem.kind} tanpa atribut ID unik.`,
          });
          continue;
        }

        if (allIds.has(elem.id)) {
          issues.push({
            severity: 'error',
            code: 'DUPLICATE_ELEMENT_ID',
            message: `ID elemen ganda "${elem.id}" ditemukan pada ${elem.label || elem.kind}. ID harus unik.`,
            elementId: elem.id,
          });
        }
        allIds.add(elem.id);

        if (elem.parent) {
          parentMap.set(elem.id, elem.parent);
        }

        // Recursive traversal for nested scenes
        if (elem.kind === 'embedScene' && elem.scene) {
          collectElements(elem.scene.elements);
        }
      }
    };

    collectElements(scene.elements);

    // Validate that every parent actually exists
    for (const [childId, parentId] of parentMap.entries()) {
      if (!allIds.has(parentId)) {
        issues.push({
          severity: 'error',
          code: 'BROKEN_PARENT_REFERENCE',
          message: `Elemen "${childId}" memiliki parent="${parentId}" yang tidak ditemukan dalam project.`,
          elementId: childId,
        });
      }

      // Check for direct self-parenting
      if (childId === parentId) {
        issues.push({
          severity: 'error',
          code: 'CIRCULAR_PARENT_SELF',
          message: `Elemen "${childId}" tidak boleh menjadikan dirinya sendiri sebagai parent.`,
          elementId: childId,
        });
      }
    }

    // Check for circular hierarchy loops (A -> B -> C -> A)
    for (const startId of parentMap.keys()) {
      const visited = new Set<string>();
      let curr: string | undefined = startId;
      while (curr && parentMap.has(curr)) {
        if (visited.has(curr)) {
          issues.push({
            severity: 'error',
            code: 'CIRCULAR_PARENT_LOOP',
            message: `Hierarki parent melingkar (circular reference loop) terdeteksi pada rantai elemen "${startId}".`,
            elementId: startId,
          });
          break;
        }
        visited.add(curr);
        curr = parentMap.get(curr);
      }
    }
  }

  /**
   * Stage 3: Validate Element Timings & Keyframe bounds
   */
  private static validateTimings(scene: AMScene, issues: ValidationIssue[]): void {
    for (const elem of scene.elements) {
      if (elem.startTime > elem.endTime) {
        issues.push({
          severity: 'error',
          code: 'INVALID_ELEMENT_TIMING',
          message: `Elemen "${elem.id}" memiliki startTime (${elem.startTime}ms) lebih besar dari endTime (${elem.endTime}ms).`,
          elementId: elem.id,
        });
      }

      if (elem.startTime < 0) {
        issues.push({
          severity: 'warning',
          code: 'NEGATIVE_START_TIME',
          message: `Elemen "${elem.id}" memiliki startTime negatif (${elem.startTime}ms).`,
          elementId: elem.id,
        });
      }

      // Validate keyframe time sorting
      if (elem.kind === 'shape' || elem.kind === 'text' || elem.kind === 'nullobj' || elem.kind === 'embedScene') {
        const tf = elem.transform;
        if (tf) {
          this.validateTransformKeyframes(elem.id, 'location', tf.location?.keyframes, issues);
          this.validateTransformKeyframes(elem.id, 'scale', tf.scale?.keyframes, issues);
          this.validateTransformKeyframes(elem.id, 'rotation', tf.rotation?.keyframes, issues);
          this.validateTransformKeyframes(elem.id, 'opacity', tf.opacity?.keyframes, issues);
        }
      }
    }
  }

  private static validateTransformKeyframes(
    elementId: string,
    propName: string,
    kfs: Array<{ t: number; v: string }> | undefined,
    issues: ValidationIssue[]
  ): void {
    if (!kfs || kfs.length <= 1) return;

    for (let i = 0; i < kfs.length - 1; i++) {
      if (kfs[i].t > kfs[i + 1].t) {
        issues.push({
          severity: 'warning',
          code: 'UNSORTED_KEYFRAMES',
          message: `Keyframe pada properti "${propName}" di elemen "${elementId}" tidak berurutan secara kronologis (t=${kfs[i].t} > t=${kfs[i + 1].t}).`,
          elementId,
        });
        break;
      }
    }
  }

  /**
   * Stage 4: Validate generated XML syntax via DOMParser
   */
  private static validateXmlSyntax(xmlString: string, issues: ValidationIssue[]): void {
    if (typeof window === 'undefined' || !window.DOMParser) return;

    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlString, 'application/xml');
    const parserError = doc.querySelector('parsererror');

    if (parserError) {
      issues.push({
        severity: 'error',
        code: 'XML_PARSER_ERROR',
        message: `XML tidak valid menurut parser XML: ${parserError.textContent?.slice(0, 200)}`,
      });
    }

    const root = doc.documentElement;
    if (root.nodeName !== 'scene') {
      issues.push({
        severity: 'error',
        code: 'INVALID_ROOT_TAG',
        message: `Root XML harus <scene>, ditemukan: <${root.nodeName}>`,
      });
    }
  }
}
