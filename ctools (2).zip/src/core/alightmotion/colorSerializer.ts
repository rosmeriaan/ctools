/**
 * Alight Motion Color Serializer
 * Strict #AARRGGBB format converter (Alpha in the highest byte).
 */

import { AMColorHex } from './types';

/**
 * Normalizes any hex, rgba or standard color string to #AARRGGBB
 */
export function toAMColor(color: string, alpha = 1.0): AMColorHex {
  if (!color) return '#ffffffff';

  const clean = color.trim().toLowerCase();

  // Already #AARRGGBB (9 chars)
  if (/^#[0-9a-f]{8}$/i.test(clean)) {
    return clean;
  }

  // Standard 6-digit hex (#RRGGBB) -> add #ff alpha prefix -> #ffRRGGBB
  if (/^#[0-9a-f]{6}$/i.test(clean)) {
    const aHex = Math.round(Math.min(1, Math.max(0, alpha)) * 255)
      .toString(16)
      .padStart(2, '0');
    return `#${aHex}${clean.slice(1)}`;
  }

  // 3-digit hex (#RGB) -> expand to #ffRRGGBB
  if (/^#[0-9a-f]{3}$/i.test(clean)) {
    const r = clean[1] + clean[1];
    const g = clean[2] + clean[2];
    const b = clean[3] + clean[3];
    const aHex = Math.round(Math.min(1, Math.max(0, alpha)) * 255)
      .toString(16)
      .padStart(2, '0');
    return `#${aHex}${r}${g}${b}`;
  }

  // rgba(r, g, b, a) or rgb(r, g, b)
  const rgbMatch = clean.match(/rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/);
  if (rgbMatch) {
    const r = Math.min(255, parseInt(rgbMatch[1], 10)).toString(16).padStart(2, '0');
    const g = Math.min(255, parseInt(rgbMatch[2], 10)).toString(16).padStart(2, '0');
    const b = Math.min(255, parseInt(rgbMatch[3], 10)).toString(16).padStart(2, '0');
    const parsedA = rgbMatch[4] !== undefined ? parseFloat(rgbMatch[4]) : alpha;
    const aHex = Math.round(Math.min(1, Math.max(0, parsedA)) * 255).toString(16).padStart(2, '0');
    return `#${aHex}${r}${g}${b}`;
  }

  return '#ffffffff';
}

/**
 * Converts #AARRGGBB to CSS color string (rgba(r, g, b, a) or #RRGGBB)
 */
export function fromAMColorToCSS(amColor: AMColorHex): string {
  if (!amColor || !/^#[0-9a-f]{8}$/i.test(amColor)) {
    return amColor || '#ffffff';
  }

  const a = parseInt(amColor.slice(1, 3), 16) / 255;
  const r = parseInt(amColor.slice(3, 5), 16);
  const g = parseInt(amColor.slice(5, 7), 16);
  const b = parseInt(amColor.slice(7, 9), 16);

  if (a >= 0.999) {
    return `#${amColor.slice(3)}`;
  }

  return `rgba(${r}, ${g}, ${b}, ${Number(a.toFixed(3))})`;
}

/**
 * Extracts 6-digit #RRGGBB hex for standard color pickers
 */
export function amColorToHex6(amColor: AMColorHex): string {
  if (amColor && /^#[0-9a-f]{8}$/i.test(amColor)) {
    return `#${amColor.slice(3, 9)}`;
  }
  return '#ffffff';
}

/**
 * Extracts Alpha [0.0 - 1.0] from #AARRGGBB
 */
export function amColorToAlpha(amColor: AMColorHex): number {
  if (amColor && /^#[0-9a-f]{8}$/i.test(amColor)) {
    return parseInt(amColor.slice(1, 3), 16) / 255;
  }
  return 1.0;
}
