/**
 * Alight Motion Domain Data Models & AST Definitions
 * STRICTLY mapped to Alight Motion 5.0.273.1028425 XML format.
 */

export type AMColorHex = string; // e.g. "#ffffffff" or "#ffd8d8d8" (#AARRGGBB)

export type AMShapeType = '.rect' | '.circle' | '.roundrect' | '.arc' | '.star' | '.poly';

export type AMFillType = 'color' | 'gradient' | 'media' | 'none' | 'intrinsic';

export type AMMediaFillMode = 'fill' | 'stretch' | 'fit';

export type AMPropertyType = 'float' | 'int' | 'bool' | 'color' | 'vec2' | 'vec3';

export type AMBlendingMode = 'normal' | 'screen' | 'multiply' | 'overlay' | 'lighten' | 'darken';

export type AMTextAlign = 'center' | 'left' | 'right';

export interface AMKeyframe {
  t: number; // Normalized time (e.g. 0.0 to 1.0)
  v: string; // Serialized value formatted for its property type
  e?: string; // Easing formula: "cubicBezier x1 y1 x2 y2" | "elastic a b c d" | "reverse elastic a b c d" | "cyclic ..." | "step a b"
}

export interface AMAnimatable<T = string> {
  value?: T; // Static value if not animated
  keyframes?: AMKeyframe[]; // Keyframes if animated
}

export interface AMTransform {
  location?: AMAnimatable<string>; // "x,y,z" (vec3)
  scale?: AMAnimatable<string>; // "x,y" (vec2)
  rotation?: AMAnimatable<string>; // degrees (float)
  opacity?: AMAnimatable<string>; // 0.0 - 1.0 (float)
  pivot?: AMAnimatable<string>; // "x,y" (vec2)
}

export interface AMProperty {
  name: string;
  type: AMPropertyType;
  value?: string;
  keyframes?: AMKeyframe[];
  hidden?: boolean;
}

export interface AMEffect {
  id: string; // e.g. "com.alightcreative.effects.motionblur4"
  locallyApplied?: boolean;
  hidden?: boolean;
  properties: AMProperty[];
}

export interface AMGradient {
  type: 'linear' | 'radial';
  startColor: AMColorHex;
  endColor: AMColorHex;
  start: string; // "x,y"
  end: string; // "x,y"
}

export interface AMShadow {
  direction?: 'outside' | 'inside';
  enabled?: boolean;
  opacity?: AMAnimatable<string>;
  offset?: AMAnimatable<string>; // "x,y"
  color?: AMAnimatable<AMColorHex>;
  radius?: AMAnimatable<string>;
}

export interface AMPathStroke {
  direction?: 'centered' | 'inside' | 'outside';
  endSize?: string;
  color?: AMColorHex;
  size?: string;
}

export interface AMBorder {
  id?: string;
  direction?: 'centered' | 'inside' | 'outside';
  color?: AMColorHex;
  size?: string;
}

export interface AMBookmark {
  t: number; // timestamp in milliseconds
}

export interface AMMedia {
  uri: string; // e.g. "am:98D36D22710C4F70CA70512FC35171FE84F8D7BC.mp4"
  filename?: string;
  title?: string;
  type?: string; // "image/png" | "image/jpeg" | "video/mp4"
  size?: number;
  sig?: string;
  orientation?: number;
  infoUpdated?: string;
  width?: number;
  height?: number;
}

export interface AMAudioElement {
  kind: 'audio';
  id: string;
  label?: string;
  startTime: number; // ms
  endTime: number; // ms
  src: string; // "am:..."
  inTime?: number;
  outTime?: number;
  mediaFillMode?: AMMediaFillMode;
  parent?: string;
  hidden?: boolean;
  volume?: AMAnimatable<string>;
  effects?: AMEffect[];
}

export interface AMShapeElement {
  kind: 'shape';
  id: string;
  label?: string;
  hidden?: boolean;
  startTime: number; // ms
  endTime: number; // ms
  fillType: AMFillType;
  fillImage?: string; // "am:..."
  fillVideo?: string; // "am:..."
  outTime?: number;
  mediaFillMode: AMMediaFillMode;
  clippingMask?: boolean;
  blending?: AMBlendingMode;
  parent?: string; // ID of parent element
  s: AMShapeType; // e.g. ".rect", ".circle", ".roundrect", ".arc"
  transform?: AMTransform;
  fillColor?: AMColorHex;
  gradient?: AMGradient;
  shadow?: AMShadow;
  path?: string; // SVG path data (d="...")
  pathStroke?: AMPathStroke;
  border?: AMBorder;
  properties?: AMProperty[];
  effects?: AMEffect[];
}

export interface AMTextElement {
  kind: 'text';
  id: string;
  label?: string;
  hidden?: boolean;
  startTime: number; // ms
  endTime: number; // ms
  fillType: AMFillType;
  mediaFillMode: AMMediaFillMode;
  parent?: string;
  size: string; // e.g. "48.000000"
  font: string; // e.g. "googlefonts?name=Roboto&weight=700"
  wrapWidth: number | string; // e.g. 512
  align: AMTextAlign;
  content: string; // text body
  transform?: AMTransform;
  fillColor?: AMColorHex;
  gradient?: AMGradient;
  shadow?: AMShadow;
  effects?: AMEffect[];
  properties?: AMProperty[];
}

export interface AMNullObjectElement {
  kind: 'nullobj';
  id: string;
  label?: string;
  startTime: number; // ms
  endTime: number; // ms
  mediaFillMode: AMMediaFillMode;
  parent?: string;
  type: 'perspective' | 'standard';
  transform?: AMTransform;
  effects?: AMEffect[];
}

export interface AMEmbedSceneElement {
  kind: 'embedScene';
  id: string;
  label?: string;
  hidden?: boolean;
  startTime: number; // ms
  endTime: number; // ms
  fillType: 'intrinsic' | AMFillType;
  outTime?: number;
  mediaFillMode: AMMediaFillMode;
  parent?: string;
  transform?: AMTransform;
  fillColor?: AMColorHex;
  shadow?: AMShadow;
  effects?: AMEffect[];
  scene: AMScene; // Nested recursive scene
}

export type AMElement =
  | AMShapeElement
  | AMTextElement
  | AMNullObjectElement
  | AMEmbedSceneElement
  | AMAudioElement;

export interface AMScene {
  title: string;
  width: number;
  height: number;
  exportWidth: number;
  exportHeight: number;
  precompose: 'dynamicResolution' | 'always' | 'never';
  bgcolor: AMColorHex; // #AARRGGBB
  totalTime: number; // in milliseconds
  fps: number; // e.g. 30, 60
  modifiedTime?: number; // timestamp in ms
  amver: string | number; // e.g. "1028425"
  ffver: string | number; // e.g. "106"
  am: string; // e.g. "com.alightcreative.motion/5.0.273.1028425"
  amplatform: 'android' | 'ios';
  retime: 'freeze' | 'off' | 'scale';
  retimeAdaptFPS?: boolean;
  thumbnailTime?: number;
  bookmarks?: AMBookmark[];
  media?: AMMedia[];
  elements: AMElement[];
}

export interface AMProject {
  title: string;
  description?: string;
  createdTime: number;
  rootScene: AMScene;
}

export interface ValidationIssue {
  severity: 'error' | 'warning';
  code: string;
  message: string;
  elementId?: string;
}

export interface ValidationResult {
  isValid: boolean;
  issues: ValidationIssue[];
}
