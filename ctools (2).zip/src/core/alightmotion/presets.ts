/**
 * Alight Motion Verified Project Preset Templates
 */

import { AMScene } from './types';
import { VERIFIED_EFFECT_IDS } from './constants';

export interface ProjectTemplate {
  id: string;
  name: string;
  badge: string;
  description: string;
  createScene: () => AMScene;
}

export const PROJECT_TEMPLATES: ProjectTemplate[] = [
  {
    id: 'jj-bounce-flash',
    name: 'JJ Beat Bounce & Exposure Flash',
    badge: 'Popular JJ',
    description: 'Animasi hentakan zoom bounce khas Jedag Jedug dengan flash pencahayaan exposure dan motion blur',
    createScene: () => ({
      title: 'JJ Beat Bounce Project',
      width: 720,
      height: 1280,
      exportWidth: 720,
      exportHeight: 1280,
      precompose: 'dynamicResolution',
      bgcolor: '#ff101019',
      totalTime: 3000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'nullobj',
          id: '10001',
          label: 'Master Controller',
          startTime: 0,
          endTime: 3000,
          mediaFillMode: 'fill',
          type: 'perspective',
          transform: {
            scale: {
              keyframes: [
                { t: 0.0, v: '1.000000,1.000000' },
                {
                  t: 0.25,
                  v: '1.450000,1.450000',
                  e: 'cubicBezier 0.70099175 -0.3633218 0.21939015 1.4152249',
                },
                { t: 0.5, v: '1.000000,1.000000', e: 'cubicBezier 0.0 0.0 0.0 1.0' },
                {
                  t: 0.75,
                  v: '1.300000,1.300000',
                  e: 'cubicBezier 0.70099175 -0.3633218 0.21939015 1.4152249',
                },
                { t: 1.0, v: '1.000000,1.000000' },
              ],
            },
          },
        },
        {
          kind: 'shape',
          id: '10002',
          parent: '10001',
          label: 'Main Card',
          startTime: 0,
          endTime: 3000,
          fillType: 'gradient',
          mediaFillMode: 'fill',
          s: '.roundrect',
          fillColor: '#ff2563eb',
          gradient: {
            type: 'linear',
            startColor: '#ff2563eb',
            endColor: '#ff9333ea',
            start: '0.000000,0.000000',
            end: '1.000000,1.000000',
          },
          properties: [
            { name: 'size', type: 'vec2', value: '480.000000,640.000000' },
            { name: 'cornerRadius', type: 'float', value: '28.000000' },
          ],
          effects: [
            {
              id: VERIFIED_EFFECT_IDS.EXPOSURE,
              locallyApplied: false,
              properties: [
                {
                  name: 'exposure',
                  type: 'float',
                  keyframes: [
                    { t: 0.0, v: '1.500000' },
                    { t: 0.2, v: '0.000000', e: 'cubicBezier 0.0 0.0 0.0 1.0' },
                    { t: 0.5, v: '1.200000' },
                    { t: 0.7, v: '0.000000', e: 'cubicBezier 0.0 0.0 0.0 1.0' },
                  ],
                },
              ],
            },
            {
              id: VERIFIED_EFFECT_IDS.MOTION_BLUR,
              locallyApplied: false,
              properties: [
                { name: 'tune', type: 'float', value: '1.000000' },
                { name: 'usePos', type: 'bool', value: 'true' },
                { name: 'useScale', type: 'bool', value: 'true' },
              ],
            },
          ],
        },
      ],
    }),
  },
  {
    id: 'kinetic-typography',
    name: 'Kinetic Typography Reveal',
    badge: 'Motion Graphic',
    description: 'Animasi teks per karakter dengan Text Transform reveal, easing halus, dan soft shadow',
    createScene: () => ({
      title: 'Kinetic Typography',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ff0b0f19',
      totalTime: 4000,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'text',
          id: '20001',
          startTime: 200,
          endTime: 3800,
          fillType: 'color',
          mediaFillMode: 'fill',
          size: '44.000000',
          font: 'googlefonts?name=Roboto&weight=900',
          wrapWidth: 600,
          align: 'center',
          content: 'KINETIC MOTION',
          fillColor: '#ffffffff',
          transform: {
            location: { value: '360.000000,320.000000,0.000000' },
          },
          effects: [
            {
              id: VERIFIED_EFFECT_IDS.TEXT_SPACING,
              locallyApplied: false,
              properties: [
                { name: 'letterspacing', type: 'float', value: '-0.040000' },
                { name: 'linespacing', type: 'float', value: '1.000000' },
              ],
            },
            {
              id: VERIFIED_EFFECT_IDS.TEXT_TRANSFORM,
              locallyApplied: false,
              properties: [
                {
                  name: 'start',
                  type: 'float',
                  keyframes: [
                    { t: 0.0, v: '0.000000' },
                    { t: 0.45, v: '1.000000', e: 'cubicBezier 0.0 0.0 0.103415966 1.034602' },
                  ],
                },
                { name: 'end', type: 'float', value: '1.000000' },
                { name: 'offset', type: 'vec2', value: '0.000000,30.000000' },
                { name: 'alpha', type: 'float', value: '-1.000000' },
                { name: 'easeIn', type: 'float', value: '1.000000' },
                { name: 'easeOut', type: 'float', value: '-1.000000' },
              ],
            },
            {
              id: VERIFIED_EFFECT_IDS.MOTION_BLUR,
              locallyApplied: false,
              properties: [{ name: 'tune', type: 'float', value: '1.000000' }],
            },
          ],
          shadow: {
            direction: 'outside',
            opacity: { value: '0.350000' },
            offset: { value: '0.000000,6.000000' },
          },
        },
      ],
    }),
  },
  {
    id: 'embed-scene-group',
    name: '3D Perspective Nested Precompose',
    badge: 'Advanced',
    description: 'Precompose grup rekursif (<embedScene>) dengan controller 3D Null dan rotasi berpasangan',
    createScene: () => ({
      title: 'Nested Scene 3D',
      width: 720,
      height: 720,
      exportWidth: 720,
      exportHeight: 720,
      precompose: 'dynamicResolution',
      bgcolor: '#ff111827',
      totalTime: 3500,
      fps: 60,
      amver: '1028425',
      ffver: '106',
      am: 'com.alightcreative.motion/5.0.273.1028425',
      amplatform: 'android',
      retime: 'freeze',
      retimeAdaptFPS: false,
      elements: [
        {
          kind: 'nullobj',
          id: '30001',
          label: '3D Axis Null',
          startTime: 0,
          endTime: 3500,
          mediaFillMode: 'fill',
          type: 'perspective',
          transform: {
            rotation: {
              keyframes: [
                { t: 0.0, v: '0.000000' },
                { t: 0.8, v: '360.000000', e: 'elastic 0.5 1.0 0.2 1.0' },
              ],
            },
          },
        },
        {
          kind: 'embedScene',
          id: '30002',
          parent: '30001',
          label: 'Badge Group',
          startTime: 0,
          endTime: 3500,
          fillType: 'intrinsic',
          outTime: 3500,
          mediaFillMode: 'fill',
          fillColor: '#ff000000',
          scene: {
            title: '',
            width: 500,
            height: 500,
            exportWidth: 500,
            exportHeight: 500,
            precompose: 'dynamicResolution',
            bgcolor: '#00000000',
            totalTime: 3500,
            fps: 60,
            amver: '1028425',
            ffver: '106',
            am: 'com.alightcreative.motion/5.0.273.1028425',
            amplatform: 'android',
            retime: 'off',
            retimeAdaptFPS: false,
            elements: [
              {
                kind: 'shape',
                id: '30003',
                label: 'Inner Circle',
                startTime: 0,
                endTime: 3500,
                fillType: 'gradient',
                mediaFillMode: 'fill',
                s: '.circle',
                fillColor: '#ffec4899',
                gradient: {
                  type: 'linear',
                  startColor: '#ffec4899',
                  endColor: '#ff8b5cf6',
                  start: '0.000000,0.000000',
                  end: '1.000000,1.000000',
                },
                properties: [{ name: 'size', type: 'vec2', value: '300.000000,300.000000' }],
              },
              {
                kind: 'text',
                id: '30004',
                startTime: 0,
                endTime: 3500,
                fillType: 'color',
                mediaFillMode: 'fill',
                size: '32.000000',
                font: 'googlefonts?name=Roboto&weight=900',
                wrapWidth: 400,
                align: 'center',
                content: 'ALIGHT MOTION',
                fillColor: '#ffffffff',
              },
            ],
          },
        },
      ],
    }),
  },
];
