/**
 * Pure Alight Motion XML Serializer
 * Strict, robust, and verified serialization engine.
 */

import {
  AMScene,
  AMElement,
  AMShapeElement,
  AMTextElement,
  AMNullObjectElement,
  AMEmbedSceneElement,
  AMAudioElement,
  AMTransform,
  AMProperty,
  AMEffect,
  AMKeyframe,
  AMAnimatable,
  AMGradient,
  AMShadow,
  AMPathStroke,
  AMBorder,
  AMBookmark,
  AMMedia,
} from './types';
import { toAMColor } from './colorSerializer';
import { TimeConverter } from './timeConverter';
import { ALIGHT_MOTION_DEFAULTS } from './constants';

export class AlightMotionSerializer {
  /**
   * Escape special XML characters for attribute values
   */
  static escapeAttr(val: string | number | boolean | undefined): string {
    if (val === undefined || val === null) return '';
    return String(val)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /**
   * Escape special XML characters for text element body
   */
  static escapeContent(val: string): string {
    if (!val) return '';
    return String(val)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /**
   * Serializes a root Scene into compliant Alight Motion XML
   */
  static serializeScene(scene: AMScene, indentLevel = 0, isRoot = true): string {
    const ind = '  '.repeat(indentLevel);
    let xml = '';

    if (isRoot) {
      xml += `<?xml version='1.0' encoding='UTF-8' ?>\n`;
      xml += `<!--\nCreated by CTools Alight Motion Exporter\nExported: ${new Date().toISOString()}\nTarget: ${scene.am || ALIGHT_MOTION_DEFAULTS.AM_PACKAGE}\n-->\n`;
    }

    const attrs: string[] = [];
    attrs.push(`title="${this.escapeAttr(scene.title)}"`);
    attrs.push(`width="${scene.width}"`);
    attrs.push(`height="${scene.height}"`);
    attrs.push(`exportWidth="${scene.exportWidth || scene.width}"`);
    attrs.push(`exportHeight="${scene.exportHeight || scene.height}"`);
    attrs.push(`precompose="${scene.precompose || ALIGHT_MOTION_DEFAULTS.PRECOMPOSE}"`);
    attrs.push(`bgcolor="${toAMColor(scene.bgcolor || ALIGHT_MOTION_DEFAULTS.DEFAULT_BG_COLOR)}"`);
    attrs.push(`totalTime="${scene.totalTime}"`);
    attrs.push(`fps="${scene.fps || ALIGHT_MOTION_DEFAULTS.DEFAULT_FPS}"`);
    attrs.push(`modifiedTime="${scene.modifiedTime ?? Date.now()}"`);
    attrs.push(`amver="${scene.amver || ALIGHT_MOTION_DEFAULTS.AMVER}"`);
    attrs.push(`ffver="${scene.ffver || ALIGHT_MOTION_DEFAULTS.FFVER}"`);
    attrs.push(`am="${this.escapeAttr(scene.am || ALIGHT_MOTION_DEFAULTS.AM_PACKAGE)}"`);
    attrs.push(`amplatform="${scene.amplatform || ALIGHT_MOTION_DEFAULTS.PLATFORM}"`);
    attrs.push(`retime="${scene.retime || ALIGHT_MOTION_DEFAULTS.RETIME}"`);

    if (scene.thumbnailTime !== undefined) {
      attrs.push(`thumbnailTime="${scene.thumbnailTime}"`);
    }

    attrs.push(`retimeAdaptFPS="${scene.retimeAdaptFPS ? 'true' : 'false'}"`);

    xml += `${ind}<scene ${attrs.join(' ')}>\n`;

    // 1. Bookmarks
    if (scene.bookmarks && scene.bookmarks.length > 0) {
      for (const bm of scene.bookmarks) {
        xml += this.serializeBookmark(bm, indentLevel + 1);
      }
    }

    // 2. Media references
    if (scene.media && scene.media.length > 0) {
      for (const m of scene.media) {
        xml += this.serializeMedia(m, indentLevel + 1);
      }
    }

    // 3. Elements (Shapes, Texts, Nulls, EmbedScenes, Audio)
    if (scene.elements && scene.elements.length > 0) {
      for (const elem of scene.elements) {
        xml += this.serializeElement(elem, indentLevel + 1);
      }
    }

    xml += `${ind}</scene>`;
    if (isRoot) xml += '\n';

    return xml;
  }

  /**
   * Serializes a single bookmark
   */
  static serializeBookmark(bm: AMBookmark, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    return `${ind}<bookmark t="${bm.t}" />\n`;
  }

  /**
   * Serializes a media reference
   */
  static serializeMedia(m: AMMedia, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`uri="${this.escapeAttr(m.uri)}"`];
    if (m.filename) attrs.push(`filename="${this.escapeAttr(m.filename)}"`);
    if (m.title) attrs.push(`title="${this.escapeAttr(m.title)}"`);
    if (m.type) attrs.push(`type="${this.escapeAttr(m.type)}"`);
    if (m.size !== undefined) attrs.push(`size="${m.size}"`);
    if (m.sig) attrs.push(`sig="${this.escapeAttr(m.sig)}"`);
    if (m.orientation !== undefined) attrs.push(`orientation="${m.orientation}"`);
    if (m.infoUpdated) attrs.push(`infoUpdated="${this.escapeAttr(m.infoUpdated)}"`);
    if (m.width !== undefined) attrs.push(`width="${m.width}"`);
    if (m.height !== undefined) attrs.push(`height="${m.height}"`);
    return `${ind}<media ${attrs.join(' ')} />\n`;
  }

  /**
   * Serializes an element by delegating to its specific type serializer
   */
  static serializeElement(elem: AMElement, indentLevel: number): string {
    switch (elem.kind) {
      case 'shape':
        return this.serializeShape(elem, indentLevel);
      case 'text':
        return this.serializeText(elem, indentLevel);
      case 'nullobj':
        return this.serializeNullObject(elem, indentLevel);
      case 'embedScene':
        return this.serializeEmbedScene(elem, indentLevel);
      case 'audio':
        return this.serializeAudio(elem, indentLevel);
      default:
        return '';
    }
  }

  /**
   * Serializes <audio>
   */
  static serializeAudio(audio: AMAudioElement, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`id="${this.escapeAttr(audio.id)}"`];

    if (audio.label) attrs.push(`label="${this.escapeAttr(audio.label)}"`);
    attrs.push(`startTime="${audio.startTime}"`);
    attrs.push(`endTime="${audio.endTime}"`);
    attrs.push(`src="${this.escapeAttr(audio.src)}"`);
    if (audio.inTime !== undefined) attrs.push(`inTime="${audio.inTime}"`);
    if (audio.outTime !== undefined) attrs.push(`outTime="${audio.outTime}"`);
    attrs.push(`mediaFillMode="${audio.mediaFillMode || 'fill'}"`);
    if (audio.parent) attrs.push(`parent="${this.escapeAttr(audio.parent)}"`);

    let inner = '';
    if (audio.volume) {
      inner += this.serializeAnimatableTag('volume', audio.volume, indentLevel + 1);
    }
    if (audio.effects && audio.effects.length > 0) {
      for (const eff of audio.effects) {
        inner += this.serializeEffect(eff, indentLevel + 1);
      }
    }

    if (inner.trim() === '') {
      return `${ind}<audio ${attrs.join(' ')} />\n`;
    }
    return `${ind}<audio ${attrs.join(' ')}>\n${inner}${ind}</audio>\n`;
  }

  /**
   * Serializes <shape>
   */
  static serializeShape(shape: AMShapeElement, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`id="${this.escapeAttr(shape.id)}"`];

    if (shape.label) attrs.push(`label="${this.escapeAttr(shape.label)}"`);
    if (shape.hidden) attrs.push(`hidden="true"`);
    attrs.push(`startTime="${shape.startTime}"`);
    attrs.push(`endTime="${shape.endTime}"`);
    if (shape.clippingMask) attrs.push(`clippingMask="true"`);
    attrs.push(`fillType="${shape.fillType}"`);
    if (shape.blending && shape.blending !== 'normal') attrs.push(`blending="${shape.blending}"`);
    if (shape.fillImage) attrs.push(`fillImage="${this.escapeAttr(shape.fillImage)}"`);
    if (shape.fillVideo) attrs.push(`fillVideo="${this.escapeAttr(shape.fillVideo)}"`);
    if (shape.outTime !== undefined) attrs.push(`outTime="${shape.outTime}"`);
    attrs.push(`mediaFillMode="${shape.mediaFillMode || 'fill'}"`);
    if (shape.parent) attrs.push(`parent="${this.escapeAttr(shape.parent)}"`);
    attrs.push(`s="${shape.s || '.rect'}"`);

    let inner = '';
    if (shape.transform) inner += this.serializeTransform(shape.transform, indentLevel + 1);
    if (shape.fillColor && shape.fillType !== 'none') {
      inner += `${ind}  <fillColor value="${toAMColor(shape.fillColor)}" />\n`;
    }
    if (shape.gradient && shape.fillType === 'gradient') {
      inner += this.serializeGradient(shape.gradient, indentLevel + 1);
    }
    if (shape.path) {
      inner += `${ind}  <path d="${this.escapeAttr(shape.path)}" />\n`;
    }
    if (shape.pathStroke) {
      inner += this.serializePathStroke(shape.pathStroke, indentLevel + 1);
    }
    if (shape.border) {
      inner += this.serializeBorder(shape.border, indentLevel + 1);
    }
    if (shape.effects && shape.effects.length > 0) {
      for (const eff of shape.effects) {
        inner += this.serializeEffect(eff, indentLevel + 1);
      }
    }
    if (shape.shadow) {
      inner += this.serializeShadow(shape.shadow, indentLevel + 1);
    }
    if (shape.properties && shape.properties.length > 0) {
      for (const prop of shape.properties) {
        inner += this.serializeProperty(prop, indentLevel + 1);
      }
    }

    if (inner.trim() === '') {
      return `${ind}<shape ${attrs.join(' ')} />\n`;
    }
    return `${ind}<shape ${attrs.join(' ')}>\n${inner}${ind}</shape>\n`;
  }

  /**
   * Serializes <text>
   */
  static serializeText(text: AMTextElement, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`id="${this.escapeAttr(text.id)}"`];

    if (text.label) attrs.push(`label="${this.escapeAttr(text.label)}"`);
    if (text.hidden) attrs.push(`hidden="true"`);
    attrs.push(`startTime="${text.startTime}"`);
    attrs.push(`endTime="${text.endTime}"`);
    attrs.push(`fillType="${text.fillType || 'color'}"`);
    attrs.push(`mediaFillMode="${text.mediaFillMode || 'fill'}"`);
    if (text.parent) attrs.push(`parent="${this.escapeAttr(text.parent)}"`);
    attrs.push(`size="${this.formatFloatStr(text.size)}"` );
    attrs.push(`font="${this.escapeAttr(text.font)}"` );
    attrs.push(`wrapWidth="${text.wrapWidth}"` );
    attrs.push(`align="${text.align || 'center'}"` );

    let inner = '';
    if (text.transform) inner += this.serializeTransform(text.transform, indentLevel + 1);
    if (text.fillColor && text.fillType !== 'none') {
      inner += `${ind}  <fillColor value="${toAMColor(text.fillColor)}" />\n`;
    }
    if (text.gradient && text.fillType === 'gradient') {
      inner += this.serializeGradient(text.gradient, indentLevel + 1);
    }
    if (text.effects && text.effects.length > 0) {
      for (const eff of text.effects) {
        inner += this.serializeEffect(eff, indentLevel + 1);
      }
    }
    if (text.shadow) {
      inner += this.serializeShadow(text.shadow, indentLevel + 1);
    }
    if (text.properties && text.properties.length > 0) {
      for (const prop of text.properties) {
        inner += this.serializeProperty(prop, indentLevel + 1);
      }
    }
    inner += `${ind}  <content>${this.escapeContent(text.content)}</content>\n`;

    return `${ind}<text ${attrs.join(' ')}>\n${inner}${ind}</text>\n`;
  }

  /**
   * Serializes <nullobj>
   */
  static serializeNullObject(nullObj: AMNullObjectElement, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`id="${this.escapeAttr(nullObj.id)}"`];

    if (nullObj.label) attrs.push(`label="${this.escapeAttr(nullObj.label)}"`);
    attrs.push(`startTime="${nullObj.startTime}"`);
    attrs.push(`endTime="${nullObj.endTime}"`);
    attrs.push(`mediaFillMode="${nullObj.mediaFillMode || 'fill'}"`);
    if (nullObj.parent) attrs.push(`parent="${this.escapeAttr(nullObj.parent)}"`);
    attrs.push(`type="${nullObj.type || 'perspective'}"`);

    let inner = '';
    if (nullObj.transform) inner += this.serializeTransform(nullObj.transform, indentLevel + 1);
    if (nullObj.effects && nullObj.effects.length > 0) {
      for (const eff of nullObj.effects) {
        inner += this.serializeEffect(eff, indentLevel + 1);
      }
    }

    if (inner.trim() === '') {
      return `${ind}<nullobj ${attrs.join(' ')} />\n`;
    }
    return `${ind}<nullobj ${attrs.join(' ')}>\n${inner}${ind}</nullobj>\n`;
  }

  /**
   * Serializes <embedScene> (Recursive group / precompose)
   */
  static serializeEmbedScene(embed: AMEmbedSceneElement, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`id="${this.escapeAttr(embed.id)}"`];

    if (embed.label) attrs.push(`label="${this.escapeAttr(embed.label)}"`);
    if (embed.hidden) attrs.push(`hidden="true"`);
    attrs.push(`startTime="${embed.startTime}"`);
    attrs.push(`endTime="${embed.endTime}"`);
    attrs.push(`fillType="${embed.fillType || 'intrinsic'}"`);
    if (embed.outTime !== undefined) attrs.push(`outTime="${embed.outTime}"`);
    attrs.push(`mediaFillMode="${embed.mediaFillMode || 'fill'}"`);
    if (embed.parent) attrs.push(`parent="${this.escapeAttr(embed.parent)}"`);

    let inner = '';
    if (embed.transform) inner += this.serializeTransform(embed.transform, indentLevel + 1);
    if (embed.fillColor) {
      inner += `${ind}  <fillColor value="${toAMColor(embed.fillColor)}" />\n`;
    }
    if (embed.shadow) {
      inner += this.serializeShadow(embed.shadow, indentLevel + 1);
    }
    if (embed.effects && embed.effects.length > 0) {
      for (const eff of embed.effects) {
        inner += this.serializeEffect(eff, indentLevel + 1);
      }
    }
    // Recursive serialized inner scene
    inner += this.serializeScene(embed.scene, indentLevel + 1, false) + '\n';

    return `${ind}<embedScene ${attrs.join(' ')}>\n${inner}${ind}</embedScene>\n`;
  }

  /**
   * Serializes <transform> with location, scale, rotation, opacity, pivot
   */
  static serializeTransform(tf: AMTransform, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    let inner = '';

    if (tf.location) inner += this.serializeAnimatableTag('location', tf.location, indentLevel + 1);
    if (tf.pivot) inner += this.serializeAnimatableTag('pivot', tf.pivot, indentLevel + 1);
    if (tf.scale) inner += this.serializeAnimatableTag('scale', tf.scale, indentLevel + 1);
    if (tf.rotation) inner += this.serializeAnimatableTag('rotation', tf.rotation, indentLevel + 1);
    if (tf.opacity) inner += this.serializeAnimatableTag('opacity', tf.opacity, indentLevel + 1);

    if (inner.trim() === '') return '';
    return `${ind}<transform>\n${inner}${ind}</transform>\n`;
  }

  /**
   * Serializes a single transform property tag (e.g. <location> or <scale>)
   */
  static serializeAnimatableTag(
    tagName: string,
    anim: AMAnimatable<string>,
    indentLevel: number
  ): string {
    const ind = '  '.repeat(indentLevel);
    if (anim.keyframes && anim.keyframes.length > 0) {
      let kfXml = '';
      for (const kf of anim.keyframes) {
        kfXml += this.serializeKeyframe(kf, indentLevel + 1);
      }
      return `${ind}<${tagName}>\n${kfXml}${ind}</${tagName}>\n`;
    }
    if (anim.value !== undefined) {
      return `${ind}<${tagName} value="${this.escapeAttr(anim.value)}" />\n`;
    }
    return '';
  }

  /**
   * Serializes a single keyframe <kf t="..." v="..." e="..." />
   */
  static serializeKeyframe(kf: AMKeyframe, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`t="${TimeConverter.formatKfT(kf.t)}"`, `v="${this.escapeAttr(kf.v)}"`];
    if (kf.e && kf.e.trim() !== '') {
      attrs.push(`e="${this.escapeAttr(kf.e)}"`);
    }
    return `${ind}<kf ${attrs.join(' ')} />\n`;
  }

  /**
   * Serializes <property name="..." type="..." value="..." />
   */
  static serializeProperty(prop: AMProperty, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`name="${this.escapeAttr(prop.name)}"`, `type="${prop.type}"`];

    if (prop.keyframes && prop.keyframes.length > 0) {
      let kfXml = '';
      for (const kf of prop.keyframes) {
        kfXml += this.serializeKeyframe(kf, indentLevel + 1);
      }
      return `${ind}<property ${attrs.join(' ')}>\n${kfXml}${ind}</property>\n`;
    }

    if (prop.value !== undefined) {
      attrs.push(`value="${this.escapeAttr(prop.value)}"`);
    }
    return `${ind}<property ${attrs.join(' ')} />\n`;
  }

  /**
   * Serializes <effect id="..." locallyApplied="...">
   */
  static serializeEffect(eff: AMEffect, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [
      `id="${this.escapeAttr(eff.id)}"`,
      `locallyApplied="${eff.locallyApplied ? 'true' : 'false'}"`,
    ];
    if (eff.hidden) attrs.push(`hidden="true"`);

    let inner = '';
    if (eff.properties && eff.properties.length > 0) {
      for (const p of eff.properties) {
        inner += this.serializeProperty(p, indentLevel + 1);
      }
    }

    if (inner.trim() === '') {
      return `${ind}<effect ${attrs.join(' ')} />\n`;
    }
    return `${ind}<effect ${attrs.join(' ')}>\n${inner}${ind}</effect>\n`;
  }

  /**
   * Serializes <gradient>
   */
  static serializeGradient(grad: AMGradient, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [
      `type="${grad.type}"`,
      `startColor="${toAMColor(grad.startColor)}"`,
      `endColor="${toAMColor(grad.endColor)}"`,
      `start="${this.escapeAttr(grad.start)}"`,
      `end="${this.escapeAttr(grad.end)}"`,
    ];
    return `${ind}<gradient ${attrs.join(' ')} />\n`;
  }

  /**
   * Serializes <shadow>
   */
  static serializeShadow(shadow: AMShadow, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`direction="${shadow.direction || 'outside'}"`];
    if (shadow.enabled === false) attrs.push(`enabled="false"`);

    let inner = '';
    if (shadow.opacity) inner += this.serializeAnimatableTag('opacity', shadow.opacity, indentLevel + 1);
    if (shadow.offset) inner += this.serializeAnimatableTag('offset', shadow.offset, indentLevel + 1);
    if (shadow.color) inner += this.serializeAnimatableTag('color', shadow.color, indentLevel + 1);
    if (shadow.radius) inner += this.serializeAnimatableTag('radius', shadow.radius, indentLevel + 1);

    if (inner.trim() === '') {
      return `${ind}<shadow ${attrs.join(' ')} />\n`;
    }
    return `${ind}<shadow ${attrs.join(' ')}>\n${inner}${ind}</shadow>\n`;
  }

  /**
   * Serializes <path-stroke>
   */
  static serializePathStroke(ps: AMPathStroke, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`direction="${ps.direction || 'centered'}"`];
    if (ps.endSize) attrs.push(`end-size="${this.escapeAttr(ps.endSize)}"`);

    let inner = '';
    if (ps.color) inner += `${ind}  <color value="${toAMColor(ps.color)}" />\n`;
    if (ps.size) inner += `${ind}  <size value="${this.escapeAttr(ps.size)}" />\n`;

    return `${ind}<path-stroke ${attrs.join(' ')}>\n${inner}${ind}</path-stroke>\n`;
  }

  /**
   * Serializes <border>
   */
  static serializeBorder(border: AMBorder, indentLevel: number): string {
    const ind = '  '.repeat(indentLevel);
    const attrs: string[] = [`direction="${border.direction || 'outside'}"`];
    if (border.id) attrs.push(`id="${this.escapeAttr(border.id)}"`);

    let inner = '';
    if (border.color) inner += `${ind}  <color value="${toAMColor(border.color)}" />\n`;
    if (border.size) inner += `${ind}  <size value="${this.escapeAttr(border.size)}" />\n`;

    return `${ind}<border ${attrs.join(' ')}>\n${inner}${ind}</border>\n`;
  }

  /**
   * Formats numeric string for floats (e.g. 48 -> 48.000000)
   */
  private static formatFloatStr(val: string | number): string {
    const num = typeof val === 'number' ? val : parseFloat(val);
    if (isNaN(num)) return String(val);
    return num.toFixed(6);
  }
}
