# ALIGHT MOTION XML PROJECT FORMAT ANALYSIS

*Document Version:* 1.0.0  
*Target Alight Motion Build:* 5.0.273.1028425 (amver: 1028425, ffver: 106)  
*Platform:* Android  
*Status:* VERIFIED against Golden Reference XML export (`Proyek Baru 5.xml` / `Message in bootle Copy.xml`)

---

## 1. Executive Summary & Core Hierarchy

Alight Motion uses a strictly hierarchical, element-specific XML format rooted in `<scene>`. It does **not** use a generic `<project>` root or generic `<element type="...">` tags.

```
<scene>
  ├── <bookmark />
  ├── <media />
  ├── <audio />
  ├── <shape>
  │     ├── <transform />
  │     ├── <fillColor />
  │     ├── <gradient />
  │     ├── <path />
  │     ├── <path-stroke />
  │     ├── <border />
  │     ├── <shadow />
  │     ├── <property />
  │     └── <effect />
  ├── <text>
  │     ├── <transform />
  │     ├── <fillColor />
  │     ├── <gradient />
  │     ├── <shadow />
  │     ├── <effect />
  │     └── <content>
  ├── <nullobj>
  │     ├── <transform />
  │     └── <effect />
  └── <embedScene>
        ├── <transform />
        ├── <fillColor />
        ├── <shadow />
        ├── <effect />
        └── <scene> (Recursive nested scene)
```

---

## 2. Root Scene: `<scene>`

| Attribute | Type | Required/Optional | Example | Verification Status |
| :--- | :--- | :--- | :--- | :--- |
| `title` | string | Required | `title="Proyek Baru 5"` | **VERIFIED** |
| `width` | integer | Required | `width="1440"` / `720` | **VERIFIED** |
| `height` | integer | Required | `height="1080"` / `720` | **VERIFIED** |
| `exportWidth` | integer | Required | `exportWidth="720"` | **VERIFIED** |
| `exportHeight` | integer | Required | `exportHeight="720"` | **VERIFIED** |
| `precompose` | enum string | Required | `precompose="dynamicResolution"` | **VERIFIED** |
| `bgcolor` | color `#AARRGGBB` | Required | `bgcolor="#ffd8d8d8"` | **VERIFIED** |
| `totalTime` | integer (ms) | Required | `totalTime="25032"` | **VERIFIED** |
| `fps` | integer | Required | `fps="30"` / `fps="60"` | **VERIFIED** |
| `modifiedTime` | integer (timestamp ms) | Required | `modifiedTime="1787106161453"` / `0` | **VERIFIED** |
| `amver` | string/integer | Required | `amver="1028425"` | **VERIFIED** |
| `ffver` | string/integer | Required | `ffver="106"` | **VERIFIED** |
| `am` | string | Required | `am="com.alightcreative.motion/5.0.273.1028425"` | **VERIFIED** |
| `amplatform` | enum string | Required | `amplatform="android"` | **VERIFIED** |
| `retime` | enum string | Required | `retime="freeze"` / `retime="off"` | **VERIFIED** |
| `thumbnailTime` | integer (ms) | Optional | `thumbnailTime="9750"` | **VERIFIED** |
| `retimeAdaptFPS` | boolean string | Required | `retimeAdaptFPS="false"` | **VERIFIED** |

---

## 3. Element Specifications

### 3.1. `<shape>`
Defines vector shapes, solids, and media clips.

- **Attributes:**
  - `id` *(string / int, Required)*: Unique numeric identifier (e.g., `"202428416"`).
  - `label` *(string, Optional)*: Display name in layer list (e.g., `"Lingkaran 1"`).
  - `hidden` *(boolean string, Optional)*: `"true"` / `"false"`.
  - `startTime` *(integer ms, Required)*: Layer in-point relative to parent scene (e.g., `9450`).
  - `endTime` *(integer ms, Required)*: Layer out-point relative to parent scene (e.g., `11465`).
  - `fillType` *(enum, Required)*: `"color"` \| `"gradient"` \| `"media"` \| `"none"` \| `"intrinsic"`.
  - `fillImage` *(string, Optional)*: Media URI reference (`"am:HASH.png"` / `"am:HASH.jpg"`).
  - `fillVideo` *(string, Optional)*: Video URI reference (`"am:HASH.mp4"`).
  - `outTime` *(integer ms, Optional)*: Source trim out-time.
  - `mediaFillMode` *(enum, Required)*: `"fill"` \| `"stretch"` \| `"fit"`.
  - `clippingMask` *(boolean string, Optional)*: `"true"`.
  - `blending` *(enum, Optional)*: `"normal"` \| `"screen"` \| `"multiply"` \| `"overlay"`.
  - `parent` *(string ID, Optional)*: Parenting ID referencing a null or layer.
  - `s` *(shape descriptor, Required)*: `".rect"`, `".circle"`, `".roundrect"`, `".arc"`, `".star"`, `".poly"`.

---

### 3.2. `<text>`
Defines typography layers with Google Fonts or imported fonts.

- **Attributes:**
  - `id` *(string, Required)*
  - `label` *(string, Optional)*
  - `hidden` *(boolean string, Optional)*
  - `startTime` *(integer ms, Required)*
  - `endTime` *(integer ms, Required)*
  - `fillType` *(enum, Required)*: `"color"` \| `"gradient"`
  - `mediaFillMode` *(enum, Required)*: `"fill"`
  - `parent` *(string ID, Optional)*
  - `size` *(float string, Required)*: e.g. `"48.000000"`
  - `font` *(string, Required)*: e.g. `"googlefonts?name=Roboto&weight=700"`, `"imported?name=Font.ttf"`
  - `wrapWidth` *(integer/float string, Required)*: e.g. `"512"`
  - `align` *(enum, Required)*: `"center"` \| `"left"` \| `"right"`
- **Children:**
  - `<content>Escaped text content</content>`

---

### 3.3. `<nullobj>`
3D Perspective / Hierarchy Controller element.

- **Attributes:**
  - `id` *(string, Required)*
  - `label` *(string, Optional)*
  - `startTime` *(integer ms, Required)*
  - `endTime` *(integer ms, Required)*
  - `mediaFillMode` *(string, Required)*: `"fill"`
  - `parent` *(string ID, Optional)*
  - `type` *(enum, Required)*: `"perspective"`

---

### 3.4. `<embedScene>`
Precomposed nested scene group.

- **Attributes:**
  - `id`, `label`, `startTime`, `endTime`, `fillType="intrinsic"`, `outTime`, `mediaFillMode="fill"`, `parent`
- **Children:**
  - `<transform />`
  - `<fillColor value="#ff000000" />`
  - `<shadow direction="outside" />`
  - `<scene ...>` *(Full recursive scene instance)*

---

### 3.5. `<audio>` & `<media>`
- `<audio id="..." label="..." startTime="0" endTime="16032" src="am:..." inTime="14266" outTime="30298" mediaFillMode="fill" />`
- `<media uri="am:..." filename="..." title="..." type="image/jpeg" size="96228" sig="..." width="1080" height="810" />`

---

## 4. Transform & Keyframe System

Transform properties can be either **static** (`value="..."`) or **keyframed** (`<kf ...>` blocks):

```xml
<transform>
  <location value="720.000061,540.000000,0.000000" />
  <scale>
    <kf t="0.003970" v="1.500000,1.500000" />
    <kf t="0.161290" v="12.525001,12.525001" e="cubicBezier 0.0 0.0 0.0 0.96539795" />
  </scale>
  <rotation>
    <kf t="0.000000" v="0.000000" />
    <kf t="1.000000" v="360.000000" e="elastic 0.5 1.0 0.19913498 1.0" />
  </rotation>
  <opacity value="1.000000" />
  <pivot value="0.000000,0.000000" />
</transform>
```

### Time Representation:
- `startTime` and `endTime`: Absolute scene timeline time in **milliseconds**.
- `kf.t`: Normalized float time relative to layer duration:
  $$t = \frac{\text{kfTime} - \text{startTime}}{\text{endTime} - \text{startTime}}$$
  *(Values can slightly precede 0.0 or succeed 1.0 during transitions/padding as proven in golden reference: `-0.043716` to `0.956284`).*

### Easing Models (`e="..."`):
1. **Cubic Bezier:** `cubicBezier x1 y1 x2 y2` (e.g. `cubicBezier 0.0 0.0 0.0 1.0`)
2. **Elastic:** `elastic a b c d` (e.g. `elastic 0.43870524 1.0 0.20726645 0.65847754`)
3. **Reverse Elastic:** `reverse elastic 0.5 1.0 0.2885813 1.0`
4. **Cyclic:** `cyclic a b c d e` (e.g. `cyclic 0.707989 0.0 0.5 0.6435986 0.0`)
5. **Step / Hold:** `step a b` (e.g. `step 1.0 0.0`)

---

## 5. Verified Effect IDs

All effect IDs from `Proyek Baru 5.xml` verified in native Alight Motion registry:
- `com.alightcreative.effects.motionblur4`
- `com.alightcreative.effects.exposure`
- `com.alightcreative.effects.satvib`
- `com.alightcreative.effects.noise3`
- `com.alightcreative.effects.flip3`
- `com.alightcreative.effects.jitter`
- `com.alightcreative.effects.textspacing`
- `com.alightcreative.effects.texttransform`
- `com.alightcreative.effects.drawing.progress`
- `com.alightcreative.effects.grid2`
- `com.alightcreative.effects.simplestars2`
- `com.alightcreative.effects.lift`
- `com.alightcreative.effects.invert`
- `com.alightcreative.effects.stripes`
- `com.alightcreative.effects.vignette`
- `com.alightcreative.effects.wipe2`
- `com.alightcreative.effects.blink2`

---

## 6. Implementation & Verification Status

- **Scene Serialization:** `VERIFIED`
- **Shape (.rect, .circle, .roundrect, .arc):** `VERIFIED`
- **Text & Content Escaping:** `VERIFIED`
- **Null Object (Perspective 3D):** `VERIFIED`
- **EmbedScene Recursive Nesting:** `VERIFIED`
- **Transform & Easing Formulas:** `VERIFIED`
- **Color (#AARRGGBB):** `VERIFIED`
- **Reference & Cycle Validation:** `VERIFIED`
- **Media Packaging & Internal Hashes (`am:...`):** `PARTIALLY VERIFIED` *(Reference syntax verified; standalone asset bundling requires direct device packaging)*
- **Android Direct Intent / Deep Link:** `PARTIALLY VERIFIED` *(Export via standard Android Web Share `.xml` / file picker is guaranteed; private URI deep-links marked as NOT VERIFIED without native bridge).*
