# CTools — Multi-Toolbox Multimedia & Utility Web Application

> **"Simple tools. Fast results."**  
> CTools adalah platform web utility serba guna yang cepat, modern, responsif, dan 100% aman (client-side processing).

---

## Daftar Isi
1. [Fitur Utama](#fitur-utama)
2. [Arsitektur Proyek](#arsitektur-proyek)
3. [Daftar Tools Awal](#daftar-tools-awal)
4. [Cara Menjalankan CTools](#cara-menjalankan-ctools)
5. [Panduan Menambahkan Tool Baru (Extensibility Guide)](#panduan-menambahkan-tool-baru)
6. [Shared Components & Utilities](#shared-components--utilities)
7. [Privasi & Keamanan](#privasi--keamanan)

---

## Fitur Utama
- **100% Client-Side Processing**: Semua gambar, video, dan audio diproses langsung di peramban web pengguna menggunakan HTML5 Canvas, Web Audio API, dan MediaRecorder tanpa upload ke server.
- **Multi-File Modular Architecture**: Struktur komponen dan engine terpisah, bersih, dan mudah diperluas.
- **Tool Registry System**: Pendaftaran tool terpusat di `src/registry/tools.ts`. Menambah tool baru tidak memerlukan perombakan arsitektur.
- **URL Parameter Navigation**: Navigasi langsung ke tool menggunakan query parameter, contoh: `?tool=bg-eraser`, `?tool=video-reverse`, `?tool=mp4-to-mp3`, `?tool=qr-generator`.
- **Responsive Mobile-First & Dark/Light Mode**: Desain modern dengan token warna CSS, nyaman di smartphone (360px - 430px) hingga layar desktop ultra-lebar.

---

## Arsitektur Proyek

```
CTools/
├── index.html                   # HTML Entry point
├── metadata.json                # App metadata
├── package.json                 # Dependencies & scripts
├── README.md                    # Dokumentasi utama proyek
│
└── src/
    ├── main.tsx                 # React entry point
    ├── App.tsx                  # Root router shell & layout
    ├── index.css                # CSS variables & design tokens
    │
    ├── types/                   # TypeScript interfaces
    │   └── index.ts
    │
    ├── context/                 # State & Theme context
    │   └── ThemeContext.tsx
    │
    ├── registry/                # Tool Registry terpusat
    │   └── tools.ts
    │
    ├── utils/                   # Reusable helper utilities
    │   ├── file.ts              # File validation, blob download, clipboard
    │   ├── formatters.ts        # File size, duration & dimension formatters
    │   └── toast.ts             # Global toast event system
    │
    ├── components/
    │   └── common/              # Shared reusable UI components
    │       ├── Header.tsx       # Brand header, theme switch, settings
    │       ├── Sidebar.tsx      # Desktop collapsible sidebar & drawer
    │       ├── BottomNav.tsx    # Mobile bottom navigation bar
    │       ├── ToolCard.tsx     # Reusable tool card
    │       ├── UploadBox.tsx    # Universal drag & drop file uploader
    │       ├── FileInfo.tsx     # File details chip
    │       ├── ProgressBar.tsx  # Dynamic progress bar & status text
    │       ├── ToastContainer.tsx # Floating animated notification toasts
    │       ├── SettingsModal.tsx# Settings & privacy modal
    │       ├── PrivacyBadge.tsx # Client-side processing trust badge
    │       └── IconHelper.tsx   # Dynamic Lucide icon mapper
    │
    ├── views/
    │   └── HomeView.tsx         # Beranda dengan Hero, pencarian, & grid tools
    │
    └── tools/                   # Isolated tool modules
        ├── bg-eraser/
        │   ├── BgEraserTool.tsx
        │   ├── bgRemovalEngine.ts
        │   └── README.md
        │
        ├── video-reverse/
        │   ├── VideoReverseTool.tsx
        │   ├── videoReverseEngine.ts
        │   └── README.md
        │
        ├── mp4-to-mp3/
        │   ├── Mp4ToMp3Tool.tsx
        │   ├── audioConverterEngine.ts
        │   └── README.md
        │
        └── qr-generator/
            ├── QrGeneratorTool.tsx
            ├── qrEngine.ts
            └── README.md
```

---

## Daftar Tools Awal

1. **Background Eraser (`?tool=bg-eraser`)**
   - Hapus background gambar (PNG, JPG, WEBP).
   - Mode: Auto Magic Color & Edge Matting, Color Key Eyedropper, Manual Brush.
   - Pilihan ganti background (Transparan, Putih, Hitam, Studio Blue, Emerald).
   - Interactive Split Comparison Slider & Download PNG.

2. **Video Reverse (`?tool=video-reverse`)**
   - Putar balik frame video dan audio secara lokal.
   - Pilihan Reverse Audio, Mute Audio, atau Original Audio.
   - Pengaturan kecepatan playback (0.75x - 1.5x) dan target FPS.
   - Download video rewind (`ctools-reversed.mp4` / `ctools-reversed.webm`).

3. **MP4 to MP3 Converter (`?tool=mp4-to-mp3`)**
   - Ekstrak trek audio dari video MP4/WebM menggunakan Web Audio API.
   - Encoding MP3 langsung dengan variasi bitrate: 128, 192, 256, 320 kbps.
   - Fitur audio trimming dan pemutar audio internal.
   - Download file MP3 (`ctools-audio.mp3`).

4. **QR Code Link Generator (`?tool=qr-generator`)**
   - Buat QR Code instan dari URL, Teks, WiFi, Email, Telepon, WhatsApp.
   - Kustomisasi ukuran resolusi, margin, warna foreground & background.
   - Pengaturan level koreksi kesalahan (L, M, Q, H).
   - Download format PNG & SVG, serta salin gambar ke clipboard.

---

## Cara Menjalankan CTools

### 1. Menjalankan Server Pengembangan (Dev Mode)
```bash
npm run dev
```
Akses aplikasi melalui peramban di `http://localhost:3000`.

### 2. Membangun untuk Produksi (Build)
```bash
npm run build
```

---

## Panduan Menambahkan Tool Baru

Untuk menambahkan tool baru (misalnya **Image Compressor**):

### Langkah 1: Buat Folder Tool di `src/tools/image-compressor/`
Buat berkas:
- `ImageCompressorTool.tsx` (Komponen UI)
- `compressorEngine.ts` (Logika pemrosesan)
- `README.md` (Dokumentasi tool)

### Langkah 2: Daftarkan Tool ke `src/registry/tools.ts`
Tambahkan entri baru ke `TOOLS_REGISTRY`:
```typescript
{
  id: 'image-compressor',
  name: 'Image Compressor',
  shortDescription: 'Kompres ukuran gambar tanpa mengurangi kualitas',
  description: 'Perkecil ukuran file JPG, PNG, dan WEBP secara instan di browser.',
  icon: 'FileArchive',
  category: 'multimedia',
  badge: 'New',
  tags: ['image', 'compress', 'optimize', 'png', 'jpg'],
  supportedFormats: ['image/png', 'image/jpeg', 'image/webp'],
  maxFileSizeMB: 30,
}
```

### Langkah 3: Tambahkan Router di `src/App.tsx`
Impor komponen dan tambahkan kasus switch:
```tsx
import { ImageCompressorTool } from './tools/image-compressor/ImageCompressorTool';

// Pada renderToolView():
case 'image-compressor':
  return <ImageCompressorTool />;
```

Selesai! Tool baru akan otomatis muncul di Home Page, Sidebar, Filter Kategori, dan dapat diakses langsung via `?tool=image-compressor`.

---

## Shared Components & Utilities

### 1. Reusable Components
- `<UploadBox onFileSelect={...} allowedTypes={...} maxSizeMB={...} />`: Area drag & drop file dengan validasi format dan ukuran otomatis.
- `<FileInfo metadata={...} onClear={...} />`: Komponen chip informasi berkas.
- `<ProgressBar progress={...} statusText={...} />`: Indikator persentase & animasi proses.
- `<PrivacyBadge />`: Badge jaminan privasi lokal.

### 2. Shared Utilities (`src/utils/`)
- `formatFileSize(bytes)`: Mengubah bytes menjadi KB, MB, GB.
- `formatDuration(seconds)`: Mengubah detik menjadi format `MM:SS`.
- `validateFile(file, allowedTypes, maxSizeMB)`: Validasi tipe MIME dan ukuran file.
- `downloadBlob(blob, filename)`: Memicu download berkas tanpa server.
- `toast.success(title, message)` / `toast.error(...)` / `toast.info(...)`: Notifikasi popup global.

---

## Privasi & Keamanan
- Tidak ada data file pengguna yang dikirim ke server backend atau cloud.
- Semua operasi memori dibersihkan menggunakan `URL.revokeObjectURL()` untuk mencegah memory leak.
- Aman dijalankan pada jaringan offline atau intranet.
